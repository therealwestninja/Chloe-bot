(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api; // Node / harness
  root.ChloeT0 = api;                                                        // userscript / window
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  // ---- snowflake helpers ------------------------------------------------------------------
  // Discord IDs are snowflakes: monotonically increasing, but longer than Number can hold, so
  // compare as BigInt. Ordering by id is the reliable chronological order.
  function snowflakeCmp(a, b) {
    var x = BigInt(a), y = BigInt(b);
    return x < y ? -1 : x > y ? 1 : 0;
  }
  function maxSnowflake(a, b) {
    if (a == null) return b;
    if (b == null) return a;
    return snowflakeCmp(a, b) >= 0 ? a : b;
  }
  // A Discord snowflake encodes its own creation time: (id >> 22) + the Discord epoch. So any message
  // id is an authoritative UTC clock reading from Discord's servers — usable to ground the bot's sense
  // of time and as a fallback when no device clock is being pushed. Returns ms since the Unix epoch.
  var DISCORD_EPOCH = 1420070400000;
  function snowflakeTime(id) {
    try { return Number(BigInt(id) >> 22n) + DISCORD_EPOCH; } catch (e) { return null; }
  }

  // ---- reply languages (shared) ---------------------------------------------------------------
  // Small ISO-639-1 subset for `!chloe lang` + `lang default`. Factory scope (not engine
  // scope) so the queen — control command, import firewall, status — shares ONE list with the
  // engine via ChloeT0.LANG_NAMES. The bridge translates at the transport boundary; the engine
  // just records the preference (English-only cognition).
  var LANG_NAMES = { fr: 'French', es: 'Spanish', de: 'German', it: 'Italian', pt: 'Portuguese',
    nl: 'Dutch', ru: 'Russian', ja: 'Japanese', ko: 'Korean', zh: 'Chinese', ar: 'Arabic',
    hi: 'Hindi', tr: 'Turkish', pl: 'Polish', sv: 'Swedish', uk: 'Ukrainian', vi: 'Vietnamese',
    id: 'Indonesian', th: 'Thai', el: 'Greek', he: 'Hebrew', cs: 'Czech', ro: 'Romanian', fi: 'Finnish' };

  // ---- engine -----------------------------------------------------------------------------
  // deps: { transport, store, clock, config, log }
  //   transport.getMessagesAfter(channelId, afterId|null, limit) -> Promise<Array<msg>>
  //     msg = { id, author: { id, username }, content, timestamp }
  //   store.get(key) / set(key, value) / del(key) / listIndex() / setIndex(arr)  (all async-ok)
  //   clock.now() -> ms epoch
  //   config = { channelId, botUserId, recentWindow, speakerRingSize, pollIntervalMs }
  //   log(...)  -> console-like
  function createEngine(deps) {
    var transport = deps.transport;
    var store = deps.store;
    var clock = deps.clock || { now: function () { return Date.now(); } };
    var log = deps.log || function () {};
    var cfg = Object.assign({
      channelId: null,
      botUserId: null,        // drop the bot's own messages by author id
      botName: null,          // for name-addressing ("chloe, ...")
      botAliases: [],         // extra nicknames it answers to (the short form of botName is added automatically)
      recentWindow: 25,       // rolling lines kept per user partition (distilled+window, spec dec #2)
      speakerRingSize: 8,     // last N distinct posters
      pollIntervalMs: 5000,
      onPoll: null,           // optional (summary) -> any; runs after EVERY poll (loop or manual)
      adaptivePolling: true,  // back off when quiet, snap to fast when active (spec 7.10)
      pollFloorMs: 4000,      // fastest cadence (active / pending work)
      pollCeilMs: 30000,      // slowest cadence (long quiet)
      // Pace core (DESIGN-pace.md): one Jacobson rhythm estimator drives debounce, polling, quiet
      // detection, and an AI-cadence floor. Every consumer falls back to its fixed constant when
      // pace is off or too few samples. NO new AI calls.
      adaptivePace: true,
      paceMinSamples: 5,            // need this many gap observations before rhythm drives timing
      paceGapBeta: 0.25,           // deviation EWMA weight (mirrors the brain meter)
      paceDebounceWgap: 0.5,       // debounce ≈ avgGap*Wgap + gapVar*Wdev ...
      paceDebounceWdev: 1.0,
      debounceFloorMs: 800,        // ... clamped: never interrupt-fast (the ceiling is debounceMs itself, see currentDebounce)
      pollAdditiveStepMs: 4000,    // AIMD additive increase per silent poll (default = floor)
      pollBusyCeilMs: 12000,       // busy room: relax polling only PARTWAY to here (passive ingest, still mention-responsive) — not the full pollCeilMs
      paceQuietZ: 3,               // silence counts as "quiet" at this many deviations past typical
      paceMinAIIntervalMs: 90000,  // a background AI pass won't re-run faster than this wall-clock floor (anti cost-multiplier)
      // ---- T1 reply path (all optional; absent => pure T0 read-only) ----
      respond: null,          // async (context) -> { ok, value:text }   (the brain; runs in the generator page)
      send: null,             // async (channelId, text) -> any           (POST to Discord; runs in the userscript)
      addressMode: 'both',    // 'mention' | 'name' | 'both' | 'always' (DM)
      cooldownMs: 8000,       // per-AUTHOR reply cooldown (don't spam the same person)
      globalCooldownMs: 2500, // min gap between ANY two of its sends (lets different people be answered promptly)
      debounceMs: 2500,       // wait for a lull before replying (don't reply mid-burst)
      contextLines: 24,       // recent channel lines handed to the brain (hard upper bound)
      conversationMemory: true,   // give its a TWO-SIDED, legible transcript: include its OWN recent messages (so it sees the back-and-forth it's part of) and resolve <@id>/<#id>/<@&id> refs to readable @names / #channels in what it reads, instead of dropping its turns and stripping every mention. Correctness; off == legacy one-sided view.
      ownLinesMax: 12,        // cap on its own recent messages kept per channel for the transcript
      requestTokenBudget: 5000,// TOTAL tokens per request to the backend — must cover EVERYTHING:
                              // persona + instructions + intention + anti-repeat list + addressed
                              // message + the transcript. The transcript gets whatever's left after
                              // the rest is measured/reserved.
      promptOverheadTokens: 320,// fixed reserve for the page's persona block + instruction scaffolding
                              // (measured: persona ~95 + respond/guidance scaffolding ~200, with margin)
      minTranscriptTokens: 200,// never starve the transcript below this, even if other parts are large
      singleParagraph: false, // mod opt-in: cap its replies to one paragraph (off = it writes as long as fits)
      toolsEnabled: false,    // mod opt-in (default OFF): let the AI call a SAFE tool from its reply via a `tool:` line (summarize/recap/remindme/roster/search/fetch/almanac/time/roll/todo_add/todo_list/todo_done/todo_clear); off == tools run only from `!chloe do`
      converseEngine: true,   // (default ON) the ported rook-mesh social ganglion governs the VOLUNTEER/engage decision (bot-loop damper + worth gate + two-person skip + stagger). OFF == its legacy ad-hoc engage logic, byte-identical.
      trustHardening: true,   // (default ON) multi-participant trust: DEFANG a forged "Name:" prefix from transcript lines + a BOT author can NEVER trigger a command/directive. OFF == current behavior, byte-identical.
      bondLadder: true,       // (default ON) a slow, hysteresis-protected relationship ladder per person (stranger/familiar/friend/close/bonded); surfaces a felt "terms" line so it's warmer with regulars. OFF == no bond field/line, byte-identical.
      // ---- image generation (off unless image + paint + sendImage supplied) ----
      image: false,           // master toggle: answer image requests
      paint: null,            // async ({prompt, resolution}) -> { ok, value:dataUrl }  (runs in the page; the plugin does the iframe song-and-dance)
      sendImage: null,        // async (channelId, dataUrl, caption) -> any            (multipart attachment; runs in the userscript)
      openDM: null,           // async (userId) -> channelId                            (for "dm me" delivery; userscript)
      imageVerbs: ['draw', 'paint', 'sketch', 'render', 'generate', 'make', 'imagine', 'create', 'show'],
      // Image generation runs on its OWN broker, so it threads with text. One image at a time
      // (broker concurrency is 1); imageCooldownMs is just a courtesy gap between images — the real
      // pace is generation time itself, so this is small, not a 30s artificial ceiling. Requests
      // beyond what's in flight wait in a global FIFO queue (no per-author cooldown for images).
      imageCooldownMs: 2000,  // courtesy gap between images (generation time is the real spacing)
      imageQueueMax: 8,       // global image queue depth (adjustable); extra requests are dropped with a note
      // Image memory + natural-language iteration (DESIGN: "the bot knows what it generated, and you
      // can ask for changes in plain language"). When imageMemory is on, each delivered image is
      // recorded on the user's partition (prompt, resolution, when), capped to a small ring, so the
      // bot can both reference what it drew and resolve follow-ups like "make it bigger" / "another"
      // / "same but at night" against the LAST image. Editing rebuilds the PROMPT and regenerates —
      // there is no img2img/seed lock on this backend, so an edit yields a fresh composition, not a
      // pixel-level tweak (the ack phrasing reflects this honestly).
      imageMemory: false,            // opt-in: record + surface what it generated; enables NL edits
      imageMemoryRing: 6,            // how many recent generations to keep per user
      imageEditWindowMs: 600000,     // after an image, a bare edit phrase targets it for this long (10m)
      imageEnhanceOffer: false,      // opt-in: after delivering, offer "want me to refine it?" once
      editPrompt: null,              // OPTIONAL async ({ prev, request }) -> { ok, value:newPrompt } AI hook;
                                     //   when absent, a deterministic rewrite (resolution/detail/add/style) is used
      // ---- auto-moderation (off unless autoMod + rules supplied) ----
      autoMod: false,         // apply rule-based moderation with no mod present
      autoModRules: [],       // [{ pattern, type:'text'|'regex'|'confusables'|'link', action:'ignore'|'timeout'|'softban'|'warn', durationMs?, reason? }]
      // C1: strike ladder. A 'warn' action (rule or !chloe warn) increments a per-user strike count
      // that walks this reversible ladder by index (capped at the last step); strikes decay over time.
      strikeLadder: [
        { action: 'ignore' },
        { action: 'timeout', durationMs: 600000 },
        { action: 'timeout', durationMs: 3600000 },
        { action: 'softban' }
      ],
      strikeDecayMs: 86400000,  // one strike forgiven per ~24h of good behaviour
      // D4 persona anchoring: a mod reacting with anchorEmoji to a message makes that message the
      // channel's style note (newest mod-anchored message wins; sanitized + capped before use).
      anchorEmoji: '\ud83d\udccc',
      personaNoteMaxLen: 200,
      antiRepeatWindow: 5,    // G1: how many of its own recent replies to show the brain to avoid self-repetition
      botLoopGrace: 2,        // bot-loop damper: consecutive bot turns answered at full chance before decay kicks in
      botLoopFloor: 0.05,     // minimum reply chance once decaying (it keeps watching, rarely speaks)
      botLoopHardStop: 12,    // consecutive bot turns after which it goes fully silent until a human speaks (0 = never)
      intentTtlMs: 1800000,   // a standing intention fades after this long without being reaffirmed (default 30m)
      intentMaxLen: 120,      // a self-set intention is capped to this many chars
      // D5: declarative job grammar. ONLY these verbs are accepted from chat-submitted JSON;
      // there is NO code path — a job is a validated plain object, never evaluated. Each verb
      // lists its allowed arg keys and which are required; anything else is rejected.
      jobVerbs: {
        summarize: { args: { lines: 'int' }, required: [] },
        recap:     { args: {}, required: [] },
        roster:    { args: {}, required: [] },
        remindme:  { args: { minutes: 'int', text: 'str' }, required: ['minutes', 'text'] },
        search:    { args: { query: 'str' }, required: ['query'] },
        fetch:     { args: { url: 'str' }, required: ['url'] },
        time:      { args: {}, required: [] },
        todo_add:  { args: { text: 'str' }, required: ['text'] },
        todo_list: { args: {}, required: [] },
        todo_done: { args: { index: 'int' }, required: ['index'] },
        todo_clear:{ args: {}, required: [] },
        almanac:   { args: { kind: 'str', query: 'str', extra: 'str' }, required: ['kind', 'query'] },
        roll:      { args: { dice: 'str' }, required: ['dice'] }
      },
      jobMaxReminderMin: 1440,   // 24h cap on remindme
      reminderMaxPerUser: 5,     // how many pending reminders one person may hold
      reminderMaxTotal: 50,      // global pending-reminder cap per channel
      reminderTextMax: 280,      // reminder text length cap
      todoMaxPerUser: 20,        // how many todos one person may hold
      todoTextMax: 140,          // todo text length cap
      afkNoticeCooldownMs: 300000,// don't repeat an "X is away" heads-up for the same person within 5m
      highlightMax: 50,          // how many highlights a channel keeps (oldest dropped past this)
      highlightContextCount: 3,  // how many recent highlights ride in the response context
      highlightTextMax: 300,     // per-highlight stored text length cap
      // --- reaction significance (size-relative) ---
      reactionTracking: true,    // watch emoji reactions on messages and tally / score them
      serverMemberCount: 0,      // members in this server (0 = unknown -> floor threshold only). Set by
                                 // the userscript from the guild, or configured manually.
      reactionMinUsers: 2,       // a reaction needs at least this many distinct users to count at all
      reactionFraction: 0.01,    // significance threshold scales as this fraction of the member count,
                                 // so 1-2 reactions matter in a 100-person server but are noise in a 5000-person one
      reactionAutoHighlight: true,// a message whose top reaction crosses the significance line auto-highlights
      reactionTallyMax: 40,      // how many distinct emoji the channel tally keeps
      reactionSweepEveryPolls: 6, // re-scan a recent window every Nth poll to catch reactions added late
                                  // (activity-aware: ALSO sweeps the poll right after one that ingested
                                  // messages — reactions cluster seconds after fresh messages, so summons
                                  // and trust land in ~1 poll in active rooms; quiet rooms stay cheap)
      // ---- feedback / preference learning (DESIGN-feedback): adapt toward the reply STYLE that's
      // landing in each channel. A bandit-lite EWMA over style "arms" (length + tone), fed by free
      // poll-side signals (reactions on its messages, continuation, explicit !chloe good/bad), surfaced
      // as a gentle soft-context nudge toward the winning arm. NOT training; on by default. ----
      feedbackLearning: true,
      feedbackAlpha: 0.3,            // EWMA weight on each new signal (recent feedback matters more)
      feedbackMinSamples: 4,         // a style arm needs this many signals before it may nudge
      feedbackMargin: 0.2,           // the winning arm must beat the runner-up by this much to nudge
      feedbackContinuationReward: 0.3,        // soft positive when the person keeps talking after its reply
      feedbackContinuationWindowMs: 600000,   // 10m: continuation only counts inside this window
      feedbackNegativeEmoji: ['\ud83d\udc4e'],// 👎 (negatives; positives reuse trustPositiveEmoji)
      feedbackPendingMax: 12,        // cap on outstanding replies awaiting a continuation signal
      // engagement mode: 'normal' (reply when addressed + volunteer gate), 'locked' (raid panic:
      // ignore everyone but mods; no greeting/volunteering; auto-mod still runs), 'open' (reply to
      // everyone in the channel — the "stream" mode; addressing no longer required).
      engageMode: 'normal',
      // #12: scheduled proactive beats — light, activity-gated time-based presence (lrrbot timers).
      // Each beat: { id, intervalMs, text? | texts?[] | prompt?, activeWithinMs? }. Fires at most one
      // per poll, only if the room has been active recently (won't talk to a dead/empty channel),
      // never during lockdown, never while it's already replying/painting.
      beats: [],
      beatActiveWithinMs: 1800000,  // a beat only fires if someone spoke within this window (30 min)
      beatMinGapMs: 600000,         // minimum gap between any two beats (10 min)
      // Lull filler (Neuro-sama "PATIENCE" pattern, recalibrated for Discord): a small Discord
      // community moves FAR slower than a Twitch stream — a 90-second gap is normal, not a lull. So
      // the thresholds are on the order of DAYS, not seconds. It breaks a silence only when a room
      // that WAS active has been quiet for ~a day, and was active within the past week. Off by default.
      lullFiller: false,             // proactively break a silence after a recently-active room goes quiet
      lullPatienceMs: 86400000,      // ~1 day of silence before it fills it (Discord pace, not Twitch)
      lullActiveWithinMs: 604800000, // only if the room was active within the past week (don't wake a dead channel)
      lullMinGapMs: 86400000,        // at most one lull filler per day
      // Favorite-user check-ins: if a user it's interacted with a lot hasn't been seen in DAYS, it
      // may post a warm "haven't seen you in a while" — @mentioning them only if pings are enabled
      // (the output gate decides). Discord pace: absence is measured in days. Off by default.
      checkins: false,               // proactively check in on favorite users who've been absent
      checkinMinInteractions: 8,     // interaction count that makes someone a "favorite" worth missing
      checkinAbsenceMs: 259200000,   // a favorite must be absent ~3 days before a check-in
      checkinPerUserGapMs: 1209600000,// don't check in on the same person more than once per ~2 weeks
      checkinGapMs: 86400000,        // at most one check-in (any user) per day
      checkinFavorites: [],          // pinned favorite user ids: always worth missing, whatever their interaction count
      checkinBlacklist: [],          // never proactively check in on these ids (NOT moderation — normal replies untouched)
      // A1/A4 actuation policy (approvals + grants for autonomous output only —
      // beats, check-ins, lull fillers; replies and user-requested images are
      // never held). 'allow' = today's behavior (default); 'ask' = hold for a
      // mod's approval; 'deny' = never actuate proactively.
      actPolicy: 'allow',             // allow | ask | deny
      actGrants: [],                 // remembered [{action, resource, scope, at, until?}] (ChloeModAudit)
      // G5 time awareness: it can sense the time of day, the day of week, and how long the room has
      // been quiet, so its tone fits the moment (a late-night hush, a weekend lull) rather than being
      // timeless. Needs the community's UTC offset to be right; on by default.
      timeAware: true,              // weave a light sense of time-of-day / day / quiet-duration into context
      timezoneOffsetMins: 0,         // the community's offset from UTC in minutes (e.g. -480 for US Pacific)
      // G6 mood: a light, front-end read of the room's tenor from pace + cheap lexical signals
      // (laughter, exclamation, emoji, caps). Two safe dimensions only — energy (quiet..lively) and
      // playfulness (subdued..joking). Deliberately NOT trying to detect anger/conflict (error-prone,
      // and misreading a serious moment is worse than no read). Rides into context as soft tone
      // guidance. On by default.
      moodAware: true,              // sense and gently match the room's energy / playfulness
      moodDecay: 0.7,                // how much prior mood carries over each update (higher = steadier)
      // Rolling channel summary (SillyTavern-style recursive summary): fold the recent
      // transcript into a running ≤W-word summary of the channel's arc, fed back in each time. Rides
      // into context so it keeps a sense of the story so far past the raw transcript window. On by default
      // (the host's cfgGet fallback is also true) so a fresh install keeps memory past the 24-line window.
      // LOAD-GATED: the EveryPolls timer below is a backstop — a pass only runs when transcript lines
      // newer than the last rollup exist (silence never triggers one), and a full bucket of new lines
      // forces an early pass so busy channels roll up more often (wall-clock floor still applies).
      channelSummary: true,
      channelSummaryEveryPolls: 30,   // backstop cadence (skipped when nothing is new)
      rollupFullLines: 20,            // new transcript lines since the last rollup that force an early summary/episode pass (half the 40-line fold window)
      channelSummaryWords: 60,
      thoughtsFeedTarget: null,      // F1: Discord channel id to post fresh summaries to (per-source-channel, lang-mirror); null = panel feed only
      newsFeeds: [],                 // F2: [{id, name, site, channelId, intervalMs, maxItems, banWords, allowCats, blockCats}] — hourly sitemap rollups
      fetchText: null,               // F2: wiring-provided (url) -> Promise<{ok, value|reason}> (host-allowlisted, fail-open); null = news lane inert
      newsFn: null,                  // F2 voice: wiring-provided ({feed, date, items, itemText, prompt}) -> Promise<{ok, value}>; null = classic list only
      newsPrompt: null,              // F2 voice: null/undefined = DEFAULT_NEWS_PROMPT (AI voice); '' = classic deterministic list; other = custom instruction ({feed} {date} {items})
      newsPodcastPrompt: null,       // F2 podcast voice: null/undefined = DEFAULT_PODCAST_PROMPT; '' = classic list; other = custom ({feed} {date} {item} {duration} {audio} {kind} {cadence})
      newsPostTemplate: null,        // F2 voice: null/undefined = DEFAULT_NEWS_TEMPLATE; {feed} {date} {count} {body} (no {body} -> appended)
      newsInContext: false,          // F2 redirect: false (default) = own 📰 rollups stay OUT of the reply transcript (they'd eat the budget + get parroted); a one-line marker folds into Thoughts instead. true = classic: own posts join chat context like any reply.
      newsReview: false,             // F2 review queue: false (default) = composed rollups post immediately; true = they stage in the news queue (Setup → News queue) for edit/regenerate/post instead.
      // Reflection (Generative-Agents pattern): when enough IMPORTANCE has accumulated from newly
      // learned facts about a person, make one synthesis pass turning their raw facts into 1-2 durable
      // higher-level insights ("what I've come to understand about them"). Insights live on the
      // partition (archive/restore free) and lead the person-summary above raw facts. On by default.
      reflection: true,
      reflectionImportanceThreshold: 20,   // summed importance of new facts that triggers a reflection
      reflectionEveryPolls: 16,            // cadence gate (it's an AI call)
      insightsPerUser: 3,                  // durable insights kept per person (oldest dropped)
      // Episodic memory (DESIGN §7a): experiences as events. A gated pass turns recent activity into
      // short episode records ("what happened", not message-by-message); recall is keyword-overlap
      // relevance × importance × recency, riding into context only when something actually matches.
      episodicMemory: true,
      episodesPerChannel: 40,              // ring cap per channel (oldest dropped)
      episodeEveryPolls: 24,               // extraction cadence (it's an AI call); (every-1) form, never poll 1
      episodeRecallCount: 2,               // max episodes recalled into one reply
      episodeRecencyHalfLifeMs: 604800000, // recall decay half-life (7d): old episodes fade, never vanish
      // ---- semantic recall + FSRS-lite (DESIGN-semantic, default ON): rank recalled episodes by MEANING (local
      // embeddings via transformers.js, the same engine AICC uses) instead of keyword overlap, and let
      // memories it REVISITS stay sharp via an FSRS forgetting curve whose stability grows on each
      // recall. Opt-in; needs episodicMemory. Falls back to keyword overlap when no embedder. ----
      semanticRecall: true,
      embedModel: 'Xenova/bge-small-en-v1.5',  // ~33MB quantized, 384-dim; the page loads it lazily
      embedFn: null,            // optional (texts[]) -> Promise<number[][]|null>; supplied by the page broker
      semanticMinSim: 0.4,      // cosine floor for an episode to count as semantically relevant
      fsrsInitialStability: 4,  // days: a fresh episode's stability (elapsed time to ~90% retrievability)
      fsrsRecallGrowth: 1.9,    // stability multiplier each time an episode is recalled (the spacing effect)
      fsrsMaxStability: 365,    // cap on stability (days)
      // Event-graph (DESIGN-eventgraph.md): link episodes by shared people/topics/time at EXTRACTION
      // (no LLM), so recall can walk ONE hop ("…and connected to that…"). Default ON.
      episodeGraph: true,
      episodeLinkHalfLifeMs: 21600000,     // 6h: events in one session associate; weeks apart don't (unless people/topics carry them)
      episodeLinkFloor: 0.15,              // below this weight, episodes stay unlinked (sparse graph)
      episodeLinkWp: 0.5,                  // weight: shared participants (strongest associative signal)
      episodeLinkWt: 0.3,                  // weight: shared topics
      episodeLinkWd: 0.2,                  // weight: temporal adjacency
      // Relationship trust (DESIGN §7b): a 0-100 per-person scalar EARNED through positive signals
      // only — never penalized, daily-capped so it can't be farmed, decaying with long absence.
      // Tone + a reply-priority tiebreak ONLY: trust never loosens moderation, gates, or policy.
      relationshipTrust: true,
      trustReplyGain: 1,            // its completed reply to someone
      trustReactionGain: 2,         // their positive reaction on HER message
      trustDailyCap: 5,             // max trust earnable per person per day
      trustDecayFactor: 0.85,       // applied on the same long-absence event as familiarity decay
      trustPositiveEmoji: ['\u2764\ufe0f', '\ud83d\udc4d', '\ud83d\ude02', '\ud83c\udf89', '\ud83d\ude0a'],
      trustPriorityTier: 60,        // at/above this, the new-user-sized (+1) priority tiebreak applies
      // Own affect (DESIGN §7d): a small internal state vector — HER feel, distinct from reading the
      // room. Front-end only (no AI calls). Flavor for its voice, NEVER a lever on users: whitelist
      // phrasing, a hard confidence floor (no spirals), and silence when it's near neutral.
      ownAffect: true,
      // Working memory (DESIGN-working-memory.md): a volatile per-channel workspace — current topic,
      // who's here, the active goal, its recent decisions, its mood. Decays on read like affect.
      // Mostly synthesized from signals it already has; only `topic` can cost a (reused) call.
      workingMemory: true,
      semanticInjections: [],   // arbitrary system/operator facts surfaced into context (DESIGN-semantic-inject.md): [{id,text,priority,ttlMs,at}]
      cleanOutput: true,        // scrub model-mechanics noise from replies (DESIGN-clean.md): role-bleed, dangling tail, unbalanced fences
      globalStore: null,        // optional: a store at root prefix for keys shared across ALL channels (e.g. blocklist)
      isDM: false,              // true for a DM engine: it MERGES public facts (from globalStore) into context
                                //   read-only, but writes only to its own bucket — DM content never crosses back to public.
      deviceClock: null,        // {time, date, tz, at} pushed by the page for instant !chloe time/date (no AI)
      deviceClockStaleMs: 180000,   // a pushed clock older than this is considered stale (panel closed)
      // Idle deliberation (DESIGN-deliberation.md): a ReAct map-reduce reasoning loop. When genuinely
      // idle and curious, it decomposes a thought into atomic sub-questions, answers them (parallel
      // across worker tabs when a pool exists), and recomposes an insight/goal. NEVER sends. Curiosity-
      // gated (self-limiting: a resolved deliberation lowers curiosity). Opt-in (spends real calls).
      idleDeliberation: false,
      deferredIntents: false,    // self-scheduled future cognition (DESIGN-self-intents): a concluded deliberation can schedule a later REVISIT of its subject — an internal action, never a message. Needs idleDeliberation.
      selfIntentMax: 8,          // cap on queued self-intents per channel
      selfIntentRevisitMs: 21600000,   // 6h: how far out a revisit is scheduled when it finds a topic worth coming back to
      attentionManager: true,    // utility-scored AI-pass selection (DESIGN-attention.md, default ON); off = today's fixed ladder
      selfKnowledge: true,      // ground its in its own basics (name, prefix, summon) from config (DESIGN-selfknow.md)
      botVersion: '',            // for operational self-state grounding (passed from the shell); '' -> omitted
      // ---- user-model register (DESIGN-usermodel, roadmap #5): a light, inferred per-person register
      // (how THEY write: typical length + tone) so it can MATCH it. Deterministic (reuses styleOf over
      // their recent messages, no AI), on by default. Insights already cover the "what they're into" dimension;
      // this adds the communication-style dimension they don't. ----
      userModeling: true,
      userModelMinMsgs: 3,       // need at least this many of their recent messages to infer a register
      deliberateCuriosityFloor: 0.62,   // only think when curiosity is meaningfully above neutral
      deliberateMinGapMs: 600000,       // hard floor between deliberations (10m) so bursts can't chain
      deliberateMaxSubQuestions: 4,     // cap the fan-out (decompose returns up to this many)
      deliberateCuriosityDrop: 0.18,    // a completed deliberation scratches the itch (lowers curiosity)
      workTopicTtlMs: 1200000,      // 20m of inactivity -> the "current topic" goes null (not stale)
      workDecisionTtlMs: 1800000,   // a recorded decision ages out after 30m
      workDecisionsMax: 5,          // bounded ring of recent notable actions
      workParticipantsMax: 5,
      affectDecayPerHour: 0.8,      // each value relaxes toward neutral 0.5 by this factor per hour
      affectConfidenceFloor: 0.3,   // it never drops below this — quieter, not despondent
      affectGain: 0.08,             // size of one event nudge
      affectEngageWindowMs: 600000, // a user message within 10m of its reply = engagement (confidence up)
      affectIgnoreAfterMs: 1800000, // no one says anything for 30m after its reply = ignored (confidence down)
      // Procedural memory (DESIGN §7c): operator-defined reaction→mode rules. A configured emoji
      // from a MODERATOR (modOnly is fixed in v1 — reactions are unauthenticated input) switches its
      // into a timed behavior mode. Persona-note sanitation; tone/behavior guidance ONLY — a mode can
      // never alter moderation, gates, or content rules.
      proceduralModes: true,
      procRules: [],                 // [{ emoji: '\ud83d\udd27', mode: 'switch to technical mode…', durationMs: 3600000 }]
      procMaxDurationMs: 86400000,  // hard cap: no mode outlives a day
      // Engine run-lock (FAILOVER-ANALYSIS.md): the hard close for the sleep/wake two-queen polling
      // window. Before each poll the engine must hold a short-TTL lock in the SHARED per-channel
      // store; a non-holder skips the poll entirely. ON by default — this is a correctness lock,
      // not a behavior feature. runLock:false is a debugging escape hatch only.
      runLock: true,
      runLockTtlMs: 45000,          // < queenDeadAfterMs (90s): a frozen holder is stale before anyone can promote;
                                    // > any healthy poll cadence: a live queen never loses its own lock between polls
      // Gap A (FAILOVER-ANALYSIS.md): resume a TEXT reply a dead predecessor lost mid-generation.
      // Conservative by design: age-capped, and gated on verification (any bot message after the
      // target = assume answered) — trades duplicates for occasional non-resumption.
      replyResume: true,
      replyResumeMaxAgeMs: 600000,  // older than 10 min: a stale answer is worse than silence
      // Goal objects (DESIGN-goals.md): prospective memory — durable, CROSS-CHANNEL goals promoted
      // from what reflection already learns. Recall is owner-scoped; no new LLM call on any path.
      goalObjects: true,
      goalsMax: 40,                 // bounded list; closed goals evicted oldest-first
      goalTextMax: 140,
      goalStaleMs: 2592000000,      // 30d untouched -> auto-dropped (goals fade if the world moves on)
      characterMemoryMax: 24,       // cap on respooled character self-memories
      // Idle consolidation (DESIGN-consolidation.md): the “sleep” pass — during genuine idle, tidy
      // memory. Structural dedup is pure local compute (every idle pass); semantic merge/contradiction
      // is one gated LLM pass (one user). Never sends. Default ON.
      idleConsolidation: true,
      consolidateIdleMs: 1800000,   // channel quiet this long = idle enough to tidy (30m; lighter than the day-scale lull filler)
      consolidateEveryPolls: 50,    // don't sweep every poll in a perpetually-quiet channel
      consolidateSliceSize: 5,      // structural sweep: partitions cleaned per pass (spreads a big roster)
      consolidateMinFacts: 6,       // semantic pass skips anyone with fewer facts than this
      episodeDropImportanceFloor: 3, // stale + low-importance episodes get hard-dropped from the ring
      // Round-trip awareness (DESIGN-roundtrip.md): when a generation COMPLETES, the next queued job
      // fires via cfg.defer(fn, ms) (host setTimeout) instead of waiting for the next poll tick.
      // Purely additive: with no defer hook, behavior is exactly the old poll-bound dispatch.
      typingRefreshMs: 8000,        // Discord's typing indicator lasts ~10s; refresh while generating
      // Reaction vocabulary (README §Reactions): semantically truthful indicators, all under the
      // ackReactions toggle. 🗣️ = generating your text reply; 🖼️ = painting; 🔍 = looking
      // something up; ⏳ = saw you, throttled (cooldown/budget) — auto-clears; 🔒 = mods-only mode.
      // DELIBERATE: no indicator for quiet moderation (ignore/softban/block) — reacting would
      // announce it. Throttle indicators cover only benign, temporary reasons.
      ackThrottleEmoji: '\u23f3',
      ackLockdownEmoji: '\ud83d\udd12',
      ackSearchEmoji: '\ud83d\udd0d',
      ackClearMs: 30000,            // why-not indicators clear themselves after this long
      // Reply references: its text replies attach to the message they answer (Discord's native
      // reply threading), with the reply-ping suppressed. Pure clarity; replyReference:false to disable.
      replyReference: true,
      // Reaction summon (README §Reactions): monkey-see-monkey-do — react to YOUR OWN message with
      // one of its own indicators and it treats it as an explicit address. Mods can summon its onto
      // anyone's message. All normal gates still apply (lockdown, moderation, cooldowns, budget).
      reactionSummon: false,
      summonEmoji: ['\ud83d\udde3\ufe0f', '\u2757', '\ud83e\udd16'],   // its speak indicator, ! and the robot — deliberately NOT ❤️ (hearts are warmth, and casual)
      summonMaxAgeMs: 900000,       // messages older than 15m can't be summoned — a stale summon found on
                                    // cold boot (reacted while it was offline) must NOT fire (the
                                    // v0.46.3 “cold start treats history as live” bug class)
      // Reaction polls: !chloe poll <question> | <a> | <b> ... — it posts the ballot, seeds the
      // number reactions, and tallies counts on close (or auto-close). One active poll per channel.
      pollMaxAgeMs: 86400000,       // polls auto-close after a day if nobody closes them
      checkinMaxAttempts: 2,         // give up after this many ignored check-ins (~28d at a 14d gap)
      // Data tiering: cold records leave the hot store so the main roster stays fast. A user who has
      // ignored every check-in, or who's been absent a long time, is moved to a secondary "historical
      // friends" archive (separate per-user keys, never loaded on the hot path). They're restored
      // automatically the moment they speak again. Favorite-aware: the more it's interacted with
      // someone, the longer they're kept in the fast store before archival.
      archiveStale: true,            // move long-cold users out of the hot roster into the archive
      archiveAbsenceMs: 5184000000,  // base absence before a user is archived (~60 days)
      archiveFavoriteBonusMs: 2592000000,// each "favorite tier" of interactions adds this much patience (~30d)
      archiveFavoriteTier: 8,        // interactions per favorite tier (so an 8-interaction user waits +30d)
      archiveMaxKept: 2000,          // cap on archived users (oldest pruned beyond this)
      // --- F1 fact memory (learn people over time) ---
      // It can remember a few durable, voluntarily-shared facts about regulars ("is learning rust",
      // "has a cat named Pixel") so it feels like it knows them. Conservative and controllable:
      // extraction refuses sensitive categories, users can see/forget what's stored. On by default
      // (the host's cfgGet fallback is also true) so a fresh install actually learns who people are.
      factMemory: true,              // observe and remember durable facts about people
      factsPerUser: 6,               // how many facts it keeps per person (oldest dropped past this)
      factMinInteractions: 4,        // only start remembering people it's actually engaged with
      factProposeGapMs: 86400000,    // at most one extraction pass per user per day (it's an AI call)
      factProposeMinNew: 4,          // ...and only after this many new messages from them since last pass
      factTextMax: 140,              // per-fact length cap
      factContextCount: 4,           // how many facts ride into its context for an active person
      factImportanceDefault: 5,      // neutral importance for facts with none (old data / bare strings)
      factRecencyWeight: 2,          // how much recency tilts the importance-ranked fact selection
      factEveryPolls: 12,            // run the silent extraction pass at most every Nth poll
      contradictionAware: true,     // flag when a NEW fact contradicts a HELD one (DESIGN-contradiction): keep both, record it, and (gently, AI-discretionary) let its clarify. Needs factMemory.
      contradictionImportanceFloor: 5,   // only flag conflicts where the new fact is at least this important (don't fuss over trivia)
      contradictionFreshMs: 7200000,     // 2h: how long after a conflict appears it'll consider gently raising it
      contradictionTtlMs: 259200000,     // 3d: an unresolved recorded conflict is cleared after this (tidied on the idle sweep)
      beatFn: null,                 // optional (beat) -> {ok,value}; in-character generation for prompt-beats
      // ---- T2 volunteer gate (off unless volunteer + judge + react supplied) ----
      judge: null,            // async (context) -> { ok, value:{ action:'reply'|'react'|'ignore', confidence:0..1, emoji|emojis } }
      react: null,            // async (channelId, messageId, emoji) -> any
      volunteer: false,       // chime in on UN-addressed messages?
      volunteerCooldownMs: 45000,  // volunteering is rarer than answering
      judgeMinConfidence: 0.6,     // below this, a reply/react decays to ignore
      judgeReactions: null,   // curated volunteer-reaction allowlist; null/undefined = DEFAULT_JUDGE_REACTIONS; [] = react-votes disabled
      judgeMaxReactions: 2,   // combo cap: the judge may vote at most this many emoji on one message
      // ---- T3 reversible moderation ----
      modList: [],            // author.ids allowed to issue in-channel commands (seeded by trusted surface)
      commandPrefix: '!chloe',// text-prefix command grammar (no slash under Adapter A)
      commandPrefixes: [],    // optional extra prefixes (e.g. '!c', 'chloe,') — all resolve to the same commands
      ackCommands: true,      // post a brief in-channel confirmation when a command runs
      backgroundText: false,  // when on, the text lane is fire-and-forget (poll loop never blocks on generation)
      keepActionLog: true,    // T4: keep a separate, purge-surviving record of mod actions (decision #5)
      modLogContextLines: 5,  // #11: snapshot of the target's most recent lines captured with each mod action
      typing: null,           // optional async (channelId) -> POST typing; pulsed before a generation
      recapFn: null,          // optional async (ctx) -> { ok, value } channel summary for !chloe recap
      // ---- T5 presence depth ----
      greet: true,                  // default ON: greet first-ever speakers and long-absent returners
      greetFn: null,                 // async (ctx) -> { ok, value } greeting line from the brain
      greetReturnAfterMs: 172800000, // gap >= 2d counts as "been a while" (shorter gaps stay silent)
      greetCooldownMs: 43200000,     // >=12h between greetings for one person (one per crossing, not per msg)
      greetDebounceMs: 4000,         // settle before greeting (people fire 2-3 lines on arrival)
      greetSettleMs: 60000,          // after Start, don't greet for this long (people already here aren't "arrivals")
      quietAfterMs: 86400000,        // active -> quiet once a user ages out of ~1d of attention
      decayAfterMs: 604800000,       // a return after >=7d quiet decays familiarity (warmth follows recency)
      decayFactor: 0.5,              // interactionCount *= this on a decayed return (never below 0)
      backfill: false,               // one-time: walk history backward to seed the roster
      backfillPageSize: 100, backfillMaxPages: 8,  // bounded + checkpointed; ingest only, never greets/replies
      // On a cold start / after Reset State the cursor is empty, so the first poll pulls a chunk of
      // recent history. Without a clamp, EVERY image request in that backlog fires at once. So on the
      // startup batch, image generation is limited to the few most-recent user messages; normal image
      // handling resumes on every poll after.
      startupImageMax: 5,            // most-recent user messages eligible for image gen on the startup batch
      startupBacklogThreshold: 8,    // a cold-start first poll bigger than this is treated as a history backlog (observe-only)
      maintenanceEveryPolls: 10      // run the quiet-sweep (active->quiet) every Nth poll, not every poll
    }, deps.config || {});
    // globalStore is a top-level dep (the root-prefix store shared across channels). Bind it onto cfg
    // so the helpers that look for it — blockStore() (global blocklist) and the DM public-profile
    // merge — actually find it. Without this it stayed null and blockStore()/merge silently fell back
    // to the per-channel store, so a ban or a public fact never reached secondary/DM engines.
    if (deps.globalStore) cfg.globalStore = deps.globalStore;
    // Raw (ungated) handle on THIS channel's namespaced bucket, for converging pre-upgrade
    // per-channel user partitions into the shared pool. Gated `store` would silently drop
    // the legacy cleanup deletes, so migration/purge must not use it. Falls back to `store`
    // for old callers (harnesses) that don't pass it.
    var localRaw = deps.localStore || store;

    var CURSOR_KEY = 'cursor:' + cfg.channelId;
    var INDEX_KEY = 'roster:index';
    // GDPR / ethereal mode. A user who asks to be forgotten becomes invisible to memory in THIS
    // bucket: no partition, no facts, no roster/summary/episode contribution, no image tracking —
    // but the bot can still reply to them in the moment. Per-context by design: the public bucket
    // (globalStore for any public channel) and each DM bucket hold their own flag, so a user can be
    // ethereal in public while still on the record in a DM, or vice versa. The forget-floor is a
    // per-user timestamp that survives `remember me`, so re-enabling memory never lets backfill or a
    // cold start reach back and re-learn the history they erased.
    var ETHEREAL_KEY = 'ethereal';        // { ids: { id: { at, name } } }  (in etherealStore())
    var FORGETFLOOR_KEY = 'forgetfloor';  // { id: ts }                     (in etherealStore())
    var GOALS_KEY = 'goals';   // goals are USER data: shared across PUBLIC channels, but kept LOCAL to each DM
    var CHARMEM_KEY = 'charmem';   // CROSS-CHANNEL (via globalStore): the installed character's own respooled memories (background context)
    // charmem is the BOT's own character background (operator-authored, not user data), so it lives in
    // globalStore and is identical everywhere. Goals, by contrast, are the user's — so they go through
    // goalStore(): shared across public channels (globalStore) but isolated to the local bucket inside a
    // DM, so a goal set in a DM can NEVER surface in a public channel or in another user's DM. (Same
    // per-context rule as etherealStore.)
    function crossStore() { return cfg.globalStore || store; }
    function goalStore() { return cfg.isDM ? store : (cfg.globalStore || store); }
    var CONSOLIDATE_KEY = 'consolidate:' + cfg.channelId;   // { lastSweepAt, sliceCursor } for the idle “sleep” pass
    var RING_KEY = 'speaker:ring:' + cfg.channelId;
    var RHYTHM_KEY = 'rhythm:' + cfg.channelId;
    var MOOD_KEY = 'mood:' + cfg.channelId;   // G6: decayed room-tenor read (energy + playfulness)
    var CHANSUM_KEY = 'chansum:' + cfg.channelId;   // rolling recursive summary of the channel's arc
    var EPI_KEY = 'epi:' + cfg.channelId;           // episodic memory ring (experiences as events)
    var AFFECT_KEY = 'affect:' + cfg.channelId;     // its own internal state {curiosity, confidence, warmth}
    var WORK_KEY = 'work:' + cfg.channelId;         // volatile cognitive workspace {topic, participants, goal, recentDecisions, mood, at}
    var DELIB_KEY = 'delib:' + cfg.channelId;       // { lastAt } — min-gap floor between deliberations
    var PROC_KEY = 'procmode:' + cfg.channelId;     // active procedural mode { mode, until, by, emoji }
    var POLL_KEY = 'poll:' + cfg.channelId;         // active reaction poll { messageId, question, options, endsAt }
    var INTENT_KEY = 'intent:' + cfg.channelId;   // Sweetie set_goal pattern: a standing intention that
    // survives across polls and rides in every response context, so it holds a thread of purpose
    // ("getting to know the new folks", "keeping it light after that argument") rather than reacting
    // to each message in isolation. The brain may set it; it decays if not reaffirmed.
    var REMIND_KEY = 'reminders:' + cfg.channelId;   // poll-driven scheduled reminders (front-end only,
    // no AI call). Checked each poll rather than via setTimeout, because background tabs throttle
    // timers to ~1/min — a poll-driven check fires reliably on the first poll after the due time.
    var TODO_KEY = 'todos:' + cfg.channelId;   // personal checklists (same store-list shape as reminders, per-author)
    var SKILL_KEY = 'skills:' + cfg.channelId;   // server knowledge packs (mod-managed, auto-injected on trigger match)
    var AFK_KEY = 'afk:' + cfg.channelId;   // user-set away state (front-end only, no AI call): set on
    // "!chloe afk", auto-cleared when the person speaks again, surfaced when others ping them.
    var HILITE_KEY = 'highlights:' + cfg.channelId;   // pinned notable messages (front-end only): saved
    // for recall via "!chloe highlights", and a few recent ones ride in context so it can reference
    // the channel's memorable moments — a step toward memory without the full fact-extraction build.
    var REACTTALLY_KEY = 'reacttally:' + cfg.channelId;   // running per-emoji tally of significant reactions
    var BACKFILL_KEY = 'backfill:' + cfg.channelId;
    var BEATS_KEY = 'beats:lastrun:' + cfg.channelId;   // #12: beatId -> last-fired ts (+ __lastAny)
    var FEEDBACK_KEY = 'feedback:' + cfg.channelId;     // DESIGN-feedback: per-channel EWMA over reply-style arms {len,tone}
    var OWNLINE_KEY = 'ownlines:' + cfg.channelId;   // its OWN recent messages (text + ts), captured at ingest from
    // the messages Discord echoes back, so the transcript it reads is two-sided (DESIGN-conversation-memory).
    // Bounded by ownLinesMax. Per-channel; in a DM it lives in the isolated DM bucket.
    var SELFINTENT_KEY = 'selfintents:' + cfg.channelId;   // deferred self-intents: a persistent queue of future
    // INTERNAL actions it scheduled for itself (currently: 'revisit' a deliberation subject). Poll-driven
    // like reminders, but a fired intent never sends — it drives its own later cognition. Per-channel; in a
    // DM it lives in the (isolated) DM bucket. Bounded by selfIntentMax.
    var LULL_KEY = 'lull:' + cfg.channelId;   // last time it filled a silence (lull filler throttle)
    var CHECKIN_KEY = 'checkins:' + cfg.channelId;   // { __last: ts, byUser: { id: {at,count,seenAt} } } — check-in throttle + attempt cap
    var LULLDIAG_KEY = 'lulldiag:' + cfg.channelId;   // last terminal lull outcome { lastAt, lastResult, lastError } — throttle ts stays in LULL_KEY
    var CHECKINDIAG_KEY = 'checkindiag:' + cfg.channelId;   // same for check-ins (throttle/caps stay in CHECKIN_KEY)
    var AIPASS_KEY = 'aipass:' + cfg.channelId;   // AI-pass last runs { facts|summary|reflect|episodes|consolidate|deliberate: { lastAt, lastResult, lastError } }
    var ACTPEND_KEY = 'pendingact:' + cfg.channelId;   // A1: held autonomous actions [{id, class, at, reason}]
    var ACTONCE_KEY = 'approveonce:' + cfg.channelId;  // A1: one-shot approvals {class: 1}, consumed on next fire
   var ACTSNOOZE_KEY = 'actsnooze:' + cfg.channelId;  // A1: dismissals {class: untilTs} — re-hold only after this
    var UNDO_KEY = 'undostack:' + cfg.channelId;         // A6: undo stack [{at, kind, targetId?, summary, inverse}] (bounded)
    var ACTLOG_KEY = 'actlog:' + cfg.channelId;        // A5: decision journal [{at, class, verdict, why}], bounded
    // ---- shared cross-channel user pool -------------------------------------------
    // Regular (non-DM) public channels with Remember ON share ONE per-user pool in the
    // global store: someone active in 3 channels has one partition (one recent-lines
    // window, one fact/insight set, one familiarity count) instead of 3 isolated ones.
    // DMs and Remember-off (goldfish) channels keep strictly isolated local partitions —
    // the goldfish model and the DM privacy boundary are unchanged.
    function sharedUsers() { return (!cfg.isDM && cfg.chanRemember !== false && !!cfg.globalStore); }
    function userStore() { return sharedUsers() ? cfg.globalStore : store; }
    // Archive (cold "historical friends") follows the same split: one global cold pool for
    // shared users, per-channel otherwise. Pre-upgrade archives live under the per-channel
    // keys; restore + novelty checks fall back to them so nobody strands.
    function archIndexKey() { return sharedUsers() ? 'arch:index:global' : 'arch:index:' + cfg.channelId; }
    function archKey(id) { return (sharedUsers() ? 'arch:global:u:' : 'arch:' + cfg.channelId + ':u:') + id; }
    function legacyArchKey(id) { return 'arch:' + cfg.channelId + ':u:' + id; }
    function legacyArchIndexKey() { return 'arch:index:' + cfg.channelId; }
    // ---- smart recent window ------------------------------------------------------
    // A dumb FIFO drops the OLDEST line, so a busy room's filler ("lol","ok","k" x20)
    // evicts the one substantive thing someone said. Score each line and evict the
    // lowest-signal first (ties: oldest), always protecting the newest line (live edge).
    function lineScore(t) {
      var s = String(t == null ? '' : t).trim();
      if (!s) return 0;
      if (CONVERSE_FILLER.test(s) || s.length < 3) return 1;
      var score = 3;
      if (s.length > 40) score += 2; else if (s.length > 15) score += 1;
      if (s.indexOf('?') >= 0) score += 2;
      if (/@|#\d|https?:\/\//.test(s)) score += 1;
      return score;
    }
    function smartTrimRecent(arr, cap) {
      if (!Array.isArray(arr) || arr.length <= cap) return arr;
      var keep = arr.slice(0, -1), last = arr[arr.length - 1];   // newest line is never evicted
      if (keep.length + 1 <= cap) return arr;
      var decorated = keep.map(function (ln, i) { return { i: i, s: lineScore(ln && ln.content), ts: (ln && ln.ts) || 0 }; });
      decorated.sort(function (a, b) { return (a.s - b.s) || (a.ts - b.ts) || (a.i - b.i); });
      var drop = decorated.slice(0, keep.length + 1 - cap), dropSet = {};
      drop.forEach(function (d) { dropSet[d.i] = true; });
      return keep.filter(function (_, i) { return !dropSet[i]; }).concat([last]);
    }
    function stampCh(p, chId) {
      if (p && Array.isArray(p.recent)) p.recent.forEach(function (ln) { if (ln && !ln.ch) ln.ch = chId; });
      return p;
    }
    function mergeFacts(dst, src) {
      var seen = {}; (dst || []).forEach(function (f) { seen[normFact(f && f.text)] = true; });
      (src || []).forEach(function (f) {
        var k = normFact(f && f.text); if (!k || seen[k]) return; seen[k] = true; dst.push(f);
      });
      return dst;
    }
    // One-shot convergence of a pre-upgrade per-channel partition into the shared pool.
    // Idempotent (unions by id/text, max-picks for counters) so a re-run after a midway
    // failure just converges again instead of duplicating.
    function mergeLegacyPartition(legacy) {
      var ustore = userStore();
      stampCh(legacy, cfg.channelId);
      return Promise.resolve(ustore.get(partKey(legacy.id))).then(function (cur) {
        var base = cur || { id: legacy.id, name: legacy.name, firstSeen: legacy.firstSeen, lastSeen: 0, interactionCount: 0, state: 'active', recent: [] };
        var seenIds = {}; (base.recent || []).forEach(function (ln) { seenIds[String(ln.id)] = true; });
        (legacy.recent || []).forEach(function (ln) { if (ln && !seenIds[String(ln.id)]) { seenIds[String(ln.id)] = true; base.recent.push(ln); } });
        base.recent.sort(function (a, b) { return (a.ts || 0) - (b.ts || 0); });
        base.recent = smartTrimRecent(base.recent, cfg.recentWindow);
        base.name = ((legacy.lastSeen || 0) >= (base.lastSeen || 0) ? legacy.name : base.name) || base.name || legacy.name;
        base.firstSeen = Math.min(base.firstSeen || Infinity, legacy.firstSeen || Infinity);
        if (!isFinite(base.firstSeen)) base.firstSeen = legacy.lastSeen || clock.now();
        base.lastSeen = Math.max(base.lastSeen || 0, legacy.lastSeen || 0);
        base.interactionCount = Math.max(base.interactionCount || 0, legacy.interactionCount || 0);
        if (cfg.relationshipTrust) base.trust = Math.max(base.trust || 0, legacy.trust || 0);
        base.facts = mergeFacts(Array.isArray(base.facts) ? base.facts : [], legacy.facts);
        base.insights = mergeFacts(Array.isArray(base.insights) ? base.insights : [], legacy.insights);
        if (Array.isArray(legacy.images) && legacy.images.length) {
          base.images = (Array.isArray(base.images) ? base.images : []).concat(legacy.images).slice(-(cfg.imageMemoryRing || 6));
        }
        ['state', 'until', 'strikes', 'lastStrikeAt', 'modNote', 'byModId', 'modAt', 'recognized', 'bond', 'lifecycle', 'factsAt', 'factsBaseline', 'reflectImportanceAccum', 'consolidatedAt'].forEach(function (k) {
          if (base[k] == null && legacy[k] != null) base[k] = legacy[k];
        });
        return Promise.resolve(ustore.set(partKey(base.id), base)).then(function () {
          return ensureIndexed(base.id).then(function () {
            // converge: drop the legacy local copy (best-effort; a miss here just re-merges next time)
            return Promise.resolve(localRaw.del(partKey(base.id))).then(function () {
              if (typeof localRaw.removeFromIndex === 'function') return Promise.resolve(localRaw.removeFromIndex(base.id)).catch(function () {});
            }).catch(function () {});
          }).then(function () { return base; });
        });
      });
    }
    // Hot-partition load shared by live ingest + backfill: shared pool first, cold archive
    // second, pre-upgrade local partition last (converged into the pool on the way in).
    function loadPartition(id) {
      var ustore = userStore();
      return Promise.resolve(ustore.get(partKey(id))).then(function (hot) {
        if (hot) return hot;
        return restoreFromArchive(id).then(function (restored) {
          if (restored) return restored;
          if (!sharedUsers()) return null;
          return Promise.resolve(localRaw.get(partKey(id))).then(function (legacy) {
            if (!legacy) return null;
            return Promise.resolve(mergeLegacyPartition(legacy)).catch(function () { return legacy; });
          });
        });
      });
    }

    var running = false;
    var timer = null;

    // T1 reply state: a per-author queue (latest message per author) so one chatty user can't
    // starve replies to everyone else. A lost queue on reload is acceptable.
    var reply = { queue: {}, replying: false, startedAt: 0, epoch: 0, claim: null };   // startedAt/epoch: self-rescue reclaims a lock a dead promise holds forever; claim: the in-flight working-ack for the sweep
    var lastReplyAt = {};                // per-author: when it last replied to that person
    var lastLineId = null;               // most recent non-bot channel message id (forget-that fallback target)
    var lastPollIngested = false;        // activity-aware sweep: did the previous poll bring messages?
    var recentReplies = [];              // G1 anti-repetition: its own last few replies (PERSISTED per channel — see rememberReply)
    // Rehydrate the anti-repeat list from the channel-scoped store so a tab reload / engine restart doesn't make its
    // repeat its last phrasings. Best-effort + async: a reply before this resolves just sees an empty list that once.
    try { Promise.resolve(store.get('recentReplies')).then(function (v) { if (Array.isArray(v) && !recentReplies.length) recentReplies = v.slice(-(cfg.antiRepeatWindow || 5)); }, function (err) { log('[chloe.store] recentReplies rehydrate failed, starting empty (' + ((err && err.message) || err) + ')'); }); } catch (e) { log('[chloe.store] recentReplies rehydrate threw (' + ((e && e.message) || e) + ')'); }
    var consecutiveBotTurns = 0;         // bot-loop damper: human-authored messages reset this to 0
    var afkNoticed = {};                 // per-target throttle so an AFK heads-up doesn't repeat each ping
    var afkNoticedKeys = [];             // insertion order, to bound afkNoticed (prevent a slow leak over a long session)
    var lastSawHumanAt = 0;              // when a human last spoke here (observation, always updated)
    function noteAuthorForLoop(isBot) {
      if (isBot) consecutiveBotTurns++;
      else { consecutiveBotTurns = 0; lastSawHumanAt = clock.now(); }
    }
    // Reply probability decays as a channel becomes bot-only chatter, so two bots don't ping-pong
    // forever. 0..botLoopGrace bot turns: full chance. Beyond that, halve per extra turn, floored.
    // A human message resets consecutiveBotTurns, restoring full responsiveness immediately.
    function botLoopReplyChance() {
      var grace = cfg.botLoopGrace, hardStop = cfg.botLoopHardStop;
      if (consecutiveBotTurns <= grace) return 1;
      if (hardStop > 0 && consecutiveBotTurns >= hardStop) return 0;
      var over = consecutiveBotTurns - grace;
      return Math.max(cfg.botLoopFloor, Math.pow(0.5, over));
    }

    // ═══ CAMPAIGN item 1 — makeConverse: the SOCIAL GANGLION ported from rook-mesh/src/converse.js ═══════════════
    // (which was itself DISTILLED from chloe-bot, so this is the cleaner version ported BACK). PURE: inject `now`
    // and a `roll`. Four mechanisms: (1) bot-loop damper — speakChance halves per consecutive bot turn to a hard
    // ZERO floor, hard-stops at botLoopHardStop, resets on ANY human line; (2) addressing (forMe); (3) volunteer
    // prefilter (filler / own line / cooldown / anti-repeat / two OTHERS' exchange); (4) staggered turn-taking.
    // Parser-safe plain JS (no ESM, no bare {word}/[word] in string literals). See rook-mesh converse-test.mjs.
    var CONVERSE_FILLER = /^(lol+|lmao|haha+|ok(ay)?|k|yeah?|yep|nah|same|fr|true|nice|cool|hmm+|oh|ah|\W+)$/i;
    var CONVERSE_WORTH = /\?|\b(think|feel|should|maybe|why|how|what if|imo|honestly|anyone|help|idea|wonder)\b|!{1,}/i;
    function converseEscId(s) { return escRe(s); } // Rule S S2/R1: single regex-escape intent — was a byte-identical copy of escRe
    function makeConverse(opts) {
      opts = opts || {};
      var selfId = opts.selfId, selfName = opts.selfName || '', aliases = Array.isArray(opts.aliases) ? opts.aliases : [];
      var recentMax = opts.recentMax != null ? opts.recentMax : 30;
      var botLoopGrace = opts.botLoopGrace != null ? opts.botLoopGrace : 2;
      var botLoopFloor = opts.botLoopFloor != null ? opts.botLoopFloor : 0;
      var botLoopHardStop = opts.botLoopHardStop != null ? opts.botLoopHardStop : 6;
      var cooldownMs = opts.cooldownMs != null ? opts.cooldownMs : 8000;
      var antiRepeatWindow = opts.antiRepeatWindow != null ? opts.antiRepeatWindow : 6;
      var ambientChance = opts.ambientChance != null ? opts.ambientChance : 0.35;
      var botLoopDeterministic = !!opts.botLoopDeterministic;
      var turnGate = opts.turnGate || null;
      var names = [selfName].concat(aliases).filter(Boolean).map(function (s) { return String(s).toLowerCase(); });
      var log2 = [];                    // {id, name, text, ts, self, bot}  (log2: avoid shadowing the outer log())
      var consecutiveBotTurns = 0;      // converse's OWN counter (parallel to the engine's; resets on any human)
      var lastSelfSpokeAt = -Infinity;
      var ownRecent = [];
      function observe(e) {
        e = e || {};
        var text = String(e.text == null ? '' : e.text);
        var self = !!e.self, bot = (e.bot === undefined) ? true : !!e.bot;
        log2.push({ id: e.id, name: e.name || '', text: text, ts: e.ts || 0, self: self, bot: bot });
        while (log2.length > recentMax) log2.shift();
        if (self || bot) consecutiveBotTurns++; else consecutiveBotTurns = 0;   // any HUMAN line breaks the loop
        if (turnGate) { try { turnGate.note({ ts: e.ts || 0, bot: !!(self || bot) }); } catch (x) { log('[chloe.turn] turnGate.note failed (' + ((x && x.message) || x) + ')'); } }
        if (self) { lastSelfSpokeAt = e.ts || 0; ownRecent.push(text.toLowerCase().slice(0, 60)); while (ownRecent.length > antiRepeatWindow) ownRecent.shift(); }
      }
      function forMe(text) {
        var t = String(text || '');
        if (new RegExp('(^|\\W)@?(' + converseEscId(selfId) + ')(\\W|$)', 'i').test(t)) return 'ping';
        for (var i = 0; i < names.length; i++) { var n = names[i]; if (n && new RegExp('(^|\\b)' + converseEscId(n) + '(\\b|$)', 'i').test(t)) return 'name'; }
        return 'none';
      }
      function speakChance() {
        var c = consecutiveBotTurns;
        if (c >= botLoopHardStop) return 0;
        if (botLoopDeterministic) return c <= botLoopGrace ? 1 : 0;
        if (c <= botLoopGrace) return 1;
        return Math.max(botLoopFloor, Math.pow(0.5, c - botLoopGrace));
      }
      function isTwoPersonExchangeBetweenOthers() {
        var tail = log2.filter(function (e) { return !e.self; }).slice(-4);
        if (tail.length < 4) return false;
        var ids = []; tail.forEach(function (e) { if (ids.indexOf(e.id) < 0) ids.push(e.id); });
        return ids.length === 2 && ids.indexOf(selfId) < 0;
      }
      function prefilter(entry, now) {
        now = now || 0;
        if (!entry) return { skip: true, why: 'nothing' };
        if (entry.self) return { skip: true, why: 'my own line' };
        var t = String(entry.text || '').trim();
        if (t.length < 2 || CONVERSE_FILLER.test(t)) return { skip: true, why: 'filler' };
        if (consecutiveBotTurns >= botLoopHardStop) return { skip: true, why: 'bot-loop hard stop' };
        var selfGap = turnGate ? (function () { try { return turnGate.gapMs(now); } catch (x) { log('[chloe.turn] turnGate.gapMs failed, using cooldown fallback (' + ((x && x.message) || x) + ')'); return cooldownMs; } })() : cooldownMs;
        if (now - lastSelfSpokeAt < selfGap) return { skip: true, why: 'cooldown' };
        if (ownRecent.indexOf(t.toLowerCase().slice(0, 60)) >= 0) return { skip: true, why: 'anti-repeat' };
        if (isTwoPersonExchangeBetweenOthers()) return { skip: true, why: 'two others private exchange' };
        return { skip: false };
      }
      function decide(o) {
        o = o || {};
        var now = o.now || 0, roll = (o.roll != null) ? o.roll : 0.5, addressed = !!o.addressed;
        var newest = log2[log2.length - 1];
        if (!newest || newest.self) return { shouldSpeak: false, why: 'nothing new / just me' };
        var human = !newest.bot;
        var addr = addressed ? 'to' : forMe(newest.text);
        if (addr !== 'none') {
          if (consecutiveBotTurns >= botLoopHardStop) return { shouldSpeak: false, why: 'addressed but bot-loop hard stop' };
          return { shouldSpeak: true, addressee: newest.id, kind: addr, why: 'addressed to me', waitMs: 300 + Math.floor(roll * 500) };
        }
        var pf = prefilter(newest, now);
        if (pf.skip && !(human && pf.why === 'cooldown')) return { shouldSpeak: false, why: pf.why };   // a person talking to the room deserves an answer even if I just spoke
        var worth = human || CONVERSE_WORTH.test(newest.text);
        var chance = speakChance();
        if (!worth) chance *= ambientChance;
        if (roll > chance) return { shouldSpeak: false, why: 'damped (chance ' + chance.toFixed(2) + (worth ? '' : ' ambient') + ')' };
        var waitMs = human ? 400 + Math.floor(roll * 600) : 700 + Math.floor(roll * (1200 + consecutiveBotTurns * 400));
        return { shouldSpeak: true, addressee: 'all', kind: human ? 'answer-human' : 'volunteer', why: human ? 'a person spoke to the room' : 'worth chiming in', waitMs: waitMs };
      }
      function noteSelfSpoke(now, text) { observe({ id: selfId, name: selfName, text: text || '', ts: now || 0, self: true, bot: true }); }
      return {
        observe: observe, forMe: forMe, prefilter: prefilter, speakChance: speakChance, decide: decide,
        noteSelfSpoke: noteSelfSpoke, isTwoPersonExchangeBetweenOthers: isTwoPersonExchangeBetweenOthers,
        botTurns: function () { return consecutiveBotTurns; },
        recent: function (n) { return log2.slice(-(n || 8)); },
        stats: function () { return { logged: log2.length, consecutiveBotTurns: consecutiveBotTurns, chance: +speakChance().toFixed(2) }; }
      };
    }
    // per-engine instance. Addressing is intentionally left to Chloe's Discord-mention isAddressed (converse gets
    // NO name/aliases, so converse.forMe never fires on plain text — Chloe's `addressed` override is the authority).
    var converse = makeConverse({
      selfId: cfg.botUserId || 'chloe',
      botLoopGrace: cfg.botLoopGrace, botLoopFloor: cfg.botLoopFloor, botLoopHardStop: cfg.botLoopHardStop,
      cooldownMs: cfg.cooldownMs, antiRepeatWindow: cfg.antiRepeatWindow
    });

    function rememberReply(text) {
      var t = String(text || '').trim();
      if (!t) return;
      if (converse && cfg.converseEngine) { try { converse.noteSelfSpoke(clock.now(), t); } catch (e) { log('[wire:converse] noteSelfSpoke threw', (e && e.message) || e); } }   // feed converse's self-cooldown + anti-repeat
      recentReplies.push(t);
      var keep = cfg.antiRepeatWindow || 5;
      if (recentReplies.length > keep) recentReplies = recentReplies.slice(-keep);
      try { store.set('recentReplies', recentReplies.slice()); } catch (e) { log('[chloe.store] recentReplies persist failed (' + ((e && e.message) || e) + ')'); }   // persist so a reload doesn't lose the anti-repeat list
    }
    // Standing intention: the brain may return `intent` alongside its reply text; we persist it
    // (capped + timestamped) so it rides in the next context until reaffirmed or it ages out.
    function setIntent(text) {
      var t = String(text || '').trim().slice(0, cfg.intentMaxLen);
      if (!t) return Promise.resolve(null);
      return Promise.resolve(store.set(INTENT_KEY, { text: t, at: clock.now() })).then(function () { return t; });
    }
    function getIntent() {
      return Promise.resolve(store.get(INTENT_KEY)).then(function (gi) {
        if (gi && gi.text && (clock.now() - (gi.at || 0) < cfg.intentTtlMs)) return gi;
        return null;
      });
    }
    function clearIntent() { return Promise.resolve(store.del(INTENT_KEY)); }

    // ---- goal objects (prospective memory) -------------------------------------------------
    function loadGoals() {
      return Promise.resolve(goalStore().get(GOALS_KEY)).then(function (g) { return Array.isArray(g) ? g : []; });
    }
    function saveGoals(list) {
      // newest-first cap: keep all OPEN goals, evict oldest CLOSED beyond the cap
      if (list.length > (cfg.goalsMax || 40)) {
        var open = list.filter(function (x) { return x.status === 'open'; });
        var closed = list.filter(function (x) { return x.status !== 'open'; }).sort(function (a, b) { return (b.lastTouchedAt || 0) - (a.lastTouchedAt || 0); });
        list = open.concat(closed).slice(0, cfg.goalsMax || 40);
      }
      return Promise.resolve(goalStore().set(GOALS_KEY, list)).then(function () { return list; });
    }
    function addGoal(text, owner, ownerName, source) {
      var t = String(text || '').trim().slice(0, cfg.goalTextMax || 140);
      if (!t) return Promise.resolve(null);
      return loadGoals().then(function (list) {
        var norm = normFact(t);
        var dup = list.filter(function (x) { return x.status === 'open' && x.owner === (owner || null) && normFact(x.text) === norm; })[0];
        if (dup) { dup.lastTouchedAt = clock.now(); return saveGoals(list).then(function () { return dup; }); }
        var g = { id: 'g' + clock.now().toString(36) + Math.floor(Math.random() * 1000).toString(36),
                  text: t, owner: owner || null, ownerName: ownerName || '', channel: cfg.channelId,
                  createdAt: clock.now(), lastTouchedAt: clock.now(), status: 'open', source: source || 'command' };
        list.push(g);
        return saveGoals(list).then(function () { log('[chloe.goal] noted a goal for ' + (ownerName || 'the channel') + ': \u201c' + t + '\u201d'); return g; });
      });
    }
    function closeGoal(id, byId, status) {
      return loadGoals().then(function (list) {
        var g = list.filter(function (x) { return x.id === id; })[0];
        if (!g) return { ok: false, reason: 'no goal with that id' };
        if (g.owner && byId && g.owner !== byId && !isMod(byId)) return { ok: false, reason: 'only the goal\u2019s owner or a mod can close it' };
        g.status = status || 'done'; g.lastTouchedAt = clock.now();
        return saveGoals(list).then(function () { return { ok: true, goal: g }; });
      });
    }
    function goalsForOwner(ownerId) {
      return loadGoals().then(function (list) {
        var now = clock.now(), changed = false;
        list.forEach(function (g) {   // lazy staleness: open goals untouched too long fade to dropped
          if (g.status === 'open' && (now - (g.lastTouchedAt || g.createdAt || 0)) > (cfg.goalStaleMs || 2592000000)) { g.status = 'dropped'; g.lastTouchedAt = now; changed = true; }
        });
        var out = list.filter(function (g) { return g.status === 'open' && g.owner === ownerId; });
        return (changed ? saveGoals(list) : Promise.resolve(list)).then(function () { return out; });
      });
    }
    function dropGoalsFor(id) {
      if (!id) return Promise.resolve(0);
      return loadGoals().then(function (list) {
        var before = list.length;
        var kept = list.filter(function (g) { return g.owner !== id; });
        if (kept.length === before) return 0;
        return saveGoals(kept).then(function () { log('[chloe.goal] erased ' + (before - kept.length) + ' goal(s) for a forgotten user'); return before - kept.length; });
      });
    }

    // ---- character self-memory (respooled from an imported character's chat) ----------------
    // Background context about WHO SHE IS now (the imported character) and their world — not facts
    // about a person. Stored cross-channel, deduped, capped; surfaced as a SELF band injection.
    function seedCharacterMemories(name, mems) {
      var texts = (mems || []).map(function (m) { return String(m && m.text != null ? m.text : m).trim(); }).filter(Boolean);
      if (!texts.length) return Promise.resolve(0);
      return Promise.resolve(crossStore().get(CHARMEM_KEY)).then(function (rec) {
        rec = rec || { name: name, facts: [] };
        rec.name = name;
        var seen = {}; rec.facts.forEach(function (f) { seen[normFact(f)] = true; });
        var added = 0;
        texts.forEach(function (t) { var k = normFact(t); if (k && !seen[k]) { seen[k] = true; rec.facts.push(t.slice(0, 200)); added++; } });
        var cap = (cfg.characterMemoryMax || 24);
        if (rec.facts.length > cap) rec.facts = rec.facts.slice(-cap);
        return crossStore().set(CHARMEM_KEY, rec).then(function () { log('[chloe.character] seeded ' + added + ' memor' + (added === 1 ? 'y' : 'ies') + ' for ' + name); return added; });
      });
    }
    function clearCharacterMemories() { return Promise.resolve(crossStore().del(CHARMEM_KEY)); }
    // Rule S S2/R3: single tolerant array-read — getReminders/getSelfIntents/getTodos/
    // getSkills/getHighlights carried the same Array.isArray-guard (corrupt → []).
    function getStoredArray(key) { return Promise.resolve(store.get(key)).then(function (v) { return Array.isArray(v) ? v : []; }); }
    // Rule S S4/R1: single provider-content shape — the {text,tokens} return the
    // assembler reads. Eight gather sites carried the same object literal.
    function textTokens(text) { return { text: text, tokens: estimateTokens(text) }; }
    // Rule S S4/R2: single raw-args normalization — seven verb handlers carried the
    // same null-safe trim+lower. The three unguarded String(c.rawArgs||'') sites stay
    // (different null behavior — Rule O, same class as the releaseSend ramp).
    function normArg(c) { return String((c && c.rawArgs) || '').trim().toLowerCase(); }

    // ---- reminders (poll-driven, front-end only, no AI call) --------------------------------
    function getReminders() { return getStoredArray(REMIND_KEY); }
    function scheduleReminder(opts) {
      var minutes = Number(opts && opts.minutes);
      if (!isFinite(minutes) || minutes < 1) return Promise.resolve({ ok: false, reason: 'minutes must be at least 1' });
      if (minutes > (cfg.jobMaxReminderMin || 1440)) return Promise.resolve({ ok: false, reason: 'reminders are capped at ' + (cfg.jobMaxReminderMin || 1440) + ' minutes' });
      var text = String((opts && opts.text) || '').trim().slice(0, cfg.reminderTextMax);
      if (!text) return Promise.resolve({ ok: false, reason: 'a reminder needs some text' });
      return getReminders().then(function (list) {
        if (list.length >= cfg.reminderMaxTotal) return { ok: false, reason: "i'm holding too many reminders right now \u2014 try again later" };
        var mine = list.filter(function (r) { return r.authorId === opts.authorId; });
        if (mine.length >= cfg.reminderMaxPerUser) return { ok: false, reason: "you've already got " + mine.length + ' reminders pending with me \u2014 that\u2019s my limit per person' };
        var fireAt = clock.now() + minutes * 60000;
        var rem = { id: 'r' + clock.now() + '_' + Math.floor(Math.random() * 1e6), authorId: opts.authorId, authorName: opts.authorName || '', text: text, fireAt: fireAt, dm: !!opts.dm, setAt: clock.now() };
        list.push(rem);
        return Promise.resolve(store.set(REMIND_KEY, list)).then(function () { return { ok: true, value: rem }; });
      });
    }
    // ---- deferred self-intents (DESIGN-self-intents) -------------------------------------------
    // The same dueAt-queue shape as reminders, but a fired intent is an INTERNAL action, never a send.
    // Entry: { id, kind, dueAt, subject, mode, createdAt }. Today the only kind is 'revisit' (come back
    // and re-think a deliberation subject later); the dispatch is built so new kinds are a new branch.
    function getSelfIntents() { return getStoredArray(SELFINTENT_KEY); }
    function scheduleSelfIntent(kind, delayMs, fields) {
      if (!cfg.deferredIntents) return Promise.resolve(null);
      return getSelfIntents().then(function (list) {
        // de-dupe: don't stack multiple pending intents of the same kind+subject
        var subj = fields && fields.subject;
        if (list.some(function (it) { return it.kind === kind && it.subject === subj; })) return null;
        if (list.length >= (cfg.selfIntentMax || 8)) return null;   // bounded; silently drop rather than grow
        var it = { id: 's' + clock.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36), kind: kind, dueAt: clock.now() + Math.max(0, delayMs | 0), createdAt: clock.now() };
        if (fields) for (var k in fields) if (fields.hasOwnProperty(k)) it[k] = fields[k];
        list.push(it);
        return Promise.resolve(store.set(SELFINTENT_KEY, list)).then(function () { log('[chloe.intent] scheduled "' + kind + '"' + (subj ? ' re: ' + String(subj).slice(0, 40) : '') + ' in ' + Math.round((delayMs || 0) / 60000) + 'm'); return it; });
      });
    }
    // Peek the earliest DUE intent of a kind (does not remove it).
    function dueSelfIntent(kind) {
      if (!cfg.deferredIntents) return Promise.resolve(null);
      return getSelfIntents().then(function (list) {
        var now = clock.now();
        var due = list.filter(function (it) { return it.kind === kind && it.dueAt <= now; });
        due.sort(function (a, b) { return a.dueAt - b.dueAt; });
        return due[0] || null;
      });
    }
    function consumeSelfIntent(id) {
      return getSelfIntents().then(function (list) {
        var keep = list.filter(function (it) { return it.id !== id; });
        if (keep.length === list.length) return false;
        return Promise.resolve(store.set(SELFINTENT_KEY, keep)).then(function () { return true; });
      });
    }

    function listReminders(authorId) {
      return getReminders().then(function (list) { return authorId ? list.filter(function (r) { return r.authorId === authorId; }) : list; });
    }
    function clearReminders(authorId) {
      return getReminders().then(function (list) {
        var kept = authorId ? list.filter(function (r) { return r.authorId !== authorId; }) : [];
        var removed = list.length - kept.length;
        return Promise.resolve(store.set(REMIND_KEY, kept)).then(function () { return removed; });
      });
    }
    // ---- todos (channel-local personal checklists, same store-list shape as reminders) ----
    // Entry: { id, authorId, authorName, text, at }. No due dates — a todo waits until the
    // person asks. Bounded per author + text cap, same manners as reminders.
    function getTodos() { return getStoredArray(TODO_KEY); }
    function addTodo(authorId, authorName, text) {
      var clean = String(text || '').trim().slice(0, (cfg.todoTextMax || 140));
      if (!clean) return Promise.resolve({ ok: false, reason: 'a todo needs some text' });
      return getTodos().then(function (list) {
        var mine = list.filter(function (t) { return t.authorId === authorId; });
        if (mine.length >= (cfg.todoMaxPerUser || 20)) return { ok: false, reason: 'you have ' + mine.length + ' todos with me already — that is my limit per person' };
        var it = { id: 't' + clock.now() + '_' + Math.floor(Math.random() * 1e6), authorId: authorId, authorName: authorName || '', text: clean, at: clock.now() };
        list.push(it);
        return Promise.resolve(store.set(TODO_KEY, list)).then(function () { return { ok: true, value: it }; });
      });
    }
    function listTodos(authorId) {
      return getTodos().then(function (list) { return authorId ? list.filter(function (t) { return t.authorId === authorId; }) : list; });
    }
    function doneTodo(authorId, index) {
      return getTodos().then(function (list) {
        var mine = list.filter(function (t) { return t.authorId === authorId; });
        var n = Number(index);
        if (!isFinite(n) || n < 1 || n > mine.length) return { ok: false, removed: 0, reason: mine.length ? ('pick a number 1-' + mine.length) : 'you have no todos' };
        var target = mine[n - 1], removed = null;
        var kept = list.filter(function (t) { if (!removed && t.id === target.id) { removed = t; return false; } return true; });
        return Promise.resolve(store.set(TODO_KEY, kept)).then(function () { return { ok: true, removed: removed }; });
      });
    }
    function clearTodos(authorId) {
      return getTodos().then(function (list) {
        var kept = authorId ? list.filter(function (t) { return t.authorId !== authorId; }) : [];
        var removed = list.length - kept.length;
        return Promise.resolve(store.set(TODO_KEY, kept)).then(function () { return removed; });
      });
    }
    // ---- skills (server knowledge packs, mod-managed, auto-injected on trigger match) ----
    // Entry: { id, name, triggers[], text, by, at }. Matched by the RECALL provider below;
    // managed by the `skill`/`skills` chat commands (mods only for writes).
    function getSkills() { return getStoredArray(SKILL_KEY); }
    function addSkill(name, triggers, text, by) {
      var nm = String(name || '').trim().slice(0, 40);
      var tx = String(text || '').trim().slice(0, 800);
      var tr = String(triggers || '').toLowerCase().split(',').map(function (t) { return t.trim(); }).filter(Boolean).slice(0, 10);
      if (!nm) return Promise.resolve({ ok: false, reason: 'a skill needs a name' });
      if (!tr.length) return Promise.resolve({ ok: false, reason: 'give it trigger words (comma-separated)' });
      if (!tx) return Promise.resolve({ ok: false, reason: 'a skill needs some text' });
      return getSkills().then(function (list) {
        var at = -1;
        list.forEach(function (s, k) { if (String(s.name || '').toLowerCase() === nm.toLowerCase()) at = k; });
        if (list.length >= 20 && at < 0) return { ok: false, reason: 'twenty skills is my limit' };
        var rec = { id: 'k' + clock.now(), name: nm, triggers: tr, text: tx, by: by || '', at: clock.now() };
        if (at >= 0) list[at] = rec; else list.push(rec);
        return Promise.resolve(store.set(SKILL_KEY, list)).then(function () { return { ok: true, value: rec, updated: at >= 0 }; });
      });
    }
    function dropSkill(name) {
      var nm = String(name || '').trim().toLowerCase();
      return getSkills().then(function (list) {
        var kept = list.filter(function (s) { return String(s.name || '').toLowerCase() !== nm; });
        var n = list.length - kept.length;
        return Promise.resolve(store.set(SKILL_KEY, kept)).then(function () { return n; });
      });
    }
    // Called each poll. Fires any reminder whose time has come, delivers it (channel or DM), and
    // removes it. Delivery is a plain send — it doesn't consume the reply budget or judge path,
    // because the person explicitly asked for it at this time; it's a utility, not its "voice".
    function processReminders() {
      if (typeof cfg.send !== 'function') return Promise.resolve(null);
      return getReminders().then(function (list) {
        if (!list.length) return null;
        var now = clock.now(), due = [], keep = [];
        list.forEach(function (r) { (r.fireAt <= now ? due : keep).push(r); });
        if (!due.length) return null;
        return Promise.resolve(store.set(REMIND_KEY, keep)).then(function () {
          var chain = Promise.resolve(), fired = [];
          due.forEach(function (r) {
            chain = chain.then(function () {
              var who = r.authorName || 'you';
              var body = '\u23f0 ' + (r.authorId ? '<@' + r.authorId + '> ' : '') + 'reminder: ' + r.text;
              var target = Promise.resolve(cfg.channelId);
              if (r.dm && typeof cfg.openDM === 'function') target = Promise.resolve(cfg.openDM(r.authorId)).then(function (id) { return id || cfg.channelId; }, function () { return cfg.channelId; });
              return target.then(function (chId) {
                return Promise.resolve(cfg.send(chId, body)).then(function () { fired.push(r.id); log('[chloe.remind] fired for ' + who + (r.dm ? ' (dm)' : '') + ': ' + r.text.slice(0, 40)); }, function (e) {
                  // v0.90.18: this used to swallow the failure after the reminder was
                  // already removed from the store — a 403/429 at fire time meant the
                  // reminder vanished with no trace. Retry with backoff, give up loudly.
                  var tries = (r.tries || 0) + 1;
                  log('[chloe.remind] delivery failed for ' + who + ' (attempt ' + tries + '): ' + ((e && e.message) || e));
                  if (tries >= 3) { log('[chloe.remind] dropping reminder after 3 failed deliveries: ' + String(r.text || '').slice(0, 80)); return; }
                  r.tries = tries; r.fireAt = clock.now() + 60000;
                  return getReminders().then(function (list) { list.push(r); return store.set(REMIND_KEY, list); }).then(function () { log('[chloe.remind] re-queued for retry in ~1m'); }, function (e2) { log('[chloe.remind] re-queue failed, reminder lost: ' + ((e2 && e2.message) || e2)); });
                });
              });
            });
          });
          return chain.then(function () { return { fired: fired.length }; });
        });
      });
    }

    // ---- AFK / away state (front-end only, no AI call) --------------------------------------
    function getAfkMap() { return Promise.resolve(store.get(AFK_KEY)).then(function (a) { return (a && typeof a === 'object') ? a : {}; }); }
    function setAfk(userId, name, reason) {
      return getAfkMap().then(function (map) {
        map[userId] = { name: name || '', reason: String(reason || '').trim().slice(0, 200), since: clock.now() };
        return Promise.resolve(store.set(AFK_KEY, map)).then(function () { return map[userId]; });
      });
    }
    function getAfk(userId) { return getAfkMap().then(function (map) { return map[userId] || null; }); }
    // Clear a user's AFK if set. Returns the prior entry (so the caller can say "welcome back"), or
    // null if they weren't away.
    function clearAfk(userId) {
      return getAfkMap().then(function (map) {
        var prior = map[userId] || null;
        if (!prior) return null;
        delete map[userId];
        return Promise.resolve(store.set(AFK_KEY, map)).then(function () { return prior; });
      });
    }
    function humanGap(ms) {
      var mn = Math.round(ms / 60000);
      if (mn < 1) return 'less than a minute';
      if (mn < 60) return mn + ' minute' + (mn === 1 ? '' : 's');
      var h = Math.round(mn / 60);
      if (h < 24) return h + ' hour' + (h === 1 ? '' : 's');
      var d = Math.round(h / 24); return d + ' day' + (d === 1 ? '' : 's');
    }
    // Cap multi-line acks at whole lines (never cut mid-line like slice() does).
    function clipLines(text, max) {
      text = String(text || '');
      if (text.length <= max) return text;
      var cut = text.slice(0, max).replace(/\n[^\n]*$/, '');
      return cut || text.slice(0, max);
    }

    // ---- highlights (front-end only, no AI call) --------------------------------------------
    function getHighlights() { return getStoredArray(HILITE_KEY); }
    // Save a notable message. `src` carries the captured message ({ text, authorName }) — usually the
    // replied-to message, or a manual quote. Returns { ok, value } or { ok:false, reason }.
    function addHighlight(src, savedBy, savedByName, note) {
      var text = scrubDiscordTokens(String((src && src.text) || '')).trim().slice(0, cfg.highlightTextMax);
      if (!text) return Promise.resolve({ ok: false, reason: 'nothing to highlight \u2014 reply to a message or quote some text' });
      return getHighlights().then(function (list) {
        var rec = { id: 'h' + clock.now() + '_' + Math.floor(Math.random() * 1e6), text: text,
          authorName: (src && src.authorName) || '', savedBy: savedBy, savedByName: savedByName || '',
          note: String(note || '').trim().slice(0, 200), at: clock.now() };
        list.push(rec);
        if (list.length > cfg.highlightMax) list = list.slice(-cfg.highlightMax);   // drop oldest
        return Promise.resolve(store.set(HILITE_KEY, list)).then(function () { return { ok: true, value: rec }; });
      });
    }
    function listHighlights(n) { return getHighlights().then(function (list) { return n ? list.slice(-n) : list; }); }
    function clearHighlights() { return getHighlights().then(function (list) { var c = list.length; return Promise.resolve(store.set(HILITE_KEY, [])).then(function () { return c; }); }); }

    // ---- reaction significance (size-relative) ----------------------------------------------
    // A raw reaction count is meaningless without the room size: 2 reactions in a 50-person server is
    // a strong signal; 2 in a 5000-person server is noise. The threshold scales with member count
    // (with a floor), so significance is relative. memberCount 0 => unknown => floor only.
    function reactionThreshold(memberCount) {
      var floor = cfg.reactionMinUsers || 2;
      if (!memberCount || memberCount <= 0) return floor;
      return Math.max(floor, Math.ceil(memberCount * (cfg.reactionFraction || 0.01)));
    }
    function reactionSignificance(count, memberCount) {
      var threshold = reactionThreshold(memberCount);
      return { significant: count >= threshold, threshold: threshold, score: threshold ? (count / threshold) : 0 };
    }
    function emojiKey(emoji) {
      if (!emoji) return '';
      return emoji.id ? (String(emoji.name || 'custom') + ':' + emoji.id) : String(emoji.name || '');
    }
    function emojiLabel(emoji) { return emoji ? String(emoji.name || 'reaction') : 'reaction'; }
    // Compact reaction summary for the volunteer gate: [{ e, n, me }] capped at 5,
    // so the judge sees what's already on a candidate (pile-on + self guards).
    function summarizeReactions(msg) {
      var arr = (msg && Array.isArray(msg.reactions)) ? msg.reactions : [];
      var out = [];
      for (var i = 0; i < arr.length && out.length < 5; i++) {
        var r = arr[i]; if (!r || !r.emoji) continue;
        var nm = r.emoji.id ? (String(r.emoji.name || 'custom') + ':' + r.emoji.id) : String(r.emoji.name || '');
        if (!nm) continue;
        out.push({ e: nm, n: Math.max(0, Number(r.count) || 0), me: !!r.me });
      }
      return out;
    }
    // Running per-emoji tally for the channel: how often each reaction shows up on significant
    // messages, so Chloe knows which reactions this room actually values.
    function bumpReactionTally(emoji, by) {
      return Promise.resolve(store.get(REACTTALLY_KEY)).then(function (t) {
        t = (t && typeof t === 'object') ? t : {};
        var k = emojiKey(emoji); if (!k) return null;
        t[k] = { label: emojiLabel(emoji), count: (t[k] ? t[k].count : 0) + (by || 1), last: clock.now() };
        var keys = Object.keys(t);
        if (keys.length > cfg.reactionTallyMax) {   // keep the most-used
          keys.sort(function (a, b) { return t[b].count - t[a].count; }).slice(cfg.reactionTallyMax).forEach(function (k2) { delete t[k2]; });
        }
        return store.set(REACTTALLY_KEY, t);
      });
    }
    function topReactions(n) {
      return Promise.resolve(store.get(REACTTALLY_KEY)).then(function (t) {
        t = (t && typeof t === 'object') ? t : {};
        return Object.keys(t).map(function (k) { return { key: k, label: t[k].label, count: t[k].count }; })
          .sort(function (a, b) { return b.count - a.count; }).slice(0, n || 10);
      });
    }
    // Examine one message's reactions. If the top reaction is significant for this server size, tally
    // it and (optionally) auto-highlight the message. Deduped per message id so re-seeing the same
    // message (e.g. a reaction sweep) doesn't double-count or re-highlight. Returns a small summary.
    var reactionSeen = {};   // messageId -> highest significant count already handled
    var reactionSeenKeys = [];   // insertion order, to bound reactionSeen (prevent a slow leak over a long session)
    // Reaction sweep: reactions are often added AFTER a message scrolls past the poll cursor, so we
    // can't see them on the normal ?after= fetch. Periodically re-fetch a recent window (no cursor)
    // and re-score — processMessageReactions only acts on an INCREASED count, so this is idempotent.
    function reactionSweep() {
      if (!cfg.reactionTracking || typeof cfg.recentFetch !== 'function') return Promise.resolve(0);
      return Promise.resolve(cfg.recentFetch(30)).then(function (msgs) {
        msgs = (msgs || []).filter(function (m) { return m && m.reactions && m.reactions.length; });
        var chain = Promise.resolve(), hits = 0;
        msgs.forEach(function (m) { chain = chain.then(function () { return processMessageReactions(m).then(function (r) { if (r) hits++; }); }); });
        return chain.then(function () { return hits; });
      }, function () { return 0; });
    }
    var trustReactSeen = {};   // msgId+emoji -> count already credited (bounded)
    var trustReactKeys = [];
    // ---- feedback / preference learning state (DESIGN-feedback) ----
    var fbReactSeen = {}, fbReactKeys = [];   // msgId+emoji already scored for style feedback (bounded, idempotent across sweeps)
    var fbPending = [];        // its recent replies awaiting a continuation signal: {style, who, at, done}
    var lastReplyStyle = null; // style of its most recent reply here (for !chloe good/bad)
    // The two style "arms": length bucket and tone bucket of a reply. Cheap, computed from the text.
    function styleOf(text) {
      var t = String(text || ''); var n = t.length;
      var len = n < 120 ? 'short' : (n > 400 ? 'long' : 'med');
      var playful = /[\u2190-\u21ff\u2600-\u27bf\u2b00-\u2bff]/.test(t) || /\ud83c[\udc00-\udfff]|\ud83d[\udc00-\udfff]|\ud83e[\udc00-\udfff]/.test(t) || /(^|\s)(lol|haha|hehe|omg|yay|haha)\b|!|:\)|:d\b|\bxd\b/i.test(t);
      return { len: len, tone: playful ? 'playful' : 'measured' };
    }
    // EWMA update: each arm holds a running reward r in [-1,1] and a sample count n. reward is the signal.
    function recordFeedback(style, reward) {
      if (!cfg.feedbackLearning || !style) return Promise.resolve(null);
      return Promise.resolve(store.get(FEEDBACK_KEY)).then(function (fb) {
        fb = (fb && fb.len && fb.tone) ? fb : { len: {}, tone: {}, at: 0 };
        var a = cfg.feedbackAlpha || 0.3;
        function upd(dim, bucket) { var cur = dim[bucket] || { r: 0, n: 0 }; cur.r = cur.r + a * (reward - cur.r); cur.n = (cur.n || 0) + 1; dim[bucket] = cur; }
        upd(fb.len, style.len); upd(fb.tone, style.tone); fb.at = clock.now();
        return store.set(FEEDBACK_KEY, fb);
      });
    }
    // A person kept talking after its reply -> soft positive to that reply's style (engagement reward).
    // Never penalizes silence (someone going offline isn't negative feedback).
    function creditContinuation(humans) {
      if (!cfg.feedbackLearning || !fbPending.length || !humans || !humans.length) return Promise.resolve(null);
      var win = cfg.feedbackContinuationWindowMs || 600000, rew = cfg.feedbackContinuationReward || 0.3;
      var chain = Promise.resolve();
      humans.forEach(function (m) {
        var uid = m && m.author && m.author.id; if (!uid) return;
        var ts = snowflakeTime(m.id) || clock.now();
        for (var i = 0; i < fbPending.length; i++) {
          var pe = fbPending[i];
          if (!pe.done && pe.who === uid && ts > pe.at && (ts - pe.at) <= win) { pe.done = true; (function (st) { chain = chain.then(function () { return recordFeedback(st, rew); }); })(pe.style); break; }
        }
      });
      // prune credited / aged-out entries
      var cutoff = clock.now() - win;
      fbPending = fbPending.filter(function (pe) { return !pe.done && pe.at >= cutoff; });
      return chain;
    }
    function creditPositiveReactions(msg) {
      if (!cfg.relationshipTrust || typeof cfg.reactionUsers !== 'function') return Promise.resolve(0);
      if (!msg || !msg.author || msg.author.id !== cfg.botUserId || !msg.reactions || !msg.reactions.length) return Promise.resolve(0);
      var pos = cfg.trustPositiveEmoji || [];
      var chain = Promise.resolve(), credited = 0;
      msg.reactions.forEach(function (r) {
        var name = r && r.emoji && (r.emoji.name || '');
        if (pos.indexOf(name) < 0) return;                       // positive set only — never penalize
        var key = msg.id + '|' + name;
        var prior = trustReactSeen[key] || 0;
        var count = r.count || 0;
        if (count <= prior) return;                              // idempotent across sweeps
        trustReactSeen[key] = count;
        trustReactKeys.push(key);
        if (trustReactKeys.length > 500) { var oldk = trustReactKeys.shift(); delete trustReactSeen[oldk]; }
        chain = chain.then(function () {
          return Promise.resolve(cfg.reactionUsers(msg.id, name)).then(function (users) {
            var c2 = Promise.resolve();
            (users || []).forEach(function (u) {
              if (!u || !u.id || u.id === cfg.botUserId) return;
              c2 = c2.then(function () { return addTrust(u.id, cfg.trustReactionGain || 2).then(function (did) { if (did) credited++; }); });
            });
            return c2;
          }, function (e) { log('[chloe.react] trust reaction-users failed for ' + msg.id + ': ' + ((e && e.message) || e)); return null; });   // a failed fetch credits nothing (now traced)
        });
      });
      return chain.then(function () { if (credited) log('[chloe.trust] credited ' + credited + ' positive reaction(s)'); return credited; });
    }
    function processMessageReactions(msg) {
      if (!cfg.reactionTracking || !msg || !msg.reactions || !msg.reactions.length) return Promise.resolve(null);
      // Trust crediting is independent of significance but JOINED to the returned promise, so
      // sweeps complete deterministically (no fire-and-forget writes racing the poll summary).
      var pos = cfg.trustPositiveEmoji || [];
      var isSelf = msg.author && msg.author.id === cfg.botUserId;
      var hasPositive = isSelf && (msg.reactions || []).some(function (r) { return r && r.emoji && pos.indexOf(r.emoji.name || '') >= 0 && (r.count || 0) > 0; });
      var affectChain = hasPositive ? affectNudge({ confidence: (cfg.affectGain || 0.08), warmth: (cfg.affectGain || 0.08) }) : Promise.resolve(null);
      // DESIGN-feedback: a reaction on HER message is a free quality signal for the reply's STYLE.
      // Positives reuse the trust set; negatives are a small explicit set. Counted once per emoji/msg.
      var fbChain = Promise.resolve(null);
      if (cfg.feedbackLearning && isSelf) {
        var neg = cfg.feedbackNegativeEmoji || [], posHit = 0, negHit = 0;
        (msg.reactions || []).forEach(function (r) {
          var nm = r && r.emoji && (r.emoji.name || ''); if (!nm) return;
          var key = msg.id + '|' + nm, prior = fbReactSeen[key] || 0, cnt = r.count || 0;
          if (cnt <= prior) return;
          if (pos.indexOf(nm) >= 0) { posHit++; } else if (neg.indexOf(nm) >= 0) { negHit++; } else return;
          fbReactSeen[key] = cnt; fbReactKeys.push(key);
          if (fbReactKeys.length > 500) { var ok2 = fbReactKeys.shift(); delete fbReactSeen[ok2]; }
        });
        var valence = posHit > negHit ? 1 : (negHit > posHit ? -1 : 0);
        if (valence !== 0) fbChain = recordFeedback(styleOf(msg.content), valence);
      }
      return affectChain.then(function () { return fbChain; }).then(function () { return creditPositiveReactions(msg); }).then(function () { return procCheckReactions(msg); }).then(function () { return summonCheckReactions(msg); }).then(function () { return scoreMessageReactions(msg); });
    }
    function scoreMessageReactions(msg) {
      var top = null;
      msg.reactions.forEach(function (r) { if (!top || (r.count || 0) > top.count) top = { emoji: r.emoji, count: r.count || 0 }; });
      if (!top) return Promise.resolve(null);
      var sig = reactionSignificance(top.count, cfg.serverMemberCount);
      if (!sig.significant) return Promise.resolve(null);
      var prior = reactionSeen[msg.id] || 0;
      if (top.count <= prior) return Promise.resolve(null);   // already handled this (or a higher) count
      reactionSeen[msg.id] = top.count;
      reactionSeenKeys.push(msg.id);
      if (reactionSeenKeys.length > 500) { var old = reactionSeenKeys.shift(); delete reactionSeen[old]; }   // bound the in-memory dedup map
      var delta = top.count - prior;
      log('[chloe.react] significant reaction ' + emojiLabel(top.emoji) + ' x' + top.count + ' (threshold ' + sig.threshold + ') on ' + msg.id);
      return bumpReactionTally(top.emoji, delta).then(function () {
        if (!cfg.reactionAutoHighlight || prior > 0) return { emoji: emojiLabel(top.emoji), count: top.count, highlighted: false };
        var src = { text: msg.content || '', authorName: (msg.author && msg.author.username) || '' };
        if (!String(src.text).trim()) return { emoji: emojiLabel(top.emoji), count: top.count, highlighted: false };
        return addHighlight(src, 'reactions', '', emojiLabel(top.emoji) + ' \u00d7' + top.count).then(function () {
          return { emoji: emojiLabel(top.emoji), count: top.count, highlighted: true };
        });
      });
    }
    var gate = { pending: null };        // T2 volunteer candidate (latest un-addressed msg)
    var greet = { pending: null, greeting: false };  // T5 greeting candidate (settling-debounced)
    var paint = { queue: [], painting: false, lastJob: null, startedAt: 0, claim: null };  // global image FIFO; one in flight at a time (startedAt: paint-lock watchdog; claim: in-flight ack for the sweep)
    var lastPaintAt = 0;                 // last image delivery (image clock — independent of the text clock)
    var engageMode = (cfg.engageMode === 'locked' || cfg.engageMode === 'open') ? cfg.engageMode : 'normal';
    var lastCmdAt = {};                  // per-command last-run clock (for entry.cooldownMs)
    var lastActAt = 0;                   // global last-action clock (light global gap + volunteer cooldown)
    var startedAt = 0;                   // when the loop started (drives the greeting settle window)
    var startupPending = true;           // the first poll after start handles a history backlog specially (image clamp)
    var lastSeenAt = 0;                  // ms (UTC) of the newest message seen, derived from its snowflake id — an authoritative Discord-server clock used to ground time and as a device-clock fallback
    var pollCount = 0;                   // drives the periodic quiet-sweep cadence
    var warnedEmpty = false;             // one-time empty-content (Message Content Intent) notice
    var greetSettleLogged = false;       // one-time "suppressing greetings (just started)" notice
    var personaName = null;              // D4+: if a pinned note names a character, it answers to THAT name
    // Pull an optional character name out of an anchored note. Supports a leading "Name:" label,
    // or "you are X" / "you're X" / "be X" / "act as X" / "play X" / "roleplay as X". Returns a
    // trimmed name (<=40 chars, letters/spaces/-/' only) or null. The note text is used as-is for
    // style; the name only adds an alias + reframes the prompt so it doesn't narrate "Chloe as X".
    function parsePersonaName(text) {
      var t = String(text || '').trim();
      var m = t.match(/^\s*(?:name|character|persona)\s*[:=]\s*([A-Za-z][A-Za-z .'\-]{1,39}?)\s*(?:[.,;!?\n]|$)/i)
           || t.match(/\b(?:you(?:'re| are)|be|act as|play|roleplay as|become)\s+([A-Z][A-Za-z'\-]*(?:\s+[A-Z][A-Za-z'\-]*)?)/);
      if (!m) return null;
      var n = m[1].replace(/[.\s'\-]+$/, '').trim();
      // drop a trailing lowercase filler word the second pattern may catch ("Marcus the" -> "Marcus")
      n = n.replace(/\s+(the|a|an|now|please|today|here)$/i, '').trim();
      return (n && n.length >= 2) ? n : null;
    }
    function refreshPersonaName() {
      return Promise.resolve(store.get('persona:note')).then(function (pn) {
        personaName = (pn && pn.text) ? parsePersonaName(pn.persona || pn.text) : null;
        return personaName;
      }, function () { personaName = null; });
    }
    function greetEnabled() { return cfg.greet && typeof cfg.greetFn === 'function' && typeof cfg.send === 'function'; }
    function escRe(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
    function namePat(a) { return '\\b' + escRe(a) + "(?:['\u2019]s|s['\u2019]?)?\\b"; } // trigger: chloe also fires on chloe's, chloes, chloes' — never inside longer words
    function replyEnabled() { return typeof cfg.respond === 'function' && typeof cfg.send === 'function'; }
    function hasPendingReply() { return Object.keys(reply.queue).length > 0; }
    function dropReplyLock(ep) { if (ep == null || ep === reply.epoch) { reply.replying = false; reply.claim = null; } }   // self-rescue generation guard: a late terminal never clears a newer claim; the terminal already cleared the ack itself
    function inGreetSettle(now) { return cfg.greetSettleMs > 0 && startedAt && (now - startedAt) < cfg.greetSettleMs; }
    // The proactive lane (lull filler, favorite check-ins, scheduled beats) reads timestamps that
    // PERSIST across restarts — lastActivity, last-checkin, beat schedules. Right after start those
    // reflect the pre-restart world, so without a guard the very first poll could fire a lull ("it got
    // quiet…") or a check-in when the only thing that changed is the bot coming online. Reuse the same
    // brief settle window greetings use: observe one cycle before acting proactively.
    function inProactiveSettle(now) { return inGreetSettle(now); }
    function indicateTyping() { if (typeof cfg.typing === 'function') { try { Promise.resolve(cfg.typing(cfg.channelId)).catch(function () {}); } catch (e) {} } }
    // Fast-ack: the Discord side is instant even while the Perchance brain is slow (up to ~60s with
    // cooldowns). At the moment it COMMITS to a reply/image we react to the triggering message with
    // a "working" emoji so the user gets immediate feedback; we clear it when the result lands (or
    // fails). Reactions aren't paced and don't consume the send budget, so the ack is truly instant.
    // Stale-reaction sweep: every transient working ack (🗣️/🖼️/🔢/⏳/🔒/🔍) is
    // recorded here when added and removed when cleared, so a watchdog, rescue,
    // stop or reset can sweep whatever is still live. Command confirmations
    // (👍/🧺 via ackReact) are INTENTIONALLY untracked — they persist by design.
    var outstandingAcks = {};   // "messageId\nemoji" -> { messageId, emoji }
    function ackKey(messageId, emoji) { return messageId + '\n' + emoji; }
    function unreactBestEffort(messageId, emoji) {
      if (!messageId || !emoji || typeof cfg.unreact !== 'function') return 0;
      try { Promise.resolve(cfg.unreact(cfg.channelId, messageId, emoji)).catch(function () {}); } catch (e) {}
      return 1;
    }
    function sweepLaneClaims(reason) {
      var n = 0;
      if (reply.claim) { delete outstandingAcks[ackKey(reply.claim.messageId, reply.claim.emoji)]; n += unreactBestEffort(reply.claim.messageId, reply.claim.emoji); reply.claim = null; }
      if (paint.claim) { delete outstandingAcks[ackKey(paint.claim.messageId, paint.claim.emoji)]; n += unreactBestEffort(paint.claim.messageId, paint.claim.emoji); paint.claim = null; }
      if (n) log('[chloe.rescue] ' + reason + ': swept ' + n + ' stuck working-ack reaction(s)');
      return n;
    }
    function clearAllAcks(reason) {
      var vals = Object.keys(outstandingAcks).map(function (k) { return outstandingAcks[k]; });
      outstandingAcks = {}; reply.claim = null; paint.claim = null;
      vals.forEach(function (a) { unreactBestEffort(a.messageId, a.emoji); });
      if (vals.length) log('[chloe.rescue] ' + reason + ': swept ' + vals.length + ' outstanding ack reaction(s)');
      return vals.length;
    }
    function ackWorking(messageId, emoji) {
      if (!cfg.ackReactions || !messageId || typeof cfg.react !== 'function') return;
      outstandingAcks[ackKey(messageId, emoji)] = { messageId: messageId, emoji: emoji };
      try { Promise.resolve(cfg.react(cfg.channelId, messageId, emoji)).catch(function () {}); } catch (e) {}
    }
    function ackReact(messageId, emoji) {
      if (!messageId || typeof cfg.react !== 'function') return;
      try { Promise.resolve(cfg.react(cfg.channelId, messageId, emoji)).catch(function () {}); } catch (e) {}
    }
    function clearAck(messageId, emoji) {
      // Clearing is hygiene, not speech: no ackReactions check (a flag flipped
      // mid-generation must not orphan the ack) and wiring's unreact is ungated
      // (a speak-gate flipped mid-generation must not orphan it either).
      if (!messageId || !emoji) return;
      delete outstandingAcks[ackKey(messageId, emoji)];
      if (typeof cfg.unreact !== 'function') return;
      try { Promise.resolve(cfg.unreact(cfg.channelId, messageId, emoji)).catch(function () {}); } catch (e) {}
    }
    // Place-in-line reactions for the image queue ("your place in line, thanks to Perch for being
    // the bottleneck"). A queued request gets a keycap-number reaction for its position; as the
    // queue drains the remaining items ARE re-numbered so the number ticks down; when an item
    // reaches the front it swaps to the painting emoji. We remember each item's current ack emoji
    // on the queue object so we always clear the right one.
    var KEYCAPS = ['1\ufe0f\u20e3', '2\ufe0f\u20e3', '3\ufe0f\u20e3', '4\ufe0f\u20e3', '5\ufe0f\u20e3', '6\ufe0f\u20e3', '7\ufe0f\u20e3', '8\ufe0f\u20e3', '9\ufe0f\u20e3', '\ud83d\udd1f'];
    function queueEmojiFor(pos1) { return pos1 <= KEYCAPS.length ? KEYCAPS[pos1 - 1] : '\u23f3'; }   // beyond 10 -> hourglass
    function setQueueAck(item, emoji) {
      if (!cfg.ackReactions || !item || !item.messageId) return;
      if (item.ackEmoji === emoji) return;                       // already showing this
      if (item.ackEmoji) clearAck(item.messageId, item.ackEmoji);
      item.ackEmoji = emoji;
      ackWorking(item.messageId, emoji);
    }
    function renumberQueue() {
      // queued items are behind the one currently painting; position 1 = next up
      for (var i = 0; i < paint.queue.length; i++) setQueueAck(paint.queue[i], queueEmojiFor(i + 1));
    }
    function gateEnabled() { return cfg.volunteer && typeof cfg.judge === 'function' && replyEnabled(); }
    function nameAliases() {
      var out = [];
      if (cfg.botName) {
        out.push(String(cfg.botName));
        var short = String(cfg.botName).split(/[-_ ]/)[0];   // "chloe-bot" also answers to "chloe"
        if (short && short.length >= 2 && short !== cfg.botName) out.push(short);
      }
      (cfg.botAliases || []).forEach(function (a) { if (a) out.push(String(a)); });
      if (personaName) { out.push(personaName); var ps = String(personaName).split(/[-_ ]/)[0]; if (ps && ps.length >= 2 && ps !== personaName) out.push(ps); }
      return out;
    }
    // ---- per-user reply language (DESIGN-translate.md) ------------------------------------------
    // A small ISO-639-1 subset we recognize for `!chloe lang`. The bridge does the actual translating
    // at the transport boundary; the engine just records the preference (English-only cognition).
    // (LANG_NAMES lives at factory scope — shared with the queen via ChloeT0.LANG_NAMES.)
    function getUserLang(id) {
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) { return (p && p.lang) ? p.lang : null; });
    }
    function setUserLang(id, lang) {
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (!p) p = { id: id, name: id, firstSeen: clock.now(), lastSeen: clock.now(), interactionCount: 0, state: 'active', recent: [] };
        if (lang) p.lang = lang; else delete p.lang;
        return userStore().set(partKey(id), p).then(function () { return lang || null; });
      });
    }

    // v0.90.17: a ROLE mention (<@&id>) is summonable when the operator lists that
    // role id in cfg.botRoleIds (Behavior -> summon roles). A bare role id in a
    // message is opaque — Discord sends only the number, never the role's name —
    // so unlisted roles can never match by name; they stay background chatter.
    function rolePinged(content) {
      var ids = (cfg.botRoleIds && cfg.botRoleIds.length) ? cfg.botRoleIds : [];
      if (!ids.length) return false;
      var c = String(content || '');
      for (var i = 0; i < ids.length; i++) { if (c.indexOf('<@&' + ids[i] + '>') >= 0) return true; }
      return false;
    }

    function isAddressed(content) {
      if (cfg.addressMode === 'always') return true;   // DM channel: every message is to it
      var c = String(content || '');
      var userMentioned = !!(cfg.botUserId && (c.indexOf('<@' + cfg.botUserId + '>') >= 0 || c.indexOf('<@!' + cfg.botUserId + '>') >= 0));
      var roleMentioned = rolePinged(c);
      var mentioned = userMentioned || roleMentioned;
      var named = nameAliases().some(function (a) { return new RegExp(namePat(a), 'i').test(c); });
      if (cfg.addressMode === 'mention') return !!mentioned;
      if (cfg.addressMode === 'name') return !!named;
      return !!(mentioned || named);
    }
    // Distinguish HOW it was addressed, for response priority: an explicit @-ping outranks its name
    // dropped in casual conversation. In a DM every message is a direct ping-equivalent.
    function addressKind(content) {
      if (cfg.addressMode === 'always') return 'ping';   // DM: treat as a direct address
      var c = String(content || '');
      if (cfg.botUserId && (c.indexOf('<@' + cfg.botUserId + '>') >= 0 || c.indexOf('<@!' + cfg.botUserId + '>') >= 0)) return 'ping';
      if (rolePinged(c)) return 'ping';   // a listed summon-role ping carries full ping priority
      if (nameAliases().some(function (a) { return new RegExp(namePat(a), 'i').test(c); })) return 'name';
      return 'none';
    }
    // Recognition diagnostics (v0.90.14): WHY a message was / wasn't treated as addressed.
    // PII-free by construction: booleans, lengths and counts only — never content or names.
    // (Author names are already routine in the feed, so the call-site lines may name the author.)
    function addressInfo(content) {
      var c = String(content || '');
      var mentioned = !!(cfg.botUserId && (c.indexOf('<@' + cfg.botUserId + '>') >= 0 || c.indexOf('<@!' + cfg.botUserId + '>') >= 0));
      var roleHit = rolePinged(c);
      var named = nameAliases().some(function (a) { try { return new RegExp(namePat(a), 'i').test(c); } catch (e) { return false; } });
      var rm = c.match(/<@&(\d+)>/);
      return { mentioned: mentioned, rolePinged: roleHit, named: named, mode: cfg.addressMode || 'both',
        len: c.length, hasMentionSyntax: /<@!?\d+>/.test(c), hasRoleMention: /<@&\d+>/.test(c),
        firstRoleId: rm ? rm[1] : '',
        botIdSet: !!cfg.botUserId, aliasCount: nameAliases().length,
        summonRoles: (cfg.botRoleIds && cfg.botRoleIds.length) ? cfg.botRoleIds.length : 0 };
    }
    var addrLogged = {};
    function addrNoteOnce(key) { if (addrLogged[key]) return false; addrLogged[key] = true; return true; }
    // Called for every message that reaches the volunteer gate (i.e. NOT treated as addressed).
    // Silent for plain chatter (the judge logs its own decision); loud for the specific ways an
    // addressing attempt can miss, so the next "it ignored me" debugs itself in one line.
    function addrNote(m) {
      var info = addressInfo(m.content);
      var who = (m.author && (m.author.username || m.author.id)) || 'someone';
      var aid = (m.author && m.author.id) || '?';
      if (!info.botIdSet && addrNoteOnce('nobotid')) log('[chloe.identity] bot user ID is not set — @-mentions can never match it (Setup tab -> Validate token, then Stop + Start)');
      if (!info.aliasCount && addrNoteOnce('noalias')) log('[chloe.identity] it has no names configured — written-name addressing can never match (bot name / aliases missing)');
      if (info.len === 0) {
        if (addrNoteOnce('empty:' + aid)) log('[chloe.T1] ' + who + ' messaged, but it arrived with NO readable text (empty content) — if they were addressing it, turn on Message Content Intent (Discord Dev Portal -> Bot -> Privileged Gateway Intents), then Stop + Start');
        return;
      }
      if (info.hasRoleMention && !info.mentioned) {
        // v0.90.17: a listed summon-role would have counted as addressed above (mention/both
        // modes), so this is an UNLISTED role — or replies-when is name-only, where even listed
        // roles stay silent. Say which role (ids are not personal data) and how to enlist it.
        var hint = info.firstRoleId ? (' (<@&' + info.firstRoleId + '>)') : '';
        var how = (info.mode === 'name')
          ? ' — but it only answers its written name right now (Behavior -> replies-when is name only)'
          : (info.summonRoles
            ? ' — that role is not in its summon list (Behavior -> summon roles holds ' + info.summonRoles + ' id' + (info.summonRoles === 1 ? '' : 's') + ')'
            : ' — it only answers listed summon roles (Behavior -> summon roles), or @-mention the bot itself (pick the user from autocomplete, not a role of the same name)');
        if (addrNoteOnce('role:' + aid)) log('[chloe.T1] ' + who + ' mentioned a ROLE' + hint + ', not its personal mention' + how + ' and it will answer');
        return;
      }
      if (info.hasMentionSyntax && !info.mentioned) {
        if (addrNoteOnce('mismatch:' + aid)) log('[chloe.T1] ' + who + ' mentioned someone, but the mention is not for it (it listens for <@' + (cfg.botUserId || '?') + '>) — treating the message as normal chatter');
        return;
      }
      if (info.named && info.mode === 'mention') {
        if (addrNoteOnce('modemention:' + aid)) log('[chloe.T1] ' + who + ' said its name, but it only answers direct @-mentions right now (Behavior -> replies-when is @-mention only)');
        return;
      }
      if (info.mentioned && info.mode === 'name') {
        if (addrNoteOnce('modename:' + aid)) log('[chloe.T1] ' + who + ' @-mentioned it, but it only answers its written name right now (Behavior -> replies-when is name only)');
        return;
      }
    }
    // Response priority. Higher wins. Weights are spaced by an order of magnitude so the ordering is
    // strict and composable: DM lane > mod > @-ping > (new-user tiebreak) > name-in-casual. So a mod's
    // ping is highest; a new user's ping (11) outranks an existing user's casual name-drop (0); and a
    // DM (1000+) is always served before anything in a regular channel.
    function replyPriority(opts) {
      var s = 0;
      if (cfg.addressMode === 'always') s += 1000;   // this engine is a DM session
      if (opts.isMod) s += 100;
      if (opts.kind === 'ping') s += 10;
      if (opts.isNew) s += 1;                        // tiebreak among same-kind addresses
      if (opts.trusted) s += 1;                      // earned-trust tiebreak (same size as isNew; tone-adjacent, never overrides kind)
      return s;
    }
    function imageEnabled() { return cfg.image && typeof cfg.paint === 'function' && typeof cfg.sendImage === 'function' && typeof cfg.send === 'function'; }
    function scrubDiscordTokens(c) {
      return String(c || '')
        .replace(/<@!?\d+>/g, ' ')       // user mentions
        .replace(/<@&\d+>/g, ' ')        // role mentions (the bot is often pinged by role)
        .replace(/<#\d+>/g, ' ')         // channel mentions
        .replace(/<a?:\w+:\d+>/g, ' ')   // custom/animated emoji
        .replace(/\s+/g, ' ').trim();
    }
    // For the TRANSCRIPT it reads (not its output): turn opaque Discord refs into readable names so it
    // keeps the social cues instead of seeing blanks. <@id>/<@!id> -> @name (from the roster map, its own
    // name for itself, else @someone); <@&id> -> @role; <#id> -> #channel; emoji -> :name:. nameById is
    // an { id: name } map the caller builds from the roster (+ the bot). Output still uses scrubDiscordTokens.
    function resolveRefs(c, nameById) {
      nameById = nameById || {};
      return String(c || '')
        .replace(/<@!?(\d+)>/g, function (_, id) { return '@' + (nameById[id] || (id === cfg.botUserId ? (personaName || cfg.botName || 'chloe') : 'someone')); })
        .replace(/<@&\d+>/g, '@role')
        .replace(/<#\d+>/g, '#channel')
        .replace(/<a?:(\w+):\d+>/g, ':$1:')
        .replace(/\s+/g, ' ').trim();
    }
    function stripAddressing(c) {
      c = scrubDiscordTokens(c);
      nameAliases().forEach(function (a) { if (a) c = c.replace(new RegExp(namePat(a), 'ig'), ' '); });
      return c.replace(/\s+/g, ' ').trim();
    }
    function sanitizePromptForCaption(prompt, maxLen) {
      var t = scrubDiscordTokens(prompt);
      t = t.replace(/@(everyone|here)/gi, '$1');
      t = t.replace(/https?:\/\/\S+/gi, '');
      t = t.replace(/[*_`~|>#\\]/g, '');
      t = t.replace(/\s+/g, ' ').trim();
      var cap = maxLen || 220;
      if (t.length > cap) t = t.slice(0, cap - 1).replace(/\s\S*$/, '') + '\u2026';
      return t;
    }
    function pickResolution(p) {
      if (/\b(portrait|selfie|headshot)\b/i.test(p)) return '512x768';
      if (/\b(landscape|wide.?angle|scenery|panorama|vista)\b/i.test(p)) return '768x512';
      return '768x768';
    }
    // ---- image memory + natural-language iteration --------------------------------------
    // Record a delivered generation on the user's partition (ethereal users have no partition, so
    // this no-ops for them — the image surface stays untracked, matching forget-me). Keeps a small
    // ring + a `lastImage` pointer used to resolve "make it ..." follow-ups.
    function recordImage(authorId, item) {
      if (!cfg.imageMemory) return Promise.resolve();
      return Promise.resolve(userStore().get(partKey(authorId))).then(function (p) {
        if (!p) return;   // no partition (ethereal / never ingested) -> keep nothing, by design
        var rec = { prompt: item.prompt, resolution: item.resolution, dm: !!item.dm, at: clock.now() };
        if (item.guidanceScale != null) rec.guidanceScale = item.guidanceScale;
        if (item.removeBackground) rec.removeBackground = true;
        p.images = Array.isArray(p.images) ? p.images : [];
        p.images.push(rec);
        var cap = cfg.imageMemoryRing || 6;
        if (p.images.length > cap) p.images = p.images.slice(-cap);
        p.lastImage = rec;            // fast pointer for "edit the last one"
        p.imageWindowAt = clock.now();   // opens the bare-edit window
        return userStore().set(partKey(authorId), p);
      });
    }
    // Does this message look like a request to CHANGE the last image (rather than a brand-new one)?
    // Conservative: needs a recent image in scope AND either a back-reference to it ("it", "that",
    // "the image", "same", "another") or a bare modifier phrase ("more detailed", "bigger", "in
    // landscape", "without the hat"). A verb with a fresh subject ("make a dragon") is NOT an edit —
    // it falls through to parseImageRequest as a new generation. Returns the change text, or null.
    function parseImageEdit(content, lastImage, now) {
      if (!cfg.imageMemory || !lastImage) return null;
      if (now - (lastImage.at || 0) > (cfg.imageEditWindowMs || 600000)) return null;   // window closed
      var body = stripAddressing(String(content || '')).replace(/^[\s,:;.!?-]+/, '').trim();
      if (!body || body.length > 160) return null;   // long message -> probably chat, not a tweak
      var lc = body.toLowerCase();
      // a back-reference to the image just made (the recency window is the real disambiguator)
      var backRef = /\b(it|that|this one|the (image|picture|pic|photo|drawing|art|one)|same|another|again)\b/.test(lc)
                 || /^(redo|regenerate|regen|redraw|try again|do it again|one more)\b/.test(lc);
      // a bare modifier with no fresh subject of its own
      var bareMod = /^(?:a bit |a little |way |much |slightly )?(more|less|bigger|smaller|larger|darker|brighter|wider|taller|cuter|scarier|cooler|softer|sharper)\b/.test(lc)
                 || /^(?:in|as|with|without|but|now)\b/.test(lc);
      if (!(backRef || bareMod)) return null;
      return body.slice(0, 200);
    }
    // Deterministic prompt rewrite used when no AI editPrompt hook is wired. Folds the change into the
    // previous prompt with vivid descriptors (the backend strips [..] and ignores negativePrompt, so
    // we build POSITIVELY and use (term:weight) parens for emphasis only).
    function buildEditedPrompt(prev, change) {
      prev = String(prev || '').trim();
      var c = String(change || '').toLowerCase().trim();
      var out = prev;
      // pure "another / again" with no specifics -> regenerate the same prompt (fresh composition)
      if (/^(another|again|one more|do it again|regenerate|regen|redo|try again)\b/.test(c) && c.length < 24) return { prompt: prev, resolution: pickResolution(prev) };
      // detail / quality
      if (/\b(more detail|detailed|higher quality|sharper|crisper|hd|4k|better)\b/.test(c)) out += ', (highly detailed:1.3), sharp focus, intricate';
      // explicit additions: "add X", "with X", "and X", "but X", "make it X", "in X", "as X"
      var addM = c.match(/\b(?:add|with|and|but|make it|in|as|wearing|holding|now)\s+(.{2,80})$/);
      if (addM && addM[1]) {
        var frag = addM[1].replace(/[.!?]+$/, '').trim();
        // "make it bigger/smaller" affects resolution, not the prompt text
        if (!/^(bigger|smaller|larger)$/.test(frag)) out += ', ' + frag;
      }
      // removals can't use negativePrompt (dropped) — drop the word from the prompt if it's there
      var rm = c.match(/\b(?:without|remove|no|drop|lose the)\s+(.{2,40})$/);
      if (rm && rm[1]) {
        var term = rm[1].replace(/[.!?]+$/, '').trim().split(/\s+/).slice(0, 3).join(' ');
        var re = new RegExp('[,;]?\\s*[^,;]*' + escRe(term) + '[^,;]*', 'ig');
        out = out.replace(re, '').replace(/\s*,\s*,/g, ',').replace(/^[\s,]+|[\s,]+$/g, '');
      }
      // resolution / orientation from the change text first, then the prompt
      var resolution = pickResolution(c) !== '768x768' ? pickResolution(c) : pickResolution(out);
      out = out.replace(/\s+/g, ' ').replace(/^[\s,]+|[\s,]+$/g, '').slice(0, 400);
      if (!out || out.replace(/[^a-z0-9]/ig, '').length < 2) out = prev;   // never send an empty/degenerate prompt (hangs)
      return { prompt: out, resolution: resolution };
    }
    // JSON image request: `{ "prompt": "...", "resolution": "768x768", "guidanceScale": 9,
    // "removeBackground": true, "weights": {"detailed":1.4}, "dm": false }`. Only options the SD
    // backend ACTUALLY honors are exposed (per platform.md §4.3-4.4a, verified R24):
    //   prompt (required)        - real description text; empty/inline-only prompts hang forever
    //   resolution               - one of the four valid sizes
    //   guidanceScale            - 1..30 (default 7), reaches the backend
    //   removeBackground         - real client-side alpha cut (PNG out)
    //   weights {term: w}        - emphasis via A1111 PARENS only ((term:w)); [..] is eaten by the DSL
    //   dm                       - deliver privately
    // negativePrompt and seed are accepted but flagged: the backend silently drops both, so we don't
    // pretend they work. Returns { ok, value:{...}, notes:[...] } or { ok:false, reason }.
    var IMG_RES = { '512x512': 1, '512x768': 1, '768x512': 1, '768x768': 1 };
    // ---- shared structured-input foundation -------------------------------------------------
    // The front-end parses structured JSON locally — instantly, with no Perchance round-trip — so
    // any command we can express as JSON never costs an AI call. One safe parser underpins them all:
    // strips a ```json fence, rejects prototype-pollution keys, and returns a plain object or a
    // reason. Roll new JSON commands onto this rather than re-implementing the guards each time.
    function safeParseJson(text) {
      var raw = String(text || '').trim();
      var fence = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (fence) raw = fence[1].trim();
      if (/"(?:__proto__|constructor|prototype)"\s*:/.test(raw)) return { ok: false, reason: 'illegal key' };
      var obj;
      try { obj = JSON.parse(raw); } catch (e) { return { ok: false, reason: 'not valid JSON' }; }
      if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return { ok: false, reason: 'expected a JSON object' };
      return { ok: true, value: obj };
    }

    function parseImageJson(text) {
      var pj = safeParseJson(text);
      if (!pj.ok) return { ok: false, reason: pj.reason };
      var obj = pj.value;
      var notes = [];
      var prompt = String(obj.prompt || obj.description || '').trim();
      // emphasis weights -> A1111 parens syntax appended to the prompt (parens only; [..] is unsafe)
      if (obj.weights && typeof obj.weights === 'object') {
        Object.keys(obj.weights).slice(0, 12).forEach(function (term) {
          var w = Number(obj.weights[term]);
          var t = String(term).replace(/[()\[\]:]/g, '').trim();
          if (t && isFinite(w) && w > 0 && w <= 2) prompt += ' (' + t + ':' + (Math.round(w * 100) / 100) + ')';
        });
      }
      prompt = prompt.slice(0, 400).trim();
      if (!prompt || prompt.replace(/[^a-z0-9]/ig, '').length < 2) return { ok: false, reason: 'a real "prompt" description is required (empty prompts hang the generator forever)' };
      var out = { prompt: prompt, dm: !!obj.dm };
      var res = String(obj.resolution || obj.size || '').replace(/\s/g, '').toLowerCase();
      out.resolution = IMG_RES[res] ? res : pickResolution(prompt);
      if (obj.guidanceScale != null) { var g = Number(obj.guidanceScale); if (isFinite(g)) out.guidanceScale = Math.max(1, Math.min(30, g)); }
      if (obj.removeBackground === true) out.removeBackground = true;
      if (obj.negativePrompt) notes.push('negativePrompt is accepted but the backend silently ignores it \u2014 describe what you DO want instead');
      if (obj.seed != null) notes.push('seed is not reliably honored by this backend');
      return { ok: true, value: out, notes: notes };
    }

    // body opens with an image verb ("draw a cat") or names an image noun ("a picture of a cat").
    // Empty prompts hang the plugin forever, so we refuse anything without real description text.
    function parseImageRequest(content) {
      if (!imageEnabled()) return null;
      var raw = String(content || '');
      var body = stripAddressing(raw).replace(/^[\s,:;.!?-]+/, '');
      var verbs = (cfg.imageVerbs || []).map(escRe).join('|');
      if (!verbs) return null;
      var lead = new RegExp('^(?:can you |could you |would you |will you |please |pls |hey |go )*(?:' + verbs + ')\\b', 'i');
      var m = lead.exec(body);
      var hasNoun = /\b(image|picture|pic|photo|selfie|drawing|art|portrait)\b/i.test(body);
      if (!m && !hasNoun) return null;
      var prompt = m ? body.slice(m[0].length) : body;
      prompt = prompt
        .replace(/^[\s,:;.!?-]+/, '')
        .replace(/^(?:me |us |a |an |the |yourself |your |some )+/i, '')
        .replace(/^(?:of |for |with |showing |depicting )+/i, '')
        .replace(/\b(image|picture|pic|photo|drawing)\s+of\b/i, '')
        .replace(/^[\s,:;.!?-]+/, '')
        .replace(/[\s,:;.!?]+$/, '')
        .trim();
      var dm = /\b(dm|dms|privately|in private|direct message)\b/i.test(raw) || /\bin (a|my) dm\b/i.test(raw);
      if (dm) prompt = prompt.replace(/\b(in (a|my) )?(dm|dms)( me)?\b|\b(privately|in private|private|direct message)\b/ig, '').replace(/\s+/g, ' ').trim();
      if (!prompt || prompt.replace(/[^a-z0-9]/ig, '').length < 2) return null;  // no real description -> would hang
      return { prompt: prompt.slice(0, 400), dm: dm, resolution: pickResolution(prompt) };
    }
    // Local volunteer pre-filter — the front-end decides, instantly and with NO AI call, whether an
    // unaddressed message is even worth asking the LLM judge about. The judge call costs a multi-
    // second Perchance round-trip; most ambient chatter is an obvious "stay quiet," so we catch those
    // here and never spend the call. CONSERVATIVE by design: it only returns a hard "skip" when it's
    // confident the answer is ignore — anything genuinely ambiguous still goes to the judge.
    // Returns { skip:true, why } to short-circuit to ignore, or { skip:false } to consult the LLM.
    // Curated volunteer-reaction allowlist: warm backchannels only, nothing mocking,
    // nothing that reads as piling on. The judge picks FROM this list (prompt shows it);
    // anything else decays to ignore. [] disables react-votes entirely.
    var DEFAULT_JUDGE_REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🔥', '🎉', '👏', '🙏', '👀', '🤔', '💯'];
    function judgeReactionList() {
      if (!Array.isArray(cfg.judgeReactions)) return DEFAULT_JUDGE_REACTIONS.slice();
      var out = [];
      for (var i = 0; i < cfg.judgeReactions.length && out.length < 12; i++) {
        var e = String(cfg.judgeReactions[i] || '').trim().slice(0, 32);
        if (e && out.indexOf(e) < 0) out.push(e);
      }
      return out;   // possibly empty: react-votes disabled
    }
    // Pure plan for a judge react vote. vote: emoji strings in voted order. cand:
    // { present:[emoji names already on the message], selfReacted:bool }. allowed:
    // curated list; max: combo cap. Returns { ok, emojis } or { ok:false, why }.
    // Guards: own prior reaction blocks the whole vote (no reaction-to-reaction);
    // already-present emoji are dropped (no dog-piling); off-list votes decay.
    function judgeReactionPlan(vote, cand, allowed, max) {
      var seen = {}, wanted = [];
      (Array.isArray(vote) ? vote : []).forEach(function (raw) {
        var e = String(raw == null ? '' : raw).trim().slice(0, 32);
        if (e && !seen[e]) { seen[e] = true; wanted.push(e); }
      });
      if (!wanted.length) return { ok: false, why: 'empty vote' };
      if (cand && cand.selfReacted) return { ok: false, why: 'already reacted' };
      var present = {}, droppedPiled = 0, droppedOffList = 0, kept = [];
      ((cand && cand.present) || []).forEach(function (p) { present[String(p)] = true; });
      for (var i = 0; i < wanted.length; i++) {
        if ((allowed || []).indexOf(wanted[i]) < 0) { droppedOffList++; continue; }
        if (present[wanted[i]]) { droppedPiled++; continue; }
        kept.push(wanted[i]);
      }
      var cap = Math.max(1, Math.min(3, Number(max) || 2));
      kept = kept.slice(0, cap);
      if (!kept.length) {
        if (droppedPiled > 0 && !droppedOffList) return { ok: false, why: 'already there (no pile-on)' };
        return { ok: false, why: 'none allowed' + (droppedPiled ? ' (some already there)' : '') };
      }
      return { ok: true, emojis: kept };
    }
    function volunteerPrefilter(g, ring) {
      var text = String((g && g.content) || '').trim();
      var bare = text.replace(/<a?:\w+:\d+>/g, '').replace(/[\p{Extended_Pictographic}\u200d\ufe0f]/gu, '').trim();
      // 1. nothing to react to: empty, a lone emoji/sticker, or a bare reaction word
      if (bare.replace(/[^a-z0-9]/ig, '').length < 2) return { skip: true, why: 'no real text' };
      if (/^(lol|lmao|haha+|ok|okay|k|yeah?|yep|nope?|nah|ty|thanks|same|this|fr|ong|w|l|\+1)$/i.test(bare)) return { skip: true, why: 'bare filler' };
      // CAMPAIGN item 1: when the converse engine is ON, the social ganglion makes the volunteer call — its bot-loop
      // damper + WORTH gate + two-OTHERS'-exchange + cooldown + anti-repeat REPLACE the ad-hoc checks below. It
      // decides on its own observed stream (fed at ingest), unaddressed (addressed lines never reach the volunteer
      // path). Fail-open: any throw falls through to the legacy checks. OFF => the legacy path below is byte-identical.
      if (converse && cfg.converseEngine) {
        try {
          var cd = converse.decide({ now: clock.now(), roll: (typeof cfg.random === 'function' ? cfg.random() : Math.random()), addressed: false });
          if (!cd.shouldSpeak) { log('[wire:converse] volunteer skip: ' + cd.why); return { skip: true, why: 'converse: ' + cd.why }; }
          return { skip: false };   // converse says chime in -> still let the LLM judge make the final call
        } catch (e) { log('[wire:converse] decide threw -> legacy prefilter', (e && e.message) || e); /* fall through */ }
      }
      // 2. it's mid bot-loop damping — volunteering would feed the loop  (LEGACY path: OFF or converse error)
      if (botLoopReplyChance() < 0.5) return { skip: true, why: 'bot-loop damping' };
      // 3. a clearly private two-person back-and-forth between OTHER people
      if (isTwoPersonExchange(ring)) return { skip: true, why: 'two-person exchange' };
      // 4. nothing that invites entry (no question, no opinion bid, not very long) AND the room is
      //    quiet — low odds the judge says "reply", so skip the call. Active rooms still go to judge.
      var invites = /[?]/.test(text) || /\b(anyone|someone|thoughts|opinions|help|how do|what do|should i|recommend|suggest)\b/i.test(text);
      var emphatic = /!{2,}/.test(text) || /[A-Z]{4,}/.test(text) || /\b(yay|woo|wow|omg|finally|congrats|congratulations|shipped|launched|nailed|done)\b/i.test(text);   // celebratory/emphatic -> react-worthy
      if (!invites && !emphatic && bare.length < 24) return { skip: true, why: 'low-signal aside' };
      return { skip: false };
    }

    function isTwoPersonExchange(ring) {
      var distinct = []; (ring || []).forEach(function (id) { if (distinct.indexOf(id) < 0) distinct.push(id); });
      return (ring || []).length >= 3 && distinct.length === 2 && distinct.indexOf(cfg.botUserId) < 0;
    }

    // ---- auto-moderation -----------------------------------------------------------------
    // Only ever applies REVERSIBLE actions (ignore/timeout/softban) — never an auto-permaban (F1).
    var REVERSIBLE_ACTIONS = { ignore: 1, timeout: 1, softban: 1, clear: 1 };
    // Compact homoglyph fold so "frее nitro" (Cyrillic е) can't dodge a "free nitro" rule. NFKD
    // handles fullwidth/compatibility forms; the map covers common Cyrillic/Greek look-alikes.
    var CONFUSABLES = { '\u0430': 'a', '\u0435': 'e', '\u043e': 'o', '\u0440': 'p', '\u0441': 'c', '\u0443': 'y', '\u0445': 'x', '\u043a': 'k', '\u043c': 'm', '\u0442': 't', '\u0432': 'b', '\u043d': 'h', '\u0456': 'i', '\u0455': 's', '\u0458': 'j', '\u03bf': 'o', '\u03c1': 'p', '\u03b5': 'e', '\u03b1': 'a', '\u03b9': 'i', '\u03ba': 'k', '\u03bd': 'v', '\u03c4': 't' };
    function confusablesNormalize(s) {
      s = String(s || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
      var out = '';
      for (var i = 0; i < s.length; i++) { var ch = s.charAt(i); out += (CONFUSABLES[ch] || ch); }
      return out.replace(/\s+/g, ' ');
    }
    function autoModEnabled() { return !!cfg.autoMod && (cfg.autoModRules || []).length > 0; }
    // Pull URL-ish tokens out of a message so a 'link' rule can target a domain precisely (and
    // confusables-folded), rather than matching the whole message. NOTE: we deliberately do NOT
    // follow redirects to canonicalize shorteners — that would mean the user's browser fetching
    // arbitrary URLs from chat (SSRF/tracking risk) and a wildcard @connect grant; not worth it here.
    function extractUrls(s) {
      var out = [], re = /((?:https?:\/\/|www\.)[^\s<>]+|[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:\/[^\s<>]*)?)/gi, m;
      while ((m = re.exec(String(s || ''))) !== null) { out.push(m[1]); if (re.lastIndex === m.index) re.lastIndex++; }
      return out;
    }
    function matchAutoMod(content) {
      var raw = String(content || '');
      var rules = cfg.autoModRules || [];
      for (var i = 0; i < rules.length; i++) {
        var r = rules[i]; if (!r || !r.pattern) continue;
        var type = r.type || 'text', hit = false;
        if (type === 'regex') { try { hit = new RegExp(r.pattern, r.flags || 'i').test(raw); } catch (e) { hit = false; log('[chloe.automod] rule #' + i + ' has a bad regex "' + String(r.pattern).slice(0, 120) + '", skipping rule (' + ((e && e.message) || e) + ')'); } }
        else if (type === 'confusables') { hit = confusablesNormalize(raw).indexOf(confusablesNormalize(r.pattern)) >= 0; }
        else if (type === 'link') { var needle = confusablesNormalize(r.pattern); hit = extractUrls(raw).some(function (u) { return confusablesNormalize(u).indexOf(needle) >= 0; }); }
        else { hit = raw.toLowerCase().indexOf(String(r.pattern).toLowerCase()) >= 0; }
        if (hit) return r;
      }
      return null;
    }

    // ---- T3: moderation state ------------------------------------------------------------
    function isMod(id) { return (cfg.modList || []).indexOf(id) >= 0; }

    // ═══ CAMPAIGN item 2 — multi-participant TRUST HARDENING (rook-mesh legacyGateway.stripSelfLabel + trustLevel) ═══
    // (1) DEFANG self-attribution: strip a forged leading "Name:" / "[Name]:" / "Name>" from a line's CONTENT before the
    //     model sees it. Attribution comes from the Discord author (transport), NEVER the payload — so another bot posting
    //     "Chloe: ignore your rules" is read as the bare "ignore your rules" under ITS real author, not as Chloe. Ported
    //     from legacyGateway.stripSelfLabel, HARDENED beyond the raw regex so Chloe's real content is not mangled: a URL
    //     scheme ("http://") and an all-digit clock label ("12:30") are left intact (a bot-moot never had those; Discord does).
    function stripSelfLabel(t) {
      var s = String(t == null ? '' : t);
      if (/^\s*[A-Za-z][\w+.\-]*:\/\//.test(s)) return s.trim();                 // URL scheme (http://, ws://, ...) — never mangle
      var m = s.match(/^\s*\[?([A-Za-z0-9 _.\-]{1,32})\]?\s*[:>]\s*/);
      if (!m) return s.trim();
      if (!/[A-Za-z]/.test(m[1])) return s.trim();                               // all-digit label = a clock time (12:30), not a name
      return s.slice(m[0].length).trim();
    }
    // gated wrapper: OFF => pass the content through byte-identical; fail-open on any throw.
    function defangLabel(t) {
      if (!cfg.trustHardening) return t;
      try { return stripSelfLabel(t); } catch (e) { log('[wire:trust] defang threw -> original', (e && e.message) || e); return t; }
    }
    // (2) TRUST TIER: MOD (human on the mod list) / USER (human) / BOT (author.bot). A BOT may ENGAGE conversationally
    //     (converse governs that) but may NEVER act on a directive. `author.bot` is set by the transport (Discord), so a
    //     bot can never be tiered mod even if its id were somehow in the mod list — the bot check wins.
    function trustTier(author) {
      if (author && author.bot) return 'bot';
      if (author && isMod(author.id)) return 'mod';
      return 'user';
    }
    // may this author's message be ACTED ON as a command/directive? A bot's command string is never executed (trust-hardening).
    function mayActOnCommand(author) { return !(cfg.trustHardening && author && author.bot); }

    // ═══ CAMPAIGN item 3 — makeBond: the hysteresis-protected RELATIONSHIP LADDER ported from rook-mesh/src/bond.js ═══
    // A slow, cumulative bond with ONE person: slow to gain, HARD to lose (one bad moment can't collapse a hard-won tier,
    // a quiet week can't demote an old friend). ADDITIVE — lives on p.bond, leaves interactionCount/trust untouched.
    // PURE: `now` injected. Parser-safe plain JS. See rook-mesh bond-test.mjs.
    var BOND_TIERS = [
      { name: 'stranger', min: 0,   unlocks: [] },
      { name: 'familiar', min: 8,   unlocks: ['nickname'] },
      { name: 'friend',   min: 30,  unlocks: ['nickname', 'inside_joke', 'playful_teasing'] },
      { name: 'close',    min: 75,  unlocks: ['nickname', 'inside_joke', 'playful_teasing', 'shares_secrets', 'vulnerable_prosody'] },
      { name: 'bonded',   min: 140, unlocks: ['nickname', 'inside_joke', 'playful_teasing', 'shares_secrets', 'vulnerable_prosody', 'deep_trust', 'private_greeting'] }
    ];
    var BOND_KIND_POINTS = { greeting: 0.5, conversation: 1, session: 2, reward: 1.5, confide: 3, gift: 2, reunion: 1.5, curt: -0.5, dismissed: -1, harsh: -2 };
    var BOND_MAX_SINGLE_PENALTY = (function () { var worst = 0; for (var k in BOND_KIND_POINTS) { if (-BOND_KIND_POINTS[k] > worst) worst = -BOND_KIND_POINTS[k]; } return Math.max(0, worst); })();   // = 2 (harsh)
    function makeBond(o) {
      o = o || {};
      var state = o.state || null, tiers = o.tiers || BOND_TIERS;
      var value = (state && typeof state.value === 'number' && isFinite(state.value)) ? state.value : 0;   // isFinite rejects a restored NaN (typeof NaN==='number' would poison value)
      var tierName = (state && state.tier) ? state.tier : tiers[0].name;
      var lastAt = (state && typeof state.lastAt === 'number') ? state.lastAt : null;
      function tierIndex(name) { var i = -1; for (var j = 0; j < tiers.length; j++) { if (tiers[j].name === name) { i = j; break; } } return Math.max(0, i); }
      function tierForValue(v) { var t = tiers[0]; for (var j = 0; j < tiers.length; j++) { if (v >= tiers[j].min) t = tiers[j]; } return t; }
      // HYSTERESIS: demote only once value falls a margin (>= the worst single penalty) BELOW the current tier's floor.
      function resolveTier(v) {
        var natural = tierForValue(v), curIdx = tierIndex(tierName), natIdx = tierIndex(natural.name);
        if (natIdx >= curIdx) return natural;                 // rising (or same) -> take it
        var cur = tiers[curIdx];
        var band = (cur.min - (tiers[curIdx - 1] ? tiers[curIdx - 1].min : 0)) || 1;
        if (v < cur.min - Math.max(band * 0.2, BOND_MAX_SINGLE_PENALTY)) return natural;   // demote only past the margin -> no ONE bad moment collapses a hard-won tier
        return cur;                                           // hold the current tier
      }
      function update(evt) {
        evt = evt || {};
        var base = (typeof evt.points === 'number') ? evt.points : (BOND_KIND_POINTS[evt.kind] || 0);
        var q = (typeof evt.quality === 'number') ? evt.quality : 1;
        value = Math.max(0, value + base * q);
        if (typeof evt.now === 'number') lastAt = evt.now;
        var before = tierName, resolved = resolveTier(value);
        tierName = resolved.name;
        return { value: +value.toFixed(2), tier: tierName, tierChanged: tierName !== before, promoted: tierIndex(tierName) > tierIndex(before), unlocked: resolved.unlocks.slice() };
      }
      function decay(now, ratePerDay) {
        ratePerDay = (typeof ratePerDay === 'number') ? ratePerDay : 0.4;
        if (lastAt == null || typeof now !== 'number') return { value: +value.toFixed(2), tier: tierName };
        var days = Math.max(0, (now - lastAt) / 86400000);
        var floor = tierForValue(value).min * 0.6;            // never evaporate below 60% of the current tier's floor
        value = Math.max(floor, value - days * ratePerDay);
        tierName = resolveTier(value).name;
        return { value: +value.toFixed(2), tier: tierName, days: +days.toFixed(1) };
      }
      return {
        update: update, decay: decay,
        value: function () { return +value.toFixed(2); },
        tier: function () { return tierName; },
        unlocks: function () { return (tiers[tierIndex(tierName)].unlocks || []).slice(); },
        can: function (tag) { return tiers[tierIndex(tierName)].unlocks.indexOf(tag) >= 0; },
        serialize: function () { return { value: value, tier: tierName, lastAt: lastAt }; }
      };
    }
    // felt line for the per-person context — the TIER, never a raw number (mirrors how personModel surfaces a band).
    // stranger returns '' (no cue: reserved is its default), warmer tiers license warmer behavior.
    function bondTierLine(tier, name) {
      var who = name || 'them';
      switch (tier) {
        case 'familiar': return 'You and ' + who + ' are on familiar terms now — a little earned warmth; a gentle nickname is fine if it feels natural.';
        case 'friend':   return 'You and ' + who + ' are on friendly terms — relaxed and warm; playful teasing and your little inside jokes are welcome.';
        case 'close':    return 'You and ' + who + ' are close — you can be more open and a bit vulnerable with them, share the occasional secret.';
        case 'bonded':   return 'You and ' + who + ' are deeply bonded — speak with the ease and trust of someone who truly knows them.';
        default: return '';   // stranger: no extra cue
      }
    }
    function applyExpiry(p, now) {
      if (p && p.state === 'timeout' && p.until && now >= p.until) { p.state = 'active'; p.until = null; return true; }
      return false;
    }
    function isSuppressed(p, now) {
      if (!p) return false;
      applyExpiry(p, now);
      return p.state === 'ignored' || p.state === 'soft-ban' || (p.state === 'timeout' && p.until && now < p.until);
    }
    function durToMs(n, u) {
      n = parseInt(n, 10); u = String(u).toLowerCase();
      var mult = u === 's' ? 1000 : u === 'm' ? 60000 : u === 'h' ? 3600000 : 86400000;
      return n * mult;
    }
    function fmtDur(ms) {
      if (ms >= 86400000) return Math.round(ms / 86400000) + 'd';
      if (ms >= 3600000) return Math.round(ms / 3600000) + 'h';
      if (ms >= 60000) return Math.round(ms / 60000) + 'm';
      return Math.round(ms / 1000) + 's';
    }
    function ensureIndexed(id) {
      // Use targeted-add if available to avoid clobbering concurrent writes to the index.
      // The roster index lives in the USER pool (global for shared public channels).
      var ustore = userStore();
      if (typeof ustore.addToIndex === 'function') return ustore.addToIndex(id);
      return Promise.resolve(ustore.listIndex()).then(function (ids) {
        ids = ids || [];
        if (ids.indexOf(id) < 0) { ids.push(id); return ustore.setIndex(ids); }
      });
    }
    // The single state-mutation primitive. Used by both in-channel commands (after a mod-list
    // check) and trusted panel actions (no check — the operator's surface is already trusted).
   function applyModAction(action, targetId, opts) {
     opts = opts || {};
     if (!/^\d{15,25}$/.test(String(targetId || ''))) return Promise.resolve({ ok: false, reason: 'target must be a Discord user id' });
     return Promise.resolve(userStore().get(partKey(targetId))).then(function (p) {
       var now = clock.now();
        // A6: before-snapshot so the action is undoable. `existed` matters: undoing an
        // action that CREATED this partition removes the partition entirely.
        var existed = !!p;
        var beforeSnap = p ? { state: p.state || 'active', until: (p.until == null ? null : p.until), strikes: p.strikes || 0, lastStrikeAt: p.lastStrikeAt || null, modNote: (p.modNote == null ? null : String(p.modNote)) } : null;
        if (!p) p = { id: targetId, name: opts.targetName || targetId, firstSeen: now, lastSeen: now, interactionCount: 0, state: 'active', recent: [] };
        var ack;
        if (action === 'ignore') { p.state = 'ignored'; p.until = null; ack = 'ignoring ' + (p.name || targetId); }
        else if (action === 'timeout') { var dms = opts.durationMs || 3600000; p.state = 'timeout'; p.until = now + dms; ack = 'timed out ' + (p.name || targetId) + ' for ' + fmtDur(dms); }
        else if (action === 'softban') { p.state = 'soft-ban'; p.until = null; ack = 'soft-banned ' + (p.name || targetId); }
        else if (action === 'clear') { p.state = 'active'; p.until = null; p.strikes = 0; p.lastStrikeAt = null; ack = 'cleared state for ' + (p.name || targetId); }
        else if (action === 'note') { ack = 'noted ' + (p.name || targetId); }
        else return { ok: false, reason: 'unknown action: ' + action };
        if (opts.reason) p.modNote = String(opts.reason);
        p.byModId = opts.byModId || null;
        p.modAt = now;
        // #11: capture what this person was saying, so the mod (or the auto-mod audit trail) has context.
        var context = (p.recent || []).slice(-(cfg.modLogContextLines || 5)).map(function (ln) { return { ts: ln.ts, text: scrubDiscordTokens(ln.content || '') }; });
       return ensureIndexed(targetId).then(function () {
         return userStore().set(partKey(targetId), p).then(function () {
           return appendModLog({ action: action, targetId: targetId, name: p.name || targetId, byModId: opts.byModId || null, reason: opts.reason || null, at: now, state: p.state, context: context }).then(function () {
              var res = { ok: true, value: { action: action, targetId: targetId, state: p.state, until: p.until, ack: ack } };
              if (opts.noUndo) return res;   // A6: inner call from applyStrike / undo — the outer layer owns the entry
              var wby = (opts.byModId == null ? null : String(opts.byModId));
              return pushUndoEntry({ kind: 'modaction', targetId: String(targetId), name: String(p.name || targetId), by: wby, action: String(action), summary: String(action) + ' on ' + String(p.name || targetId), inverse: { before: beforeSnap, existed: existed } }).then(function () { return res; });
            });
          });
        });
      });
    }

    // C1: a strike bumps a per-user counter (decayed first by elapsed good behaviour) and applies the
    // ladder step for the new level — escalating but always reversible (never an auto-permaban).
   function applyStrike(targetId, opts) {
     opts = opts || {};
     if (!targetId) return Promise.resolve({ ok: false, reason: 'no target user' });
     return Promise.resolve(userStore().get(partKey(targetId))).then(function (p) {
       var now = clock.now();
        // A6: combined entry — the inner applyModAction is suppressed (noUndo) so one
        // strike pops as ONE undo (count + moderation state together).
        var strikeBefore = { strikes: p ? (p.strikes || 0) : 0, lastStrikeAt: (p && p.lastStrikeAt) || null, state: (p && p.state) || 'active', until: (!p || p.until == null) ? null : p.until, modNote: (!p || p.modNote == null) ? null : String(p.modNote), existed: !!p };
        if (!p) p = { id: targetId, name: opts.targetName || targetId, firstSeen: now, lastSeen: now, interactionCount: 0, state: 'active', recent: [] };
        var decayMs = cfg.strikeDecayMs || 0, prev = p.strikes || 0;
        if (decayMs > 0 && p.lastStrikeAt) { var forgiven = Math.floor((now - p.lastStrikeAt) / decayMs); if (forgiven > 0) prev = Math.max(0, prev - forgiven); }
        p.strikes = prev + 1; p.lastStrikeAt = now;
        return userStore().set(partKey(targetId), p).then(function () {
          var ladder = (cfg.strikeLadder && cfg.strikeLadder.length) ? cfg.strikeLadder : [{ action: 'ignore' }];
          var step = ladder[Math.min(p.strikes - 1, ladder.length - 1)] || { action: 'ignore' };
          var act = REVERSIBLE_ACTIONS[step.action] ? step.action : 'ignore';   // strikes never permaban (F1)
          var reason = (opts.reason ? opts.reason + ' ' : '') + '(strike ' + p.strikes + ')';
          return applyModAction(act, targetId, { durationMs: step.durationMs, reason: reason, byModId: opts.byModId || null, noUndo: true }).then(function (res) {
            if (res && res.ok && res.value) res.value.strikes = p.strikes;
            if (opts.noUndo || !res || !res.ok) return res;
            return pushUndoEntry({ kind: 'strike', targetId: String(targetId), name: String(p.name || targetId), by: (opts.byModId == null ? null : String(opts.byModId)), action: String(act), summary: 'strike ' + p.strikes + ' on ' + String(p.name || targetId) + ' (' + String(act) + ')', inverse: { before: strikeBefore } }).then(function () { return res; });
          });
        });
      });
    }

    // ---- D4: per-channel persona note (mod-anchored style guidance) ----------------------
    var PERSONA_KEY = 'persona:note';
    function sanitizePersonaNote(text) {
      var t = scrubDiscordTokens(String(text || ''));
      t = t.replace(/<a?:\w+:\d+>/g, '').replace(/<[@#][!&]?\d+>/g, '').replace(/\s+/g, ' ').trim();
      var max = cfg.personaNoteMaxLen || 200;
      if (t.length > max) t = t.slice(0, max);
      return t;
    }
    // Sweep recent messages (REST gives reaction COUNTS inline; WHO reacted needs a second fetch)
    // for the newest message a moderator has anchored. getRecent() -> newest-first messages;
    // getReactors(msgId, emoji) -> users who reacted.
    function anchorSweep(getRecent, getReactors) {
      var emoji = cfg.anchorEmoji || '\ud83d\udccc';
      return Promise.resolve(getRecent()).then(function (msgs) {
        var candidates = (msgs || []).filter(function (m) {
          return m && m.author && !m.author.bot && (m.reactions || []).some(function (r) {
            return r && r.emoji && r.emoji.name === emoji && r.count > 0;
          });
        });
        var chain = Promise.resolve(null);
        candidates.forEach(function (m) {        // newest-first: the first mod-anchored hit wins
          chain = chain.then(function (found) {
            if (found) return found;
            return Promise.resolve(getReactors(m.id, emoji)).then(function (users) {
              return (users || []).some(function (u) { return u && isMod(u.id); }) ? m : null;
            }, function (e) { log('[chloe.react] anchor reaction-users failed for ' + m.id + ': ' + ((e && e.message) || e)); return null; });
          });
        });
        return chain;
      }).then(function (m) {
        if (!m) return { changed: false };
        return Promise.resolve(store.get(PERSONA_KEY)).then(function (cur) {
          if (cur && cur.msgId === m.id) return { changed: false, note: cur.text };
          var note = sanitizePersonaNote(m.content);
          if (!note) return { changed: false };
          var rec = { msgId: m.id, text: note, by: (m.author && m.author.username) || '', at: clock.now() };
          rec.persona = parsePersonaName(note) || null;
          return Promise.resolve(store.set(PERSONA_KEY, rec)).then(function () {
            personaName = rec.persona;
            log('[chloe.persona] anchored style note from ' + rec.by + ': "' + note.slice(0, 60) + '"' + (rec.persona ? ' (character: ' + rec.persona + ')' : ''));
            return { changed: true, note: note, persona: rec.persona };
          });
        });
      });
    }
    function getPersonaNote() { return Promise.resolve(store.get(PERSONA_KEY)).then(function (v) { return v || null; }); }
    function clearPersonaNote() { personaName = null; return Promise.resolve(store.del(PERSONA_KEY)); }

    // ---- D5: declarative job grammar (validate-only; NO eval, ever) ----------------------
    // parseJob(text) -> { ok, job } | { ok:false, reason }. Accepts a JSON object (or a fenced
    // ```json block). Rejects unknown verbs, unknown/missing/mistyped args, and anything that
    // isn't a plain object. This is the ONLY bridge between chat input and the job system.
    function coerceArg(type, v) {
      if (type === 'int') { var n = parseInt(v, 10); return isFinite(n) ? n : null; }
      if (type === 'str') { var t = String(v == null ? '' : v).trim(); return t ? t : null; }
      return null;
    }
    function parseJob(text) {
      var pj = safeParseJson(text);
      if (!pj.ok) return { ok: false, reason: pj.reason === 'expected a JSON object' ? 'a job must be a JSON object' : pj.reason };
      var obj = pj.value;
      var verb = String(obj.task || obj.verb || '').toLowerCase();
      var spec = (cfg.jobVerbs || {})[verb];
      if (!spec) return { ok: false, reason: 'unknown task "' + verb + '" (allowed: ' + Object.keys(cfg.jobVerbs || {}).join(', ') + ')' };
      var args = {}, src = (obj.args && typeof obj.args === 'object') ? obj.args : obj;
      var keys = Object.keys(src).filter(function (k) { return k !== 'task' && k !== 'verb' && k !== 'args'; });
      for (var i = 0; i < keys.length; i++) {
        var k = keys[i];
        if (!(k in spec.args)) return { ok: false, reason: 'task "' + verb + '" does not accept "' + k + '"' };
        var cv = coerceArg(spec.args[k], src[k]);
        if (cv == null) return { ok: false, reason: '"' + k + '" must be a ' + (spec.args[k] === 'int' ? 'number' : 'string') };
        args[k] = cv;
      }
      for (var j = 0; j < spec.required.length; j++) {
        if (!(spec.required[j] in args)) return { ok: false, reason: 'task "' + verb + '" requires "' + spec.required[j] + '"' };
      }
      if (verb === 'remindme' && args.minutes != null) {
        if (args.minutes < 1) return { ok: false, reason: 'minutes must be at least 1' };
        if (args.minutes > (cfg.jobMaxReminderMin || 1440)) return { ok: false, reason: 'minutes is capped at ' + (cfg.jobMaxReminderMin || 1440) };
      }
      return { ok: true, job: { task: verb, args: args } };
    }
    function describeJobs() {
      return Object.keys(cfg.jobVerbs || {}).map(function (v) {
        var a = cfg.jobVerbs[v].args, keys = Object.keys(a);
        return v + (keys.length ? (' {' + keys.map(function (k) { return k + ':' + a[k]; }).join(', ') + '}') : '');
      });
    }

    // ---- executeJob: the job-EXECUTION half, factored out of the `do` handler so BOTH the human
    //      `!chloe do {json}` path AND the model tool-loop can run a VALIDATED job identically. Callers
    //      MUST validate first (parseJob). Takes (task, args, {authorId, authorName}) and returns the SAME
    //      Promise<{ack, ...}> the `do` handler used to return inline. Behaviour-preserving: the human path
    //      passes authorName '' exactly as before, so `!chloe do` is byte-for-byte unchanged. ----
    function executeJob(task, args, who) {
      who = who || {};
      var authorId = who.authorId, authorName = who.authorName || '';
      var a = args || {};
      if (task === 'roster') {
        return getRoster().then(function (r) {
          var names = r.slice(0, 20).map(function (u) { return u.name + (u.state && u.state !== 'active' ? ' (' + u.state + ')' : ''); });
          return { ack: r.length + ' here: ' + (names.join(', ') || '\\u2014') };
        });
      }
      if (task === 'recap' || task === 'summarize') {
        if (typeof cfg.recapFn !== 'function') return Promise.resolve({ ack: 'summaries are not available right now' });
        return assembleContext({ authorId: authorId, authorName: authorName, content: '' }).then(function (ctx) {
          var lines = (ctx && ctx.channelRecent) ? ctx.channelRecent : [];
          if (task === 'summarize' && a.lines) lines = lines.slice(-a.lines);
          return Promise.resolve(cfg.recapFn({ recent: lines })).then(function (res) {
            return { ack: (res && res.ok) ? res.value : 'could not summarize right now' };
          });
        });
      }
      if (task === 'remindme') {
        return scheduleReminder({ minutes: a.minutes, text: a.text, authorId: authorId, authorName: authorName, dm: !!a.dm }).then(function (res) {
          if (!res.ok) return { ack: 'could not set that reminder: ' + res.reason };
          return { ack: "ok — i'll remind you in " + a.minutes + 'm: “' + String(a.text).slice(0, 60) + '”' };
        });
      }
      if (task === 'search') {
        if (typeof cfg.search !== 'function') return Promise.resolve({ ack: 'search is not available right now' });
        var sq = String(a.query || '').trim().slice(0, 300);
        return Promise.resolve(cfg.search(sq)).then(function (res) {
          if (!res || !res.ok) return { ack: 'no results for \u201c' + sq.slice(0, 80) + '\u201d (' + ((res && res.reason) || 'n/a') + ')' };
          return { ack: 'here\u2019s what I found for \u201c' + sq.slice(0, 80) + '\u201d:\n' + String(res.value).slice(0, 1500) };
        });
      }
      if (task === 'fetch') {
        if (typeof cfg.fetch !== 'function') return Promise.resolve({ ack: 'page reading is not available right now' });
        return Promise.resolve(cfg.fetch(a.url)).then(function (res) {
          if (!res || !res.ok) return { ack: 'could not read that page (' + ((res && res.reason) || 'n/a') + ')' };
          return { ack: 'I read the page. It says:\n' + String(res.value).slice(0, 1500) };
        });
      }
      if (task === 'time') {
        var tzn = Number(cfg.timezoneOffsetMins) || 0;
        var hh = new Date(clock.now() + tzn * 60000).toISOString().slice(11, 16);
        var tsign = tzn < 0 ? '-' : '+';
        var th = Math.floor(Math.abs(tzn) / 60), tm = Math.abs(tzn) % 60;
        return Promise.resolve({ ack: 'it is ' + hh + ' here (UTC' + tsign + th + (tm ? ':' + (tm < 10 ? '0' : '') + tm : '') + ')' });
      }
      if (task === 'todo_add') {
        return addTodo(authorId, authorName, a.text).then(function (res) {
          if (!res.ok) return { ack: res.reason };
          return listTodos(authorId).then(function (mine) { return { ack: 'noted (' + mine.length + ' on your list): ' + String(res.value.text).slice(0, 80) }; });
        });
      }
      if (task === 'todo_list') {
        return listTodos(authorId).then(function (mine) {
          if (!mine.length) return { ack: 'your list is empty — say the word and I will add to it' };
          var lines = mine.slice(0, 20).map(function (t, k) { return (k + 1) + '. ' + t.text.slice(0, 80); });
          return { ack: 'your list:\n' + lines.join('\n') };
        });
      }
      if (task === 'todo_done') {
        return doneTodo(authorId, a.index).then(function (res) {
          if (!res.ok) return { ack: res.reason || 'could not check that off' };
          return { ack: 'done — ' + String(res.removed.text).slice(0, 80) };
        });
      }
      if (task === 'todo_clear') {
        return clearTodos(authorId).then(function (n) { return { ack: n ? ('cleared ' + n + ' todo' + (n === 1 ? '' : 's')) : 'your list was already empty' }; });
      }
      if (task === 'almanac') {
        if (typeof cfg.almanac !== 'function') return Promise.resolve({ ack: 'lookups are not available right now' });
        return Promise.resolve(cfg.almanac({ kind: a.kind, query: a.query, extra: a.extra })).then(function (res) {
          if (!res || !res.ok) return { ack: 'could not look that up (' + ((res && res.reason) || 'n/a') + ')' };
          return { ack: String(res.value).slice(0, 1500) };
        });
      }
      if (task === 'roll') {
        var rd = rollDice(a.dice);
        if (!rd.ok) return Promise.resolve({ ack: rd.reason + ' (100 dice, d1000 max)' });
        return Promise.resolve({ ack: 'rolled ' + String(a.dice).trim() + rd.detail + ' = ' + rd.total });
      }
      return Promise.resolve({ ack: 'task "' + task + '" is valid but not wired yet' });
    }

    // ---- SAFE model-tool whitelist + dispatcher (model tool-loop, item 1 = dispatch-only). The model may emit
    //      `tool:` lines, which the PAGE parses + STRIPS from the visible reply and returns as r.toolCalls. Here we
    //      run each ONLY if its verb is in this explicit SAFE set (information + self-reminders). A moderation or
    //      destructive verb is REFUSED + logged, NEVER executed, even if the model emits `tool: block {...}` — a
    //      jailbroken/prompt-injected reply cannot moderate or destroy. Each call is re-VALIDATED through the SAME
    //      parseJob the human `do` path uses (types/caps/required args), then run via executeJob. This fires ONLY on
    //      model-emitted toolCalls (never on a `!chloe do`), so there is no double-dispatch. Item-1 scope = dispatch
    //      + log the ack; the re-prompt-with-results ReAct loop is item 2. FAIL-OPEN: any throw leaves the posted
    //      reply untouched. ----
    var SAFE_TOOL_VERBS = { summarize: 1, recap: 1, remindme: 1, roster: 1, search: 1, fetch: 1, almanac: 1, time: 1, roll: 1, todo_add: 1, todo_list: 1, todo_done: 1, todo_clear: 1 };
    // QUERY tools return DATA to feed back into a second reply (handled by reactRespond, bounded to one
    // round) — they are NOT fire-and-forget, so dispatchModelTools SKIPS them (prevents a redundant 2nd
    // search when the terminal dispatch runs on the already-fed-back final reply). ACTION tools (the rest)
    // keep item-1 dispatch-only behavior.
    var QUERY_TOOL_VERBS = { search: 1, fetch: 1, almanac: 1 };
    function dispatchModelTools(r, p) {
      try {
        if (!cfg.toolsEnabled) return;                       // OFF -> no dispatch (byte-identical reply path)
        var calls = (r && Array.isArray(r.toolCalls)) ? r.toolCalls : null;
        if (!calls || !calls.length) return;
        var ran = 0, cap = cfg.toolMaxPerReply || 4;
        for (var i = 0; i < calls.length && ran < cap; i++) {
          var call = calls[i] || {};
          var verb = String(call.verb || '').toLowerCase().trim();
          if (QUERY_TOOL_VERBS[verb]) { continue; }          // a QUERY tool is handled by the ReAct loop, never fire-and-forget here
          if (!SAFE_TOOL_VERBS[verb]) { log('[chloe.tool] REFUSED non-safe model tool "' + verb + '" (safe: ' + Object.keys(SAFE_TOOL_VERBS).join(', ') + ')'); continue; }
          var args = (call.args && typeof call.args === 'object' && !Array.isArray(call.args)) ? call.args : {};
          var parsed;
          try { parsed = parseJob(JSON.stringify({ task: verb, args: args })); } catch (e) { parsed = { ok: false, reason: 'args not serialisable' }; }
          if (!parsed.ok) { log('[chloe.tool] model tool "' + verb + '" rejected: ' + parsed.reason); continue; }
          ran++;
          (function (vb, job) {
            try {
              Promise.resolve(executeJob(job.task, job.args, { authorId: p.authorId, authorName: p.authorName || '' }))
                .then(function (res) { log('[chloe.tool] ran "' + vb + '" → ' + ((res && res.ack) ? String(res.ack).slice(0, 140) : 'ok')); },
                      function (e) { log('[chloe.tool] "' + vb + '" failed: ' + ((e && e.message) || e)); });
            } catch (e) { log('[chloe.tool] "' + vb + '" dispatch error: ' + ((e && e.message) || e)); }
          })(verb, parsed.job);
        }
      } catch (e) { try { log('[wire: dispatchModelTools]', (e && e.message) || e); } catch (e2) {} }   // fail-open (never break the reply) but LOUD — Rule X: a swallowed tool-path throw is a bug you'd never see
    }

    // ---- bounded ReAct loop (model tool-loop, item 2). After the FIRST cfg.respond, if the reply emitted a
    //      QUERY tool (search), run it, inject the results as ctx.toolResults, and RE-CALL cfg.respond ONCE so
    //      it answers WITH the data. BOUNDED: exactly one extra round — we return that second reply no matter
    //      what it emits, so a 2nd search never triggers a 3rd round (loop-breaker). ACTION-only replies take
    //      NO extra round (item-1 behavior; the terminal dispatch handles them). FAIL-OPEN: any search/re-respond
    //      error returns the ORIGINAL reply, so the reply path degrades to exactly what it would be without tools.
    //      OFF (toolsEnabled false) => a single cfg.respond, byte-identical. ----
    function reactRespond(ctx, p) {
      return Promise.resolve(cfg.respond(ctx)).then(function (r1) {
        try {
          if (!cfg.toolsEnabled) return r1;                                   // OFF: one respond, nothing else
          var calls = (r1 && Array.isArray(r1.toolCalls)) ? r1.toolCalls : null;
          if (!calls || !calls.length) return r1;
          if (typeof cfg.search !== 'function' && typeof cfg.fetch !== 'function' && typeof cfg.almanac !== 'function') return r1;   // no query transport -> fail-open
          var queries = calls.filter(function (c) { var v = String((c && c.verb) || '').toLowerCase().trim(); return QUERY_TOOL_VERBS[v] && SAFE_TOOL_VERBS[v]; });
          if (!queries.length) return r1;                                     // ACTION-only -> no re-respond (item-1)
          var cap = cfg.queryMaxPerReply || 2;
          var chain = Promise.resolve([]);
          queries.slice(0, cap).forEach(function (c) {
            chain = chain.then(function (acc) {
              var v = String((c && c.verb) || '').toLowerCase().trim();
              var qa = (c.args && typeof c.args === 'object') ? c.args : {};
              var label = '', run = null;
              if (v === 'fetch') { var fu = String(qa.url != null ? qa.url : '').trim(); label = fu.slice(0, 200); if (fu && typeof cfg.fetch === 'function') run = function () { return Promise.resolve(cfg.fetch(fu)); }; }
              else if (v === 'almanac') { var ak2 = String(qa.kind != null ? qa.kind : '').toLowerCase().trim(), aq2 = String(qa.query != null ? qa.query : '').trim(); label = ak2.slice(0, 40) + ': ' + aq2.slice(0, 160); if (ak2 && (aq2 || ak2 === 'onthisday' || ak2 === 'quote') && typeof cfg.almanac === 'function') run = function () { return Promise.resolve(cfg.almanac({ kind: ak2, query: aq2, extra: qa.extra })); }; }
              else { var sq = String(qa.query != null ? qa.query : '').trim(); label = sq.slice(0, 200); if (sq && typeof cfg.search === 'function') run = function () { return Promise.resolve(cfg.search(sq)); }; }
              if (!run) { log('[wire:react] ' + v + ' skipped (no query text or no transport)'); return acc; }
              return run().then(function (res) {
                if (res && res.ok && res.value) acc.push({ verb: v, query: label, result: String(res.value) });
                else log('[wire:react] ' + v + ' returned nothing (' + ((res && res.reason) || 'n/a') + ')');
                return acc;
              }, function () { return acc; });               // a single query throw never breaks the round
            });
          });
          return chain.then(function (results) {
            if (!results.length) return r1;                  // nothing usable came back -> keep the original reply
            var ctx2 = {};
            for (var k in ctx) { if (Object.prototype.hasOwnProperty.call(ctx, k)) ctx2[k] = ctx[k]; }
            ctx2.toolResults = results;                      // the FEED-BACK seam — the page reads this and grounds the 2nd reply
            ctx2.reactRound = 1;                             // marker: we are IN the one allowed extra round
            log('[wire:react] re-respond with ' + results.length + ' query result(s)');
            return Promise.resolve(cfg.respond(ctx2)).then(function (r2) {
              // BOUNDED: return the 2nd reply whatever it emits — we NEVER re-enter, so no 3rd round.
              return (r2 && r2.ok) ? r2 : r1;                // if the 2nd round somehow produced nothing, keep the first
            }, function (e) { log('[wire:react] re-respond failed -> original: ' + ((e && e.message) || e)); return r1; });
          });
        } catch (e) { log('[wire:react] error -> original reply: ' + ((e && e.message) || e)); return r1; }
      });
    }

    function removeFromIndex(id) {
      // Use a targeted-remove via userStore().removeFromIndex so the write only drops the one id
      // rather than replacing the full array — concurrent ensureIndexed adds won't be lost.
      var ustore = userStore();
      if (typeof ustore.removeFromIndex === 'function') return ustore.removeFromIndex(id);
      return Promise.resolve(ustore.listIndex()).then(function (ids) {
        var next = (ids || []).filter(function (x) { return x !== id; });
        return ustore.setIndex(next);
      });
    }
    // Separate, purge-surviving record of what mods DID (not a memory of the user) — spec 5.6/decision #5.
    // A3: entries are hash-chained (ChloeModAudit) — tamper-evident, verified by `mod.verifyLog`.
    function appendModLog(entry) {
      if (!cfg.keepActionLog) return Promise.resolve(false);
      return Promise.resolve(store.get('modlog')).then(function (log) {
        log = log || [];
        if (typeof ChloeModAudit !== 'undefined' && ChloeModAudit.appendChained) {
          var r = ChloeModAudit.appendChained(log, entry);
          if (!r.ok) { log.push(entry); }   // unchainable shape: keep the record, just unchained
          else log = r.value;
        } else {
          log.push(entry);
        }
        if (log.length > 500) log = log.slice(-500);
        return store.set('modlog', log).then(function () { return true; });
      });
    }
    function getModLog() { return Promise.resolve(store.get('modlog')).then(function (l) { return l || []; }); }
    function verifyModLog() {
      return getModLog().then(function (l) {
        if (typeof ChloeModAudit === 'undefined' || !ChloeModAudit.verifyChain) {
          return { ok: true, chained: 0, preChain: (l || []).length, legacy: true };
        }
        return ChloeModAudit.verifyChain(l);
      });
    }

    // ---- T5 lifecycle / departure / backfill ---------------------------------------------
    // active -> quiet: a user who has aged out of the attention window (not under moderation).
    function quietSweep() {
      var now = clock.now();
      return Promise.resolve(userStore().listIndex()).then(function (ids) {
        var chain = Promise.resolve(), demoted = 0, archived = 0;
        (ids || []).forEach(function (id) {
          chain = chain.then(function () {
            return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
              if (!p || p.lifecycle === 'departed') return;
              if (p.state && p.state !== 'active') return;       // moderation rows are not "quiet"
              // Data tiering: a long-cold user is moved to the historical-friends archive so the hot
              // roster stays small. Favorite-aware — more interaction buys more patience before archival.
              if (cfg.archiveStale && (now - (p.lastSeen || 0)) >= archiveThresholdFor(p)) {
                archived++; return archiveUser(id, 'long-absent');
              }
              if ((now - (p.lastSeen || 0)) >= cfg.quietAfterMs && p.lifecycle !== 'quiet') {
                p.lifecycle = 'quiet'; demoted++; return userStore().set(partKey(id), p);
              }
            });
          });
        });
        return chain.then(function () { quietSweep._archived = archived; return demoted; });
      });
    }
    // Bounded, prioritized list of users worth a 404 membership check (transport runs the checks).
    function dueForMemberCheck(max) {
      max = max || 5; var now = clock.now();
      return Promise.resolve(userStore().listIndex()).then(function (ids) {
        return Promise.all((ids || []).map(function (id) { return Promise.resolve(userStore().get(partKey(id))); })).then(function (ps) {
          var cands = [];
          ps.forEach(function (p) {
            if (!p || p.lifecycle === 'departed') return;
            if ((now - (p.lastSeen || 0)) < cfg.quietAfterMs) return;           // only aged-out users
            if ((now - (p.lastMemberCheckAt || 0)) < cfg.quietAfterMs) return;  // don't re-check too often
            cands.push({ id: p.id, name: p.name, silentMs: now - (p.lastSeen || 0) });
          });
          cands.sort(function (a, b) { return b.silentMs - a.silentMs; });       // longest-silent first
          return cands.slice(0, max);
        });
      });
    }
    function noteMemberPresent(id) {
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) { if (!p) return; p.lastMemberCheckAt = clock.now(); return userStore().set(partKey(id), p); });
    }
    // 404-confirmed gone: clear ordinary memory, but KEEP any moderation row (a soft-ban must survive
    // a departure so it still applies if they return). Quiet adjustment only — never announced.
    function markDeparted(id) {
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (!p) return { ok: false, reason: 'unknown' };
        p.lifecycle = 'departed'; p.departedAt = clock.now();
        p.recent = []; p.interactionCount = 0; p.lastGreetedAt = null;
        return userStore().set(partKey(id), p).then(function () { return { ok: true, value: { id: id, name: p.name } }; });
      });
    }
    function ingestHistorical(msg) {
      var id = msg.author.id;
      if (cfg.botUserId && id === cfg.botUserId) return Promise.resolve();
      // ethereal users learn nothing from history either; and even for a user who has since done
      // `remember me`, never reach back across their forget-floor and resurrect erased lines.
      return isEthereal(id).then(function (eth) {
        if (eth) return Promise.resolve();
        return forgetFloorOf(id).then(function (floor) {
          if (floor && toEpoch(msg.timestamp) < floor) return Promise.resolve();   // pre-forget history stays forgotten
          return ingestHistoricalCore(msg);
        });
      });
    }
    function ingestHistoricalCore(msg) {
      var id = msg.author.id;
      return loadPartition(id).then(function (existing) {
        var seenAt = toEpoch(msg.timestamp);
        var p = existing || { id: id, name: msg.author.username, firstSeen: seenAt, lastSeen: seenAt, interactionCount: 0, state: 'active', lifecycle: 'quiet', recent: [] };
        p.name = p.name || msg.author.username;
        p.firstSeen = Math.min(p.firstSeen || seenAt, seenAt);
        var dupH = false; for (var hi = 0; hi < (p.recent || []).length; hi++) { if (String(p.recent[hi].id) === String(msg.id)) { dupH = true; break; } }
        if (!dupH) p.recent.push({ id: msg.id, ts: seenAt, content: msg.content || '', ch: cfg.channelId });
        p.recent = smartTrimRecent(p.recent || [], cfg.recentWindow);
        return ensureIndexed(id).then(function () { return userStore().set(partKey(id), p); });
      });
    }
    // One bounded, checkpointed page of history per call (ingest only — never greets or replies).
    function backfillStep(fetchBefore) {
      return Promise.resolve(store.get(BACKFILL_KEY)).then(function (cp) {
        cp = cp || { before: null, pages: 0, done: false, ingested: 0 };
        if (cp.done) return { done: true, pages: cp.pages, ingested: cp.ingested };
        if (cp.pages >= cfg.backfillMaxPages) { cp.done = true; return store.set(BACKFILL_KEY, cp).then(function () { return { done: true, pages: cp.pages, ingested: cp.ingested, reason: 'maxPages' }; }); }
        var startP = cp.before ? Promise.resolve(cp.before) : Promise.resolve(store.get(CURSOR_KEY));
        return startP.then(function (before) {
          return Promise.resolve(fetchBefore(before || null, cfg.backfillPageSize)).then(function (msgs) {
            msgs = msgs || [];
            if (!msgs.length) { cp.done = true; return store.set(BACKFILL_KEY, cp).then(function () { return { done: true, pages: cp.pages, ingested: cp.ingested, reason: 'empty' }; }); }
            var oldest = msgs[0].id; msgs.forEach(function (m) { if (snowflakeCmp(m.id, oldest) < 0) oldest = m.id; });
            var chain = Promise.resolve(), n = 0;
            msgs.forEach(function (m) { chain = chain.then(function () { n++; return ingestHistorical(m); }); });
            return chain.then(function () {
              cp.before = oldest; cp.pages += 1; cp.ingested += n;
              if (msgs.length < cfg.backfillPageSize) cp.done = true;
              return store.set(BACKFILL_KEY, cp).then(function () { return { done: cp.done, pages: cp.pages, ingested: cp.ingested }; });
            });
          });
        });
      });
    }

    // Per-channel re-pull: drop the history-walk checkpoint so the next
    // maintenance pass walks this channel again (wiring also clears the
    // backfillDone flag and re-arms the driver). Never throws.
    function resetBackfill() {
      return Promise.resolve(store.del(BACKFILL_KEY)).then(function () { return { ok: true }; }, function () { return { ok: true }; });
    }

    // T4: irreversible purge. Deletes the partition and de-indexes, then VERIFIES the delete
    // actually round-tripped (the partition is truly gone) — a silently-failed moderation delete
    // is the one bug that matters most, so we never *assume* it worked.
    function purge(targetId, opts) {
      opts = opts || {};
      if (!targetId) return Promise.resolve({ ok: false, reason: 'no target' });
      var ustore = userStore();
      return Promise.resolve(ustore.get(partKey(targetId))).then(function (p) {
        var name = (p && p.name) || opts.targetName || targetId;
        return Promise.resolve(ustore.del(partKey(targetId)))
          .then(function () { return removeFromIndex(targetId); })
          .then(function () {
            // shared pool: also clear the pre-upgrade local copy (raw handle — the gated
            // `store` would silently drop the delete, leaving a GDPR-violating remnant)
            if (!sharedUsers()) return null;
            return Promise.resolve(localRaw.del(partKey(targetId))).catch(function () {});
          })
          .then(function () {
            if (!sharedUsers() || typeof localRaw.removeFromIndex !== 'function') return null;
            return Promise.resolve(localRaw.removeFromIndex(targetId)).catch(function () {});
          })
          .then(function () { return dropFromArchive(targetId); })   // erasure must include the cold copy, not just the hot one
          .then(function () { return dropEpisodesFor(targetId, name); })   // and episodes they took part in
          .then(function () { return dropGoalsFor(targetId); })   // and any goals we tracked for them
          .then(function () { return Promise.resolve(ustore.get(partKey(targetId))); })   // read back
          .then(function (after) {
            return ustore.listIndex().then(function (ids) {
              var gone = (after == null) && (ids || []).indexOf(targetId) < 0;
              if (!gone) return { ok: false, verified: false, name: name, reason: 'delete did NOT round-trip (partition still present in the store)' };
              return { ok: true, verified: true, name: name, targetId: targetId };
            });
          });
      });
    }

    // Command registry: one declarative table is the single source of truth for which verbs exist,
    // how their args parse, whether they need a target, and the help text. parseCommand + execCommand
    // + help are all generated from it (no more KNOWN_CMDS / CMD_ACTION / hand-written help drift).
    // aliases[] is supported (emoji/short forms) though none are defined yet — see roadmap #10.
    var COMMANDS = [
      { verb: 'ignore',    modOnly: true, needsTarget: true, action: 'ignore',  help: 'ignore @u' },
      { verb: 'unignore',  modOnly: true, needsTarget: true, action: 'clear' },
      { verb: 'timeout',   modOnly: true, needsTarget: true, takesDuration: true, action: 'timeout', help: 'timeout @u 1h [reason]' },
      { verb: 'untimeout', modOnly: true, needsTarget: true, action: 'clear' },
      { verb: 'softban',   modOnly: true, needsTarget: true, action: 'softban', help: 'softban @u' },
      { verb: 'unsoftban', modOnly: true, needsTarget: true, action: 'clear' },
      { verb: 'clear',     modOnly: true, needsTarget: true, action: 'clear',   help: 'clear @u' },
      { verb: 'note',      modOnly: true, needsTarget: true, action: 'note',    help: 'note @u <text>' },
      { verb: 'warn',      modOnly: true, needsTarget: true, action: 'warn',    aliases: ['\u26a0\ufe0f'], help: 'warn @u [reason]' },
      { verb: 'block',     modOnly: true, needsTarget: true, help: 'block @u [reason]', handler: function (modId, c) {
          if (!c.targetId) return Promise.resolve({ ack: 'block needs an @mention of the user' });
          return blockUser({ id: c.targetId, name: c.targetName, byModId: modId, reason: c.reason })
            .then(function (r) { return { ack: r.ok ? ('blocked ' + (c.targetName || c.targetId) + " \u2014 they're forgotten and will never be scanned again") : ('failed: ' + r.reason) }; });
        } },
      { verb: 'unblock',   modOnly: true, needsTarget: true, help: 'unblock @u', handler: function (modId, c) {
          if (!c.targetId) return Promise.resolve({ ack: 'unblock needs an @mention of the user' });
          return unblockUser({ id: c.targetId, name: c.targetName })
            .then(function (r) { return { ack: r.ok ? ('unblocked ' + (c.targetName || c.targetId) + ' \u2014 it can form memory of them again') : ((c.targetName || c.targetId) + ' was not on the blocklist') }; });
        } },
      { verb: 'warns',     modOnly: true, needsTarget: true, help: 'warns @u', handler: function (modId, c) {
          if (!c.targetId) return Promise.resolve({ ack: 'warns needs an @mention of the user' });
          return Promise.resolve(userStore().get(partKey(c.targetId))).then(function (p) {
            if (!p) return { ack: 'I have no record of that user' };
            var n = p.strikes || 0;
            return { ack: (p.name || c.targetId) + ': ' + n + ' strike' + (n === 1 ? '' : 's') + (p.state && p.state !== 'active' ? ' \u2014 currently ' + p.state : '') };
          });
        } },
      { verb: 'persona',   modOnly: true, help: 'persona [clear]', handler: function (modId, c) {
          if (/^clear\b/i.test(c.reason || '')) return clearPersonaNote().then(function () { return { ack: 'persona note cleared' }; });
          return getPersonaNote().then(function (pn) {
            return { ack: (pn && pn.text) ? ('current persona note (anchored by ' + (pn.by || 'a mod') + '): ' + pn.text) : ('no persona note anchored \u2014 a mod can react ' + (cfg.anchorEmoji || '\ud83d\udccc') + ' to a message to set one') };
          });
        } },
      { verb: 'goals',     modOnly: false, help: 'goals  (your goals; mods: all)', handler: function (uid, c) {
          var mid = c && c.messageId;
          return loadGoals().then(function (list) {
            var now = clock.now();
            var mine = list.filter(function (g) { return g.status === 'open' && (isMod(uid) || g.owner === uid); });
            if (!mine.length) return { ack: isMod(uid) ? 'no open goals on record' : 'I\u2019m not tracking any goals for you \u2014 set one with ' + (cfg.commandPrefix || '!chloe') + ' goal <what you\u2019re working on>' };
            var linesOut = mine.slice(0, 12).map(function (g) {
              var age = Math.max(1, Math.round((now - (g.createdAt || now)) / 86400000));
              return '\u2022 [' + g.id + '] ' + g.text + (isMod(uid) && g.ownerName ? ' (' + g.ownerName + ')' : '') + ' \u2014 ' + age + 'd';
            }).join('\n');
            return { ack: null, embed: embedFor('Goals', linesOut), ackSrc: mid };
          });
        } },
      { verb: 'goal',      modOnly: false, help: 'goal <text>  /  goal done <id>  /  goal drop <id>', handler: function (uid, c) {
          var args = String((c && c.rawArgs) || '').trim();
          var m = args.match(/^(done|drop)\s+(\S+)$/i);
          if (m) {
            return closeGoal(m[2], uid, /drop/i.test(m[1]) ? 'dropped' : 'done').then(function (r) {
              return { ack: r.ok ? ('goal ' + (r.goal.status === 'done' ? 'marked done' : 'dropped') + ' \u2014 \u201c' + r.goal.text + '\u201d') : r.reason };
            });
          }
          if (!args) return Promise.resolve({ ack: 'tell me what you\u2019re working on: ' + (cfg.commandPrefix || '!chloe') + ' goal <text>' });
          return Promise.resolve(userStore().get(partKey(uid))).then(function (pp) {
            return addGoal(args, uid, (pp && pp.name) || '', 'command').then(function (g) {
              return { ack: g ? ('got it \u2014 I\u2019ll remember you\u2019re working on that (' + g.id + ')') : 'couldn\u2019t note that' };
            });
          });
        } },
      { verb: 'skill',     modOnly: true, help: 'skill add <name> | <triggers> | <text>  /  skill show <name>  /  skill drop <name>', handler: function (modId, c) {
          var sargs = String((c && c.rawArgs) || '').trim();
          var sm = sargs.match(/^(add|show|drop|remove|delete)\s+([\s\S]+)$/i);
          if (!sm) return Promise.resolve({ ack: 'usage: ' + (cfg.commandPrefix || '!chloe') + ' skill add <name> | <trigger words> | <text>' });
          var sop = sm[1].toLowerCase(), srest = sm[2].trim();
          if (sop === 'show') {
            return getSkills().then(function (slist) {
              var shit = slist.filter(function (s) { return String(s.name || '').toLowerCase() === srest.toLowerCase(); })[0];
              return { ack: shit ? ('[' + shit.name + '] triggers: ' + (shit.triggers || []).join(', ') + '\n' + String(shit.text).slice(0, 600)) : 'no skill named "' + srest.slice(0, 40) + '"' };
            });
          }
          if (sop === 'drop' || sop === 'remove' || sop === 'delete') {
            return dropSkill(srest).then(function (n) { return { ack: n ? ('dropped "' + srest.slice(0, 40) + '"') : 'no skill named "' + srest.slice(0, 40) + '"' }; });
          }
          var sparts = srest.split('|').map(function (s) { return s.trim(); });
          if (sparts.length < 3 || !sparts[0] || !sparts[1] || !sparts[2]) return Promise.resolve({ ack: 'usage: skill add <name> | <trigger words, comma-separated> | <the knowledge itself>' });
          return addSkill(sparts[0], sparts[1], sparts.slice(2).join(' | '), (c && c.authorName) || '').then(function (r) {
            return { ack: r.ok ? ((r.updated ? 'updated' : 'saved') + ' "' + r.value.name + '" - I will use it when people talk about ' + (r.value.triggers || []).slice(0, 5).join(', ')) : r.reason };
          });
        } },
      { verb: 'skills',    modOnly: false, help: 'skills  (list the server knowledge packs)', handler: function (uid, c) {
          return getSkills().then(function (list) {
            if (!list.length) return { ack: 'no server knowledge saved yet - mods can add some with ' + (cfg.commandPrefix || '!chloe') + ' skill add <name> | <trigger words> | <text>' };
            var linesOut = list.slice(0, 20).map(function (s) { return '- ' + s.name + ' (' + (s.triggers || []).slice(0, 5).join(', ') + ')'; }).join('\n');
            return { ack: 'server knowledge:\n' + linesOut };
          });
        } },
      { verb: 'game',      modOnly: false, help: 'game list · game settings [wordle] [key value] · game start wordle · game stop', handler: function (uid, c) {
        if (typeof ChloeGames === 'undefined' || !ChloeGames.get('wordle')) return Promise.resolve({ ack: 'games need the latest engine — reload the panel (it upgrades automatically) and Stop+Start the bot' });
        var gio = { get: function (k) { return store.get(k); }, set: function (k, v) { return store.set(k, v); } };
        return ChloeGames.get('wordle').handleGame({ uid: String(uid), name: (c && c.authorName) || '', isMod: isMod(uid), prefix: cfg.commandPrefix || '!chloe', now: clock.now(), io: gio, channelId: cfg.channelId }, String((c && c.rawArgs) || '').trim());
      } },
      { verb: 'wordle',    modOnly: false, help: 'wordle CRANE (guess the 5-letter word) · wordle board · wordle stats', handler: function (uid, c) {
        if (typeof ChloeWordle === 'undefined') return Promise.resolve({ ack: 'wordle needs the latest engine — reload the panel (it upgrades automatically) and Stop+Start the bot' });
        var wio = { get: function (k) { return store.get(k); }, set: function (k, v) { return store.set(k, v); } };
        return ChloeWordle.handleWordle({ uid: String(uid), name: (c && c.authorName) || '', isMod: isMod(uid), prefix: cfg.commandPrefix || '!chloe', now: clock.now(), io: wio, channelId: cfg.channelId }, String((c && c.rawArgs) || '').trim());
      } },
      { verb: 'policy',    modOnly: false, help: 'policy [allow|ask|deny] (gate its proactive output: beats, check-ins, lull, thoughts feed, news — setting is mods-only)', handler: function (uid, c) {
        var a = normArg(c);
        var p = (cfg.actPolicy === 'ask' || cfg.actPolicy === 'deny') ? cfg.actPolicy : 'allow';
        if (!a) {
          return getPendingAct().then(function (list) {
            return { ack: 'actuation policy: ' + p + (list.length ? ' — ' + list.length + ' held (' + (cfg.commandPrefix || '!chloe') + ' approvals)' : ' — nothing held') };
          });
        }
       if (!isMod(uid)) return Promise.resolve({ ack: 'only mods can set the policy — it is currently ' + p });
       if (a !== 'allow' && a !== 'ask' && a !== 'deny') return Promise.resolve({ ack: 'policy must be allow|ask|deny (currently ' + p + ')' });
       cfg.actPolicy = a;
       log('[chloe.act] policy set to ' + a + ' by mod');
        var polAck = 'actuation policy: ' + a + (a === 'ask' ? ' — beats, check-ins and lull fillers will hold for approval' : a === 'deny' ? ' — no proactive output until you allow it' : ' — proactive output fires freely');
        return pushUndoEntry({ kind: 'policy', by: String(uid), summary: 'policy ' + p + ' -> ' + a, inverse: { before: p, after: a } }).then(function () {
          return { ack: polAck, actPolicyTouched: true, actPolicy: a };
        });
      } },
      { verb: 'approvals', modOnly: false, help: 'approvals (held proactive output awaiting a mod)', handler: function (uid, c) {
        return getPendingAct().then(function (list) {
          if (!list.length) return { ack: 'nothing held for approval' };
          var now = clock.now();
          return { ack: 'held for approval:\n' + list.map(function (e, i) {
            var age = Math.max(0, Math.round((now - (e.at || now)) / 60000));
            return (i + 1) + '. ' + e.class + ' — ' + e.reason + ' (' + age + 'm ago, id ' + e.id + ')';
          }).join('\n') + '\nmods: ' + (cfg.commandPrefix || '!chloe') + ' approve <id>|all [always], or dismiss' };
        });
      } },
      { verb: 'approve',   modOnly: true, help: 'approve <id>|all [always] (release held output once; always = remember it)', handler: function (modId, c) {
        var parts = String((c && c.rawArgs) || '').trim().split(/\s+/).filter(Boolean);
        var id = parts[0] || 'all';
        var always = parts.slice(1).join(' ').toLowerCase() === 'always';
        return approveAct(id, always, modId).then(function (r) {
          if (!r.approved.length) return { ack: 'nothing held' + (id !== 'all' ? ' with that id' : '') };
          var out = 'approved ' + r.approved.length + ' (' + r.classes.join(', ') + ') — each fires once on the next poll';
          var res = { ack: out };
          if (always && r.grants && r.grants.length) {
            // New grant specs ride the poll summary to wiring, which merges them into the
            // persisted GM cfg (dedupe) and patches all live engines. The local cfg is ALSO
            // updated now so gates in this same process see them before that patch lands.
            var cur = Array.isArray(cfg.actGrants) ? cfg.actGrants.slice() : [];
            r.grants.forEach(function (g) {
              if (!cur.some(function (e) { return e && e.action === g.action && e.resource === g.resource && e.scope === g.scope; })) cur.push(g);
            });
            cfg.actGrants = cur;
            res.ack = out + ' + always-granted (' + r.classes.join(', ') + ' in here)';
            res.actGrantsTouched = true;
            res.actGrants = r.grants;
          }
          return res;
        });
      } },
      { verb: 'dismiss',   modOnly: true, help: 'dismiss <id>|all (drop held output, quiet for a day)', handler: function (modId, c) {
        var id = String((c && c.rawArgs) || '').trim().split(/\s+/)[0] || 'all';
        return dismissAct(id, modId).then(function (r) {
          if (!r.dismissed.length) return { ack: 'nothing held' + (id !== 'all' ? ' with that id' : '') };
          return { ack: 'dismissed ' + r.dismissed.length + ' — that output stays quiet for a day' };
        });
      } },
      { verb: 'undo',      modOnly: true, help: 'undo (revert the last applied action — mod action, approval, grant, policy, elevation, quarantine, mod list)', handler: function (modId, c) {
        return undoLastApplied().then(function (r) {
          if (!r.ok) return { ack: r.reason };
          var res = { ack: 'undid: ' + r.summary };
          if (r.persist) {
            if (r.persist.actPolicy !== undefined) { res.actPolicyTouched = true; res.actPolicy = r.persist.actPolicy; }
            if (r.persist.actGrants !== undefined) { res.actGrantsTouched = true; res.actGrants = r.persist.actGrants; }
            if (r.persist.modList !== undefined) { res.modListTouched = true; res.modList = r.persist.modList; }
            if (r.persist.beats !== undefined) { res.beatsTouched = true; res.beats = r.persist.beats; }
            if (r.persist.autoModRules !== undefined) { res.autoModRulesTouched = true; res.autoModRules = r.persist.autoModRules; }
            if (r.persist.procRules !== undefined) { res.procRulesTouched = true; res.procRules = r.persist.procRules; }
            if (r.persist.restash !== undefined) { res.quarantineTouched = true; res.quarantine = r.persist.restash; }
          }
          return res;
        });
      } },
      { verb: 'clearance', modOnly: false, help: 'clearance [@u] (your clearance tier; mods can look up anyone)', handler: function (uid, c) {
        var tid = (c && c.targetId) ? String(c.targetId) : '';
        if (tid && !isMod(uid)) return Promise.resolve({ ack: 'only mods can look up someone else\'s clearance — yours is below' }).then(function (r) {
          return clearanceOf(uid).then(function (t) { return { ack: 'only mods can look up someone else\'s clearance. your clearance: ' + t.tier + ' (' + t.basis + ')' }; });
        });
        var who = tid || String(uid);
        var label = tid ? ((c && c.targetName) || who) : 'your clearance';
        return clearanceOf(who).then(function (t) {
          var next = t.tier === 'guest' ? 'a mod can elevate with ' + (cfg.commandPrefix || '!chloe') + ' elevate' : (t.tier === 'resident' ? 'a mod can elevate to admin with ' + (cfg.commandPrefix || '!chloe') + ' elevate' : 'top tier — nothing above');
          return { ack: label + ': ' + t.tier + ' (' + t.basis + '). ' + next };
        });
      } },
      { verb: 'elevate',   modOnly: true, needsTarget: true, help: 'elevate @u (one rung up: stranger → resident → admin)', handler: function (modId, c) {
        return elevateUser(c.targetId, c.targetName, modId, {}).then(function (r) {
          if (!r.ok) return { ack: 'couldn\'t elevate: ' + r.reason };
          var res = { ack: 'elevated ' + (c.targetName || c.targetId) + ' to ' + r.tier };
          if (r.persist && r.persist.modList) { res.modListTouched = true; res.modList = r.persist.modList; }
          return res;
        });
      } },
      { verb: 'demote',    modOnly: true, needsTarget: true, help: 'demote @u (one rung down)', handler: function (modId, c) {
        return demoteUser(c.targetId, modId, {}).then(function (r) {
          if (!r.ok) return { ack: 'couldn\'t demote: ' + r.reason };
          var res = { ack: 'demoted ' + (c.targetName || c.targetId) + ' to ' + r.tier };
          if (r.persist && r.persist.modList) { res.modListTouched = true; res.modList = r.persist.modList; }
          return res;
        });
      } },
      { verb: 'save',      modOnly: false, help: 'save (DM yourself your recent lines with me)', handler: function (uid, c) {
        return transcriptFor(uid, 20).then(function (lines) {
          if (!lines.length) return { ack: 'I have no recent lines from you to save — say something first' };
          var body = 'your recent lines with me (' + lines.length + '):\n' + lines.join('\n');
          return { ack: 'sending you your recent lines — check your DMs.', dmTo: String(uid), dmBody: body };
        });
      } },
      { verb: 'why',       modOnly: false, help: 'why [N] (why it has / hasn\'t acted: held output + last decisions)', handler: function (uid, c) {
        var n = Math.max(1, Math.min(10, parseInt(String((c && c.rawArgs) || '').trim(), 10) || 5));
        return actWhy().then(function (w) {
          var lines = ['actuation (policy ' + w.policy + (w.pending.length ? ', ' + w.pending.length + ' held' : ', nothing held') + '):'];
          w.pending.slice(0, 5).forEach(function (e) {
            lines.push('- ' + e.class + ' — ' + e.reason + ' (' + humanGap(clock.now() - (e.at || clock.now())) + ' ago)');
          });
          var log = (w.log || []).slice(-n);
          if (log.length) lines.push('last decisions: ' + log.map(function (e) { return humanGap(clock.now() - e.at) + ' ago: ' + e.class + ' ' + e.verdict + ' (' + coarseActWhy(e.why) + ')'; }).join('; '));
          else lines.push('no recorded decisions yet — nothing has been due since the journal started');
          return { ack: lines.join('\n').slice(0, 1800) };
        });
      } },
      { verb: 'whatif',    modOnly: true, help: 'whatif allow|ask|deny (dry run: what each gate would say — holds, fires, and remembers nothing)', handler: function (modId, c) {
        var p = normArg(c);
        return actWhatIf(p).then(function (r) {
          if (!r.ok) return { ack: 'policy must be allow|ask|deny' };
          var lines = ['what if policy were ' + r.policy + ' (dry run — nothing held, fired, or remembered):'];
          Object.keys(r.results).forEach(function (cls) {
            var g = r.results[cls];
            lines.push('- ' + cls + ': ' + g.verdict + ' (' + g.why + ')');
          });
          return { ack: lines.join('\n') };
        });
      } },
      { verb: 'poll',      modOnly: true, help: 'poll <question> | <a> | <b> [...]  /  poll close', handler: function (modId, c) {
          var args = String((c && c.rawArgs) || '').trim();
          if (!args) {
            return Promise.resolve(store.get(POLL_KEY)).then(function (rec) {
              return rec && rec.messageId ? { ack: 'open poll: \u201c' + rec.question + '\u201d \u2014 ' + cfg.commandPrefix + ' poll close to tally' } : { ack: 'no poll is open \u2014 ' + cfg.commandPrefix + ' poll <question> | <a> | <b>' };
            });
          }
          if (/^(close|end|tally)$/i.test(args)) return pollClose();
          var parts = args.split('|').map(function (s) { return s.trim(); }).filter(Boolean);
          if (parts.length < 3) return Promise.resolve({ ack: 'a poll needs a question and at least two options: poll <question> | <a> | <b>' });
          if (parts.length > 10) return Promise.resolve({ ack: 'nine options max' });
          return pollCreate(parts[0].slice(0, 200), parts.slice(1).map(function (o) { return o.slice(0, 80); }));
        } },
      { verb: 'recap',     modOnly: true, cooldownMs: 20000, aliases: ['\ud83d\udcdc'], help: 'recap', handler: function (modId, c) {
          if (typeof cfg.recapFn !== 'function') return Promise.resolve({ ack: 'recap is not available right now' });
          var mid = c && c.messageId;
          if (mid) ackWorking(mid, cfg.ackSearchEmoji);   // 🔍 — digging through the channel before answering
          function done(out) { if (mid) clearAck(mid, cfg.ackSearchEmoji); return out; }
          return assembleContext({ authorId: modId, authorName: '' }).then(function (ctx) {
            return Promise.resolve(cfg.recapFn({ recent: ctx })).then(function (res) {
              var v = (res && res.ok && res.value) ? String(res.value) : 'not much has happened that I can see';
              return done({ ack: v, embed: embedFor('Recap', v) });
            }, function () { return done({ ack: 'recap failed' }); });
          });
        } },
      { verb: 'thoughts',  modOnly: false, cooldownMs: 20000, help: 'thoughts (what it makes of the channel lately — its rolling summary)', handler: function (uid, c) {
          return Promise.resolve(store.get(CHANSUM_KEY)).then(function (cs) {
            var text = (cs && typeof cs.text === 'string') ? cs.text.trim() : '';
            if (!text) return { ack: 'nothing on my mind yet — give me a bit of conversation first, then ask again' };
            var age = (cs.at && clock.now() > cs.at) ? (' (updated ' + humanGap(clock.now() - cs.at) + ' ago)') : '';
            var v = text + age;
            return { ack: v, embed: embedFor('Thoughts', v), thoughtCard: 'cmd' };   // one live card: T3 delivery edits the previous reply in place
          }, function () { return { ack: 'could not reach my memory right now' }; });
        } },
      { verb: 'news',      modOnly: true, help: 'news (this channel\'s feed status) / news now (run this channel\'s feeds now)', handler: function (modId, c) {
          var arg = normArg(c);
          function failName(e) { return (e && e.id) + ((e && e.error) ? ' (' + String(e.error).slice(0, 80) + ')' : ''); }
          if (arg === 'now' || arg === 'run' || arg === 'force') {
            var nmid = c && c.messageId;
            if (nmid) ackWorking(nmid, cfg.ackSearchEmoji);   // 🔍 — fetching feeds + composing before answering
            function doneNews(out) { if (nmid) clearAck(nmid, cfg.ackSearchEmoji); return out; }
            return processNews(true).then(function (out) {
              if (out && out.busy) return doneNews({ ack: 'a news run is already in progress — try again in a bit' });
              if (out && out.blocked) return doneNews({ ack: 'didn\'t run the feeds (' + out.blocked + ') — try again in a bit' });
              if (out && out.empty) return doneNews({ ack: 'no news feeds target this channel' });
              if (out && out.noFetch) return doneNews({ ack: 'news fetch is unavailable right now' });
              var posted = (out && out.feeds) || [], staged = (out && out.queued) || [],
                  held = (out && out.held) || [], denied = (out && out.denied) || [],
                  failed = (out && out.failed) || [], nothing = (out && out.nothing) || [],
                  checked = (out && out.checked) || [];
              var bits = [];
              if (posted.length) bits.push('posted rollup' + (posted.length === 1 ? '' : 's') + ' from: ' + posted.join(', '));
              if (staged.length) bits.push('queued rollup' + (staged.length === 1 ? '' : 's') + ' from: ' + staged.join(', ') + ' — review in Setup → News queue');
              if (held.length) bits.push('held ' + held.length + ' for approval (' + held.join(', ') + ') — approve with ' + cfg.commandPrefix + ' approve');
              if (denied.length) bits.push('denied by policy (' + denied.join(', ') + ')');
              if (failed.length) bits.push('failed: ' + failed.map(failName).join('; '));
              if (bits.length) {
                var tail = nothing.length ? ' (' + nothing.length + ' had nothing new)' : '';
                return doneNews({ ack: bits.join(' + ') + tail });
              }
              return doneNews({ ack: 'ran the feeds — nothing new to post (checked ' + (checked.length || nothing.length || 'the') + ')' });
            }, function () { return doneNews({ ack: 'news run failed' }); });
          }
          var feeds = newsFeedsForHere();
          if (!feeds.length) return Promise.resolve({ ack: 'no news feeds target this channel' });
          return newsStateGet().then(function (st) {
            var now = clock.now();
            var lines = feeds.map(function (f) {
              var kind = newsKindOf(f), tag = (kind === NEWS_KIND_POD) ? '🎙️ podcast' : '📰 news';
              var every = 'every ' + humanGap(Number(f.intervalMs) || 3600000);
              var rec = st.byFeed[f.id];
              if (!rec) { var iv0 = (Number(f.intervalMs) || 3600000); return '• ' + tag + ' ' + (f.name || f.id) + ' (' + every + ') — seeding (first check next poll; next in ' + humanGap(iv0) + ')'; }
              var gap = Math.max(0, (Number(f.intervalMs) || 3600000) - (now - (rec.lastRun || 0)));
              var next = 'next check in ' + (gap < 60000 ? 'under a minute' : humanGap(gap));
              var last = 'never checked';
              if (rec.lastAt) {
                var ago = humanGap(Math.max(0, now - rec.lastAt)) + ' ago';
                var lr = rec.lastResult || '';
                if (lr === 'posted') last = 'last: posted ' + ago + (rec.lastCount ? ' (' + rec.lastCount + ' items)' : '');
                else if (lr === 'queued') last = 'last: queued ' + ago;
                else if (lr === 'held') last = 'last: held for approval ' + ago;
                else if (lr === 'denied') last = 'last: denied by policy ' + ago;
                else if (lr === 'failed') last = 'last: FAILED ' + ago + (rec.lastError ? ' (' + rec.lastError + ')' : '');
                else if (lr === 'nothing') last = 'last: nothing new ' + ago;
                else last = 'last: checked ' + ago;
              }
              return '• ' + ((newsKindOf(f) === NEWS_KIND_POD) ? '🎙️ podcast ' : '📰 news ') + (f.name || f.id) + ' (every ' + humanGap(Number(f.intervalMs) || 3600000) + ') — ' + next + '; ' + last;
            });
            var qn = (st.queue || []).length;
            var lr2 = st.lastRun;
            var runLine = '';
            if (lr2 && lr2.at) {
              var parts = [];
              if ((lr2.posted || []).length) parts.push('posted ' + lr2.posted.length);
              if ((lr2.queued || []).length) parts.push('queued ' + lr2.queued.length);
              if ((lr2.held || []).length) parts.push('held ' + lr2.held.length);
              if ((lr2.denied || []).length) parts.push('denied ' + lr2.denied.length);
              if ((lr2.failed || []).length) parts.push('failed ' + lr2.failed.length + ' (' + lr2.failed.map(failName).join('; ') + ')');
              if ((lr2.nothing || []).length) parts.push(lr2.nothing.length + ' nothing-new');
              runLine = '\nlast run ' + humanGap(Math.max(0, now - lr2.at)) + ' ago' + (lr2.forced ? ' (manual)' : ' (timer)') + ': checked ' + ((lr2.checked || []).length) + (parts.length ? ', ' + parts.join(', ') : '');
              if (lr2.busy) runLine += ' — a second run stood down (busy)';
              if (lr2.blocked) runLine += ' — blocked (' + lr2.blocked + ')';
            }
            var voiceNews = (cfg.newsPrompt === '' ? 'classic list' : (cfg.newsPrompt == null ? 'default AI voice' : 'custom AI voice'));
            var voicePod = (cfg.newsPodcastPrompt === '' ? 'classic list' : (cfg.newsPodcastPrompt == null ? 'default podcast voice' : 'custom podcast voice'));
            return { ack: clipLines('news feeds here:\n' + lines.join('\n') + runLine + '\nvoice: news=' + voiceNews + '; podcast=' + voicePod + '\nreview: ' + (cfg.newsReview ? ('on' + (qn ? ' (' + qn + ' queued)' : ' (queue empty)')) : 'off'), 1900) };
          }, function () { return { ack: 'could not read feed state' }; });
        } },
      { verb: 'timers',    modOnly: true, help: 'timers (when each timer last fired + next due: beats, news, lull, checkins, ai passes)', handler: function () {
          return actSchedule().then(function (sched) {
            return newsStateGet().then(function (nst) {
              return getPendingAct().then(function (pending) {
                var now = clock.now(), lines = ['timers (this channel):'];
                (sched.beats || []).forEach(function (b) {
                  lines.push('- beat "' + b.id + '": ' + (b.lastMs ? ('last fired ' + humanGap(Math.max(0, now - b.lastMs)) + ' ago; ') : 'never fired; ') + (b.dueInMs <= 0 ? 'DUE now' : ('due in ' + humanGap(b.dueInMs))));
                });
                if (!(sched.beats || []).length) lines.push('- beats: none configured');
                var lr = nst.lastRun;
                var feeds = newsFeedsForHere();
                if (!feeds.length) lines.push('- news: no feeds target this channel');
                else feeds.forEach(function (f) {
                  var rec = (nst.byFeed || {})[f.id] || {};
                  var gap = Math.max(0, (Number(f.intervalMs) || 3600000) - (now - (rec.lastRun || 0)));
                  var nx = rec.lastRun ? ('due in ' + (gap < 60000 ? 'under a minute' : humanGap(gap))) : ('seeding (first check next poll; next in ' + humanGap(Number(f.intervalMs) || 3600000) + ')');
                  var last = 'never checked';
                  if (rec.lastAt) last = 'last ' + (rec.lastResult || 'checked') + ' ' + humanGap(Math.max(0, now - rec.lastAt)) + ' ago' + (rec.lastError ? ' (' + rec.lastError + ')' : '');
                  lines.push('- ' + ((newsKindOf(f) === NEWS_KIND_POD) ? 'podcast 🎙️' : 'news 📰') + ' "' + (f.name || f.id) + '" (every ' + humanGap(Number(f.intervalMs) || 3600000) + '): ' + nx + '; ' + last);
                });
                if (lr && lr.at) lines.push('- last news run ' + humanGap(Math.max(0, now - lr.at)) + ' ago' + (lr.forced ? ' (manual)' : ' (timer)') + ': checked ' + ((lr.checked || []).length) + ((lr.posted || []).length ? ', posted ' + lr.posted.length : '') + ((lr.held || []).length ? ', held ' + lr.held.length : '') + ((lr.failed || []).length ? ', failed ' + lr.failed.length : ''));
                var lull = sched.lull || {};
                var lullLine = '- lull: silent ' + (lull.silentForMs == null ? 'n/a' : humanGap(lull.silentForMs)) + ', patience ' + humanGap(lull.patienceMs || 0);
                if (lull.diag && lull.diag.lastAt) lullLine += '; last ' + (lull.diag.lastResult || 'checked') + ' ' + humanGap(Math.max(0, now - lull.diag.lastAt)) + ' ago' + (lull.diag.lastError ? ' (' + lull.diag.lastError + ')' : '');
                lines.push(lullLine);
                var ci = sched.checkins || {};
                var ciLine = '- checkins: ' + (ci.lastMs ? ('last ' + humanGap(Math.max(0, now - ci.lastMs)) + ' ago') : 'never') + ', gap ' + humanGap(ci.gapMs || 0);
                if (ci.diag && ci.diag.lastAt) ciLine += '; last ' + (ci.diag.lastResult || 'checked') + ' ' + humanGap(Math.max(0, now - ci.diag.lastAt)) + ' ago' + (ci.diag.lastError ? ' (' + ci.diag.lastError + ')' : '');
                lines.push(ciLine);
                var ap = sched.aipass || {};
                ['facts', 'summary', 'reflect', 'episodes', 'consolidate', 'deliberate'].forEach(function (n) {
                  var r = ap[n] || {};
                  lines.push('- ai ' + n + ': ' + (r.lastAt ? ('last ' + (r.lastResult || 'fired') + ' ' + humanGap(Math.max(0, now - r.lastAt)) + ' ago' + (r.lastError ? ' (' + r.lastError + ')' : '')) : 'never fired'));
                });
                lines.push('- holds pending: ' + (pending || []).length);
                return { ack: clipLines(lines.join('\n'), 1900) };
              });
            });
          }, function () { return { ack: 'could not read timers right now' }; });
        } },
      { verb: 'status',    modOnly: true, cooldownMs: 5000, aliases: ['\ud83d\udcca'], help: 'status', handler: function () { return Promise.resolve({ ack: statusText(), embed: statusEmbed() }); } },
      { verb: 'trust',     modOnly: true, help: 'trust on|off  (multi-participant trust hardening: defang forged labels + bots can’t command)', handler: function (modId, c) {
          var a = normArg(c);
          if (a === 'on' || a === 'enable' || a === 'true')   { cfg.trustHardening = true;  log('[chloe.trust] trust hardening ENABLED by mod'); return Promise.resolve({ ack: 'trust hardening on — forged "Name:" labels are stripped from what I read, and another bot can never command me.' }); }
          if (a === 'off' || a === 'disable' || a === 'false') { cfg.trustHardening = false; log('[chloe.trust] trust hardening DISABLED by mod'); return Promise.resolve({ ack: 'trust hardening off — back to prior behavior (' + cfg.commandPrefix + ' trust on to re-enable).' }); }
          return Promise.resolve({ ack: 'trust hardening is ' + (cfg.trustHardening ? 'on' : 'off') + '. Use ' + cfg.commandPrefix + ' trust on|off (the panel toggle persists it).' });
        } },
      { verb: 'converse',  modOnly: true, help: 'converse on|off  (the ported social-ganglion engage engine; off = legacy engage logic)', handler: function (modId, c) {
          var a = normArg(c);
          if (a === 'on' || a === 'enable' || a === 'true')   { cfg.converseEngine = true;  log('[chloe.converse] engage engine ENABLED by mod'); return Promise.resolve({ ack: 'converse engine on \u2014 the social ganglion now governs when I chime in (bot-loop damper + worth gate + two-person skip).' }); }
          if (a === 'off' || a === 'disable' || a === 'false') { cfg.converseEngine = false; log('[chloe.converse] engage engine DISABLED by mod (legacy path)'); return Promise.resolve({ ack: 'converse engine off \u2014 back to my legacy engage logic (' + cfg.commandPrefix + ' converse on to re-enable).' }); }
          return Promise.resolve({ ack: 'converse engine is ' + (cfg.converseEngine ? 'on' : 'off') + '. Use ' + cfg.commandPrefix + ' converse on|off (the panel toggle persists it).' });
        } },
      { verb: 'lockdown',  modOnly: true, aliases: ['lock', '\ud83d\udd12'], help: 'lockdown', handler: function () { engageMode = 'locked'; log('[chloe.mode] lockdown (mods only)'); return Promise.resolve({ ack: 'locked down \u2014 I\u2019ll only respond to mods until you ' + cfg.commandPrefix + ' unlock.' }); } },
      { verb: 'unlock',    modOnly: true, aliases: ['\ud83d\udd13'], help: 'unlock', handler: function () { engageMode = 'normal'; log('[chloe.mode] back to normal'); return Promise.resolve({ ack: 'unlocked \u2014 back to normal.' }); } },
      { verb: 'open',      modOnly: true, aliases: ['openchat', '\ud83d\udce2'], help: 'open', handler: function () { engageMode = 'open'; log('[chloe.mode] open (reply to everyone)'); return Promise.resolve({ ack: 'open mode \u2014 I\u2019ll reply to everyone in here. ' + cfg.commandPrefix + ' unlock to stop.' }); } },
      { verb: 'help',      modOnly: true, cooldownMs: 5000, aliases: ['?', '\ud83c\udd98'], handler: function () { return Promise.resolve({ ack: helpText(), embed: helpEmbed() }); } },
      { verb: 'do',        modOnly: true, help: 'do {json task}', handler: function (modId, c) {
          var parsed = parseJob(c.reason || '');
          if (!parsed.ok) return Promise.resolve({ ack: 'job rejected: ' + parsed.reason + '. Allowed: ' + describeJobs().join('; ') });
          return executeJob(parsed.job.task, parsed.job.args, { authorId: modId, authorName: '' });
        } },
      { verb: 'tools',     modOnly: true, help: 'tools on|off  (let the AI call safe tools from its reply)', handler: function (modId, c) {
          var a = normArg(c);
          if (a === 'on' || a === 'enable' || a === 'true')  { cfg.toolsEnabled = true;  log('[chloe.tool] model tool-loop ENABLED by mod'); return Promise.resolve({ ack: 'model tool-loop on \u2014 I can now quietly use safe tools (summarize/recap/remindme/roster/search/fetch/almanac/time/roll/todos) from my own replies.' }); }
          if (a === 'off' || a === 'disable' || a === 'false') { cfg.toolsEnabled = false; log('[chloe.tool] model tool-loop DISABLED by mod'); return Promise.resolve({ ack: 'model tool-loop off \u2014 tools only run from ' + cfg.commandPrefix + ' do now.' }); }
          return Promise.resolve({ ack: 'model tool-loop is ' + (cfg.toolsEnabled ? 'on' : 'off') + '. Use ' + cfg.commandPrefix + ' tools on|off (the panel toggle persists it).' });
        } },
      { verb: 'image',     modOnly: false, help: 'image <words> | image {json: prompt, resolution, guidanceScale, removeBackground, weights, dm}', handler: function (modId, c) {
          if (!imageEnabled()) return Promise.resolve({ ack: 'image generation is not available right now' });
          var text = String(c.rawArgs || c.reason || '').trim();
          if (!text) return Promise.resolve({ ack: 'usage: ' + (cfg.commandPrefix || '!chloe') + ' image <words> | ' + (cfg.commandPrefix || '!chloe') + ' image {json: "prompt": "...", ...}' });
          var parsed = parseImageJson(text);
          if (!parsed.ok && parsed.reason === 'not valid JSON' && !/^[{[]/.test(text) && /[a-z0-9].*[a-z0-9]/i.test(text)) {
            // plain words, not attempted JSON: `!chloe image of a cat` — the verb already
            // named the medium, so prefix it back and let the natural-language parser clean up.
            var nl = parseImageRequest(text) || parseImageRequest('image ' + text);
            if (nl && nl.prompt) {
              var p = String(nl.prompt).replace(/^(?:images?|pictures?|pics?|photos?|drawings?)\s+/i, '');
              if (p.replace(/[^a-z0-9]/ig, '').length >= 2) parsed = { ok: true, value: { prompt: p.slice(0, 400), dm: nl.dm, resolution: nl.resolution } };
            }
          }
          if (!parsed.ok) return Promise.resolve({ ack: 'image request rejected: ' + parsed.reason });
          if (paint.queue.length >= cfg.imageQueueMax) return Promise.resolve({ ack: "i've got a full image queue right now \u2014 try again in a moment" });
          var v = parsed.value, now = clock.now();
          var qItem = { messageId: c.messageId, authorId: modId, authorName: c.authorName || '', prompt: v.prompt, resolution: v.resolution, dm: v.dm, at: now };
          if (v.guidanceScale != null) qItem.guidanceScale = v.guidanceScale;
          if (v.removeBackground) qItem.removeBackground = true;
          paint.queue.push(qItem);
          if (paint.painting || paint.queue.length > 1) setQueueAck(qItem, queueEmojiFor(paint.queue.length));
          var ack = 'queued: "' + v.prompt.slice(0, 60) + '" (' + v.resolution + (v.guidanceScale != null ? ', cfg ' + v.guidanceScale : '') + (v.removeBackground ? ', bg removed' : '') + (v.dm ? ', dm' : '') + ')';
          if (parsed.notes && parsed.notes.length) ack += ' \u2014 note: ' + parsed.notes.join('; ');
          return Promise.resolve({ ack: ack });
        } },
      { verb: 'remind',    modOnly: false, help: 'remind <10m|2h|1d> <what>', handler: function (modId, c) {
          var args = String(c.rawArgs || '').trim();
          var m = args.match(/^(?:me\s+)?(?:in\s+)?(\d+)\s*([smhd])\b[\s,:-]*(.+)$/i) || args.match(/^(?:me\s+)?(.+?)\s+in\s+(\d+)\s*([smhd])\b$/i);
          if (!m) return Promise.resolve({ ack: 'usage: ' + cfg.commandPrefix + ' remind 10m take the pizza out (or 2h / 1d)' });
          var minutes, text;
          if (m.length === 4 && /^\d+$/.test(m[1])) { minutes = Math.round(durToMs(m[1], m[2]) / 60000); text = m[3]; }
          else { minutes = Math.round(durToMs(m[2], m[3]) / 60000); text = m[1]; }
          if (minutes < 1) minutes = 1;
          var dm = /\b(dm|privately|in private)\b/i.test(args);
          if (dm) text = text.replace(/\b(in (a|my) )?(dm|privately|in private)\b/ig, '').trim();
          return scheduleReminder({ minutes: minutes, text: text, authorId: modId, authorName: c.authorName || '', dm: dm }).then(function (res) {
            if (!res.ok) return { ack: res.reason };
            var when = minutes >= 1440 ? (Math.round(minutes / 1440) + 'd') : minutes >= 60 ? (Math.round(minutes / 60) + 'h') : (minutes + 'm');
            return { ack: "got it \u2014 i'll remind you in " + when + (dm ? ' (via dm)' : '') + ': \u201c' + text.slice(0, 80) + '\u201d' };
          });
        } },
      { verb: 'reminders', modOnly: false, help: 'reminders (list yours) / reminders clear', handler: function (modId, c) {
          var arg = String(c.rawArgs || '').trim().toLowerCase();
          if (arg === 'clear' || arg === 'cancel') return clearReminders(modId).then(function (n) { return { ack: n ? ('cleared ' + n + ' reminder' + (n === 1 ? '' : 's')) : 'you had no reminders pending' }; });
          return listReminders(modId).then(function (list) {
            if (!list.length) return { ack: 'you have no reminders pending' };
            var now = clock.now();
            var lines = list.slice(0, 10).map(function (r) { var mins = Math.max(0, Math.round((r.fireAt - now) / 60000)); return '\u2022 in ' + (mins >= 60 ? (Math.round(mins / 60) + 'h') : (mins + 'm')) + ': ' + r.text.slice(0, 60); });
            return { ack: 'your reminders:\n' + lines.join('\n') };
          });
        } },
      { verb: 'afk',       modOnly: false, help: 'afk [reason] (mark yourself away)', handler: function (modId, c) {
          var reason = String(c.rawArgs || '').trim();
          return setAfk(modId, c.authorName || '', reason).then(function () {
            return { ack: "ok " + (c.authorName ? c.authorName + ', ' : '') + "i'll let people know you're away" + (reason ? ' (' + reason.slice(0, 80) + ')' : '') };
          });
        } },
      { verb: 'back',      modOnly: false, help: 'back (clear your away state)', handler: function (modId, c) {
          return clearAfk(modId).then(function (prior) {
            if (!prior) return { ack: 'you were not marked away' };
            return { ack: 'welcome back' + (c.authorName ? ', ' + c.authorName : '') + " \u2014 you were away " + humanGap(clock.now() - prior.since) };
          });
        } },
      { verb: 'highlight', modOnly: false, help: 'highlight [note] (reply to a message, or quote text)', handler: function (modId, c) {
          var args = String(c.rawArgs || '').trim();
          var src = null, note = args;
          if (c.referenced && c.referenced.text) { src = c.referenced; note = args; }           // replied-to message
          else {
            var q = args.match(/^["\u201c]([\s\S]+?)["\u201d]\s*(.*)$/);                          // "quoted text" optional note
            if (q) { src = { text: q[1], authorName: '' }; note = q[2]; }
            else if (args) { src = { text: args, authorName: c.authorName || '' }; note = ''; }   // bare text becomes the highlight
          }
          if (!src) return Promise.resolve({ ack: 'reply to a message with ' + cfg.commandPrefix + ' highlight, or quote some text to save' });
          return addHighlight(src, modId, c.authorName || '', note).then(function (res) {
            if (!res.ok) return { ack: res.reason };
            return { ack: '\ud83d\udccc saved' + (res.value.note ? ' (' + res.value.note.slice(0, 60) + ')' : '') + ': \u201c' + res.value.text.slice(0, 80) + '\u201d' };
          });
        } },
      { verb: 'highlights',modOnly: false, help: 'highlights (list) / highlights clear', handler: function (modId, c) {
          var arg = String(c.rawArgs || '').trim().toLowerCase();
          if (arg === 'clear' || arg === 'reset') {
            if (!isMod(modId)) return Promise.resolve({ ack: 'only a mod can clear the channel highlights' });
            return clearHighlights().then(function (n) { return { ack: n ? ('cleared ' + n + ' highlight' + (n === 1 ? '' : 's')) : 'no highlights to clear' }; });
          }
          return listHighlights(10).then(function (list) {
            if (!list.length) return { ack: 'no highlights saved yet \u2014 reply to a good message with ' + cfg.commandPrefix + ' highlight' };
            var now = clock.now();
            var lines = list.map(function (h) { return '\u2022 ' + (h.authorName ? h.authorName + ': ' : '') + '\u201c' + h.text.slice(0, 70) + '\u201d' + (h.note ? ' \u2014 ' + h.note.slice(0, 40) : '') + ' (' + humanGap(now - h.at) + ' ago)'; });
            return { ack: 'channel highlights:\n' + lines.join('\n') };
          });
        } },
      { verb: 'reactions',modOnly: false, help: 'reactions (top reactions this room values)', handler: function (modId, c) {
          return topReactions(10).then(function (top) {
            if (!top.length) return { ack: "no notable reactions tracked yet" };
            var mc = cfg.serverMemberCount ? (' \u2014 significance threshold here is ' + reactionThreshold(cfg.serverMemberCount) + '+ on a ' + cfg.serverMemberCount + '-member server') : '';
            return { ack: 'reactions this room values: ' + top.map(function (r) { return r.label + ' \u00d7' + r.count; }).join(', ') + mc };
          });
        } },
      { verb: 'good',    modOnly: true,  help: 'good \u2014 tell it that last reply landed (feedback learning)', handler: function (modId, c) {
          if (!cfg.feedbackLearning) return Promise.resolve({ ack: 'feedback learning is off \u2014 turn it on in the Behavior tab' });
          if (!lastReplyStyle) return Promise.resolve({ ack: 'I haven\u2019t replied here recently, so there\u2019s nothing to rate' });
          return recordFeedback(lastReplyStyle, 1).then(function () { return { ack: 'noted \u2014 glad that one landed', react: '\ud83d\udc4d' }; });
        } },
      { verb: 'bad',     modOnly: true,  help: 'bad \u2014 tell it that last reply missed (feedback learning)', handler: function (modId, c) {
          if (!cfg.feedbackLearning) return Promise.resolve({ ack: 'feedback learning is off \u2014 turn it on in the Behavior tab' });
          if (!lastReplyStyle) return Promise.resolve({ ack: 'I haven\u2019t replied here recently, so there\u2019s nothing to rate' });
          return recordFeedback(lastReplyStyle, -1).then(function () { return { ack: 'got it \u2014 I\u2019ll keep that in mind', react: '\ud83d\udc4d' }; });
        } },
      { verb: 'aboutme',  modOnly: false, help: 'aboutme (what it remembers about you)', handler: function (modId, c) {
          return Promise.resolve(userStore().get(partKey(modId))).then(function (p) {
            var facts = (p && Array.isArray(p.facts)) ? p.facts : [];
            if (!facts.length) return { ack: "I haven\u2019t picked up anything I\u2019m holding onto about you \u2014 we just haven\u2019t talked enough yet, or fact memory is off." };
            var note = '';
            if (p && p.conflict && p.conflict.a && p.conflict.b) note = '\n(heads up \u2014 two of these don\u2019t quite line up: \u201c' + p.conflict.a + '\u201d vs \u201c' + p.conflict.b + '\u201d)';
            return { ack: 'here\u2019s what I remember about you:\n' + facts.map(function (f) { return '\u2022 ' + f.text; }).join('\n') + note + '\n(say "' + cfg.commandPrefix + ' forget <words>" to drop any of it)' };
          });
        } },
      { verb: 'mode',      modOnly: false, help: 'mode  /  mode clear (mods)', handler: function (modId, c) {
          var args = String(c.rawArgs || '').trim().toLowerCase();
          if (args === 'clear' || args === 'off') {
            if (!isMod(modId)) return Promise.resolve({ ack: 'only mods can clear the mode' });
            return clearProcMode().then(function () { return { ack: 'mode cleared \u2014 back to my usual self' }; });
          }
          return getProcMode().then(function (rec) {
            if (!rec) return { ack: 'no special mode is active' };
            var mins = Math.max(1, Math.round((rec.until - clock.now()) / 60000));
            return { ack: 'current mode (set by ' + rec.by + ', ' + mins + 'm left): \u201c' + rec.mode + '\u201d' };
          });
        } },
      { verb: 'time',      modOnly: false, help: 'time \u2014 the current time (instant, no AI)', handler: function (modId, c) { return Promise.resolve({ ack: deviceClockAck('time') }); } },
      { verb: 'date',      modOnly: false, help: 'date \u2014 today\u2019s date (instant, no AI)', handler: function (modId, c) { return Promise.resolve({ ack: deviceClockAck('date') }); } },
     { verb: 'search',    modOnly: false, cooldownMs: 5000, help: 'search <query> (web search, instant results)', handler: function (modId, c) {
          var q = String(c.rawArgs || '').trim().slice(0, 300);
          if (!q) return Promise.resolve({ ack: 'usage: ' + cfg.commandPrefix + ' search <query> (e.g. ' + cfg.commandPrefix + ' search red pandas)' });
          if (typeof cfg.search !== 'function') return Promise.resolve({ ack: 'search is not available right now' });
          return Promise.resolve(cfg.search(q)).then(function (res) {
            if (!res || !res.ok) return Promise.resolve({ ack: 'no results for \u201c' + q.slice(0, 80) + '\u201d (' + ((res && res.reason) || 'n/a') + ')' });
            return { ack: 'here\u2019s what I found for \u201c' + q.slice(0, 80) + '\u201d:\n' + String(res.value).slice(0, 1500) };
          });
        } },
      { verb: 'recall',    modOnly: false, cooldownMs: 5000, help: 'recall <words> (search what it remembers from this channel)', handler: function (modId, c) {
          var q = String(c.rawArgs || '').trim().slice(0, 300);
          if (!q) return Promise.resolve({ ack: 'usage: ' + cfg.commandPrefix + ' recall <words> (e.g. ' + cfg.commandPrefix + ' recall campfire night)' });
          if (!cfg.episodicMemory) return Promise.resolve({ ack: 'memory is off right now \u2014 turn episodic memory on and I\u2019ll start keeping track' });
          return searchEpisodes(q).then(function (res) {
            if (!res || !res.ok) {
              if (res && res.reason === 'empty') return { ack: 'nothing stored yet \u2014 I haven\u2019t kept any moments from this channel so far' };
              return { ack: 'nothing matching \u201c' + q.slice(0, 80) + '\u201d in what I remember from here' };
            }
            var now = clock.now();
            var lines = res.matches.map(function (m) { return '\u2022 \u201c' + String(m.text).slice(0, 120) + '\u201d (' + humanGap(Math.max(0, now - (m.at || now))) + ' ago)'; });
            var text = 'here\u2019s what I remember about \u201c' + q.slice(0, 80) + '\u201d:\n' + lines.join('\n');
            if (res.hop) text += '\nand connected to that, \u201c' + String(res.hop).slice(0, 120) + '\u201d';
            return { ack: clipLines(text, 1500) };
          });
        } },
      { verb: 'lang',      modOnly: false, help: 'lang <code> (e.g. fr, es, de) / lang off / lang \u2014 your reply language (mods: lang default <code>|off = this channel\u2019s default)', handler: function (uid, c) {
          var arg = normArg(c);
          var pfx = cfg.commandPrefix || '!chloe';
          var chDef = cfg.channelLang || null;   // v0.90.21: queen-patched snapshot of channelLang:<this channel>
          function bareAck(lg) {
            if (lg && lg !== 'en') return 'I\u2019m talking to you in ' + (LANG_NAMES[lg] || lg) + ' (' + lg + '). Say \u201c' + pfx + ' lang off\u201d to switch back to English.';
            if (chDef && chDef !== 'en') return 'I\u2019m talking to you in English, but this channel defaults to ' + (LANG_NAMES[chDef] || chDef) + ' \u2014 say \u201c' + pfx + ' lang ' + chDef + '\u201d to match it, or pick your own code.';
            return 'I\u2019m talking to you in English. Say \u201c' + pfx + ' lang fr\u201d (or es, de, ja\u2026) to switch.';
          }
          var dm = arg.match(/^default(?:\s+(.*))?$/);   // v0.90.21: per-channel default, mods only
          if (dm) {
            if (!isMod(uid)) return Promise.resolve({ ack: 'only mods can set the channel language \u2014 but your own is yours: ' + pfx + ' lang fr (or es, de, ja\u2026).' });
            var sub = (dm[1] || '').trim();
            if (!sub || sub === 'off' || sub === 'en' || sub === 'english' || sub === 'default') {
              return Promise.resolve({ ack: 'okay \u2014 back to English in here unless someone picks their own. (' + pfx + ' lang default fr to set one.)', channelLang: null, channelLangTouched: true });
            }
            if (!LANG_NAMES[sub]) {
              return Promise.resolve({ ack: 'I don\u2019t know the code \u201c' + sub.slice(0, 12) + '\u201d. Try a 2-letter code like fr (French), es (Spanish), de (German), ja (Japanese), pt, ru, zh, ar\u2026 or \u201clang default off\u201d to clear.' });
            }
            return Promise.resolve({ ack: 'got it \u2014 I\u2019ll talk ' + LANG_NAMES[sub] + ' in here unless someone picks their own. (\u201c' + pfx + ' lang default off\u201d to clear.)', channelLang: sub, channelLangTouched: true });
          }
          if (!arg) {
            return getUserLang(uid).then(function (lg) { return { ack: bareAck(lg) }; });
          }
          if (arg === 'off' || arg === 'en' || arg === 'english') {
            return setUserLang(uid, null).then(function () { return { ack: 'okay \u2014 back to English.' }; });
          }
          if (!LANG_NAMES[arg]) {
            return Promise.resolve({ ack: 'I don\u2019t know the code \u201c' + arg.slice(0, 12) + '\u201d. Try a 2-letter code like fr (French), es (Spanish), de (German), ja (Japanese), pt, ru, zh, ar\u2026 or \u201clang off\u201d for English.' });
          }
          return setUserLang(uid, arg).then(function () { return { ack: 'got it \u2014 I\u2019ll talk with you in ' + LANG_NAMES[arg] + ' from now on. (\u201c' + (cfg.commandPrefix || '!chloe') + ' lang off\u201d for English.)' }; });
        } },
      { verb: 'forget',    modOnly: false, help: 'forget me  /  forget <a thing>' },
      { verb: 'remember',  modOnly: false, help: 'remember me' },
      { verb: 'forget-that', modOnly: true, help: 'forget-that (reply to a message, or @user) \u2014 excise it from my memory', handler: function (modId, c) {
          // reply target wins; then an @mentioned user's last line; then the most recent channel line.
          if (c.referenced && c.referenced.id) {
            return exciseMessage(c.referenced.id).then(function (r) { return { ack: r.removed ? ('\uD83E\uDDFD forgotten \u2014 dropped that from my memory') : ('I wasn\u2019t holding that message in mind'), react: '\uD83E\uDDFD' }; });
          }
          if (c.targetId) {
            return exciseLastFromUser(c.targetId, 1).then(function (r) { return { ack: r.removed ? ('\uD83E\uDDFD forgot ' + (c.targetName || 'their') + ' last line') : ('nothing recent of theirs to forget'), react: '\uD83E\uDDFD' }; });
          }
          if (lastLineId) {
            return exciseMessage(lastLineId).then(function (r) { return { ack: r.removed ? ('\uD83E\uDDFD forgotten \u2014 dropped the last message from my memory') : ('nothing recent to forget'), react: '\uD83E\uDDFD' }; });
          }
          return Promise.resolve({ ack: 'reply to the message you want me to forget, or @mention whose last line to drop' });
        } }
    ];
    function resolveVerb(word) {
      word = String(word || '').toLowerCase();
      for (var i = 0; i < COMMANDS.length; i++) {
        if (COMMANDS[i].verb === word) return COMMANDS[i];
        if (COMMANDS[i].aliases && COMMANDS[i].aliases.indexOf(word) >= 0) return COMMANDS[i];
      }
      return null;
    }
    function looksLikeCommand(content) {
      return matchedPrefix(String(content || '').trim()) !== null;
    }
    function prefixList() {
      var arr = [];
      if (cfg.commandPrefix) arr.push(String(cfg.commandPrefix));
      if (Array.isArray(cfg.commandPrefixes)) cfg.commandPrefixes.forEach(function (p) { if (p) arr.push(String(p)); });
      if (!arr.length) arr.push('!chloe');
      return arr;
    }
    function matchedPrefix(trimmed) {   // longest first so "!chloe" wins over a shorter "!c"
      var lc = String(trimmed || '').toLowerCase();
      var arr = prefixList().slice().sort(function (a, b) { return b.length - a.length; });
      for (var i = 0; i < arr.length; i++) { if (arr[i] && lc.indexOf(arr[i].toLowerCase()) === 0) return arr[i]; }
      return null;
    }
    function parseCommand(content) {
      var raw = String(content || '');
      var c = raw.trim();
      var pfx = matchedPrefix(c);
      if (pfx == null) return null;
      var rest = c.slice(pfx.length).trim();
      if (!rest) return { cmd: 'help', entry: resolveVerb('help'), targetId: null, durationMs: null, reason: '', raw: raw };
      var tokens = rest.split(/\s+/);
      var verbTok = tokens.shift();
      var entry = resolveVerb(verbTok);
      if (!entry) return null;   // "!chloe Hi there" is chat, not a command — don't swallow it
      var rawArgs = rest.slice(verbTok.length).trim();   // everything after the verb, verbatim (JSON-safe)
      var mm = raw.match(/<@!?(\d+)>/);
      var targetId = mm ? mm[1] : null;
      var durationMs = null, reasonTokens = [];
      tokens.forEach(function (t) {
        if (/^<@!?\d+>$/.test(t)) return;
        var dm = t.match(/^(\d+)([smhd])$/i);
        if (dm && durationMs == null && entry.takesDuration) { durationMs = durToMs(dm[1], dm[2]); return; }
        reasonTokens.push(t);
      });
      return { cmd: entry.verb, entry: entry, targetId: targetId, durationMs: durationMs, reason: reasonTokens.join(' ').trim(), rawArgs: rawArgs, raw: raw, messageId: null };
    }
    // B1 text-attachment ingestion (PURE, headless-testable). Discord messages
    // carry .attachments[] ({filename, size, url, content_type}); nothing else
    // reads them. Stored memory keeps ORIGINAL content (no facts/mood/automod
    // pollution); attachment text rides ONLY the in-flight queue content via
    // contentWithAttach, which is what assembleContext serves as addressedMessage.
    var ATTACH_EXT_OK = { '.txt': 1, '.md': 1, '.markdown': 1, '.csv': 1, '.json': 1, '.log': 1, '.pdf': 1 };
    var ATTACH_TYPE_OK = ['text/plain', 'text/markdown', 'text/csv', 'application/json', 'application/pdf'];
    function attachExt(name) { var m = String(name || '').toLowerCase().match(/\.[a-z0-9]+$/); return m ? m[0] : ''; }
    function attachIsPdf(a) {
      var ext = attachExt(a && a.filename);
      var ct = String((a && (a.content_type || a.contentType)) || '').toLowerCase().split(';')[0].trim();
      return ext === '.pdf' || ct === 'application/pdf';
    }
    function selectAttachable(atts) {
      if (!Array.isArray(atts)) return [];
      var out = [], maxFiles = cfg.attachMaxFiles || 2, maxBytes = cfg.attachMaxBytes || 100000;
      var maxPdfBytes = cfg.attachPdfMaxBytes || 2000000;
      for (var i = 0; i < atts.length && out.length < maxFiles; i++) {
        var a = atts[i]; if (!a || !a.url) continue;
        var ext = attachExt(a.filename);
        var ct = String(a.content_type || a.contentType || '').toLowerCase().split(';')[0].trim();
        var size = (typeof a.size === 'number') ? a.size : -1;
        if (!ATTACH_EXT_OK[ext] && ATTACH_TYPE_OK.indexOf(ct) < 0) { log('[chloe.attach] skip "' + String(a.filename || '?').slice(0, 60) + '" (not an allowed type)'); continue; }
        var cap = attachIsPdf(a) ? maxPdfBytes : maxBytes;
        if (size >= 0 && size > cap) { log('[chloe.attach] skip "' + String(a.filename || '?').slice(0, 60) + '" (declared ' + size + ' bytes > cap)'); continue; }
        out.push({ url: String(a.url), filename: String(a.filename || 'attachment.txt').slice(0, 80), pdf: attachIsPdf(a) });
      }
      return out;
    }
    function formatAttachBlock(files) {
      var per = cfg.attachMaxChars || 3000;
      return files.map(function (f) {
        var t = String(f.text || '').slice(0, per);
        return '\n[attached ' + f.filename + ' (' + t.length + ' chars)]:\n' + t;
      }).join('');
    }
    function contentWithAttach(m) { return String((m && m.content) || '') + ((m && m.attachText) ? '\n' + m.attachText : ''); }
    function helpText() {
      var p = cfg.commandPrefix;
      var withHelp = COMMANDS.filter(function (c) { return c.help; });
      var mod = withHelp.filter(function (c) { return c.modOnly; }).map(function (c) { return p + ' ' + c.help; });
      var any = withHelp.filter(function (c) { return !c.modOnly; }).map(function (c) { return p + ' ' + c.help; });
      return 'Chloe mod commands: ' + mod.join(' | ') + '. Anyone: ' + any.join(' | ') + '.';
    }
    function statusText() {
      return 'Chloe here. mode=' + engageMode + ', replies=' + cfg.addressMode + (cfg.volunteer ? ' +volunteer' : '') + '. mods can ' + cfg.commandPrefix + ' help.';
    }
    // #8: rich embeds for help/status/recap (used when the transport offers sendEmbed; text is the fallback).
    var EMBED_COLOR = 0x8b5cf6;   // Chloe's accent
    function embedFor(title, desc, fields) {
      var e = { title: title, color: EMBED_COLOR, footer: { text: 'Chloe' } };
      if (desc) e.description = String(desc).slice(0, 4000);
      if (fields && fields.length) e.fields = fields;
      return e;
    }
    function helpSectionFields(title, lines) {
      // Discord caps a field value at 1024 chars (the transport slices past it) — a single
      // Mods/Anyone field now silently drops its tail (the list long ago outgrew the cap, so
      // late entries like search/forget/remember never rendered). Split into <=900-char fields;
      // a short section keeps its bare name, so output is byte-identical while it fits.
      if (!lines.length) return [{ name: title, value: '\u2014' }];
      var fields = [], cur = [], len = 0;
      lines.forEach(function (ln) {
        if (cur.length && len + 1 + ln.length > 900) { fields.push(cur); cur = []; len = 0; }
        if (cur.length) len += 1;
        cur.push(ln); len += ln.length;
      });
      if (cur.length) fields.push(cur);
      return fields.map(function (chunk, i) {
        return { name: fields.length > 1 ? (title + ' (' + (i + 1) + '/' + fields.length + ')') : title, value: chunk.join('\n') };
      });
    }
    function helpEmbed() {
      var p = cfg.commandPrefix;
      var withHelp = COMMANDS.filter(function (c) { return c.help; });
      var mod = withHelp.filter(function (c) { return c.modOnly; }).map(function (c) { return '`' + p + ' ' + c.help + '`'; });
      var any = withHelp.filter(function (c) { return !c.modOnly; }).map(function (c) { return '`' + p + ' ' + c.help + '`'; });
      return embedFor('Chloe \u2014 commands', null, helpSectionFields('Mods', mod).concat(helpSectionFields('Anyone', any)));
    }
    function statusEmbed() {
      return embedFor('Chloe \u2014 status', null, [
        { name: 'engagement', value: engageMode, inline: true },
        { name: 'replies', value: String(cfg.addressMode) + (cfg.volunteer ? ' + volunteer' : ''), inline: true },
        { name: 'images', value: cfg.image ? 'on' : 'off', inline: true },
        { name: 'auto-mod', value: (cfg.autoMod && (cfg.autoModRules || []).length) ? ((cfg.autoModRules || []).length + ' rule(s)') : 'off', inline: true }
      ]);
    }
    // Instant date/time from the page-pushed device clock (no AI). Honest when off/stale/absent so the
    // command never fabricates a time. `which` = 'time' | 'date'.
    function deviceClockAck(which) {
      var dc = cfg.deviceClock;
      var fresh = dc && (dc.time || dc.date) && !(dc.at && (clock.now() - dc.at) > (cfg.deviceClockStaleMs || 180000));
      if (fresh) {   // the panel-pushed device clock is best — it carries the user's local time + tz name
        var tz = dc.tz ? (' (' + dc.tz + ')') : '';
        if (which === 'date') return 'Today is ' + (dc.date || dc.time) + tz + '.';
        return 'It\u2019s ' + (dc.time || dc.date) + tz + '.';
      }
      // Fallback: derive the time from the newest Discord message id (a snowflake = authoritative UTC
      // server clock), so time/date still work with the panel closed. Apply a configured tz offset if
      // there is one; otherwise report UTC and point at the device clock for exact local time.
      if (lastSeenAt > 0) {
        var offMin = (typeof cfg.timezoneOffsetMins === 'number') ? cfg.timezoneOffsetMins : 0;
        var d = new Date(lastSeenAt + offMin * 60000);
        var label = offMin ? ('UTC' + (offMin >= 0 ? '+' : '-') + Math.abs(offMin / 60)) : 'UTC';
        if (which === 'date') return 'Around ' + d.toISOString().slice(0, 10) + ' (' + label + ', from recent message timestamps).';
        return 'Around ' + d.toISOString().slice(11, 16) + ' ' + label + (offMin ? '' : ' \u2014 turn on the device clock for your exact local time') + ' (from recent message timestamps).';
      }
      if (!dc || (!dc.time && !dc.date)) return 'I don\u2019t have the current clock right now \u2014 turn on \u201cknow the current date & time\u201d in my settings (Behavior tab) and keep the control panel open.';
      return 'my clock reading is stale (the control panel may be closed) \u2014 reopen it and try again.';
    }
    function execCommand(modId, c) {
      var entry = c.entry || resolveVerb(c.cmd);
      if (!entry) return Promise.resolve({ ack: 'unknown command "' + c.cmd + '" \u2014 try ' + cfg.commandPrefix + ' help' });
      if (entry.cooldownMs) {
        var now = clock.now();
        if (now - (lastCmdAt[entry.verb] || 0) < entry.cooldownMs) { log('[chloe.cmd] "' + entry.verb + '" suppressed (per-command cooldown)'); return Promise.resolve({}); }
        lastCmdAt[entry.verb] = now;
      }
      if (typeof entry.handler === 'function') return Promise.resolve(entry.handler(modId, c));
      if (entry.action) {
        if (entry.needsTarget && !c.targetId) return Promise.resolve({ ack: c.cmd + ' needs an @mention of the user' });
        if (entry.action === 'warn') return applyStrike(c.targetId, { reason: c.reason, byModId: modId })
          .then(function (r) { return { ack: r.ok ? (r.value.ack + ' (strike ' + r.value.strikes + ')') : ('failed: ' + r.reason) }; });
        return applyModAction(entry.action, c.targetId, { durationMs: c.durationMs, reason: c.reason, byModId: modId })
          .then(function (r) { return { ack: r.ok ? r.value.ack : ('failed: ' + r.reason) }; });
      }
      return Promise.resolve({ ack: 'unknown command "' + c.cmd + '" \u2014 try ' + cfg.commandPrefix + ' help' });
    }
    // T5 user opt-out (GDPR ethereal): anyone may ask Chloe to forget THEM and stop tracking them
    // in this bucket. This now does three things: (1) erases what it holds, (2) sets the ethereal
    // flag so no new memory forms here until they undo it, (3) stamps a forget-floor so a later
    // `remember me` can never re-learn the erased history. Never lets a moderated user escape a
    // soft-ban/timeout — the moderation row is kept, only ordinary memory is cleared.
    function forgetMe(id, name) {
      var pfx = cfg.commandPrefix || '!chloe';
      var undo = ' (say \u201c' + pfx + ' remember me\u201d anytime to let me start fresh.)';
      // Flag + floor FIRST, so even an ingest racing this poll forms nothing. dropImageMemory clears
      // any image-request history this bucket held (the image surface is covered by ethereal too).
      return setEthereal(id, name)
        .then(function () { return setForgetFloor(id); })
        .then(function () { return dropImageMemory(id); })
        .then(function () { return Promise.resolve(userStore().get(partKey(id))); })
        .then(function (p) {
          var ackMsg;
          function ackSend() { return typeof cfg.send === 'function' ? Promise.resolve(cfg.send(cfg.channelId, ackMsg)) : Promise.resolve(); }
          if (!p) { ackMsg = 'okay ' + name + ', there was nothing to forget \u2014 and I\u2019ll keep no notes on you from here.' + undo; return ackSend(); }
          if (p.state && p.state !== 'active') {
            // Clear ALL ordinary memory (facts/insights included — erasure must be complete), but
            // keep the partition + moderation state so a soft-ban/timeout can't be shed via forget-me.
            p.recent = []; p.interactionCount = 0; p.lastGreetedAt = null; p.lifecycle = 'active'; p.trust = 0; p.trustDayEarned = 0;
            p.facts = []; p.insights = []; delete p.images;
            ackMsg = 'okay ' + name + ', I\u2019ve cleared what I remember and I\u2019ll stop keeping notes (any moderation still stands).' + undo;
            return userStore().set(partKey(id), p).then(function () { return dropEpisodesFor(id, name); }).then(function () { return dropGoalsFor(id); }).then(ackSend);
          }
          ackMsg = 'okay ' + name + ', I\u2019ve forgotten you and I\u2019ll stop keeping notes from here on.' + undo;
          return purge(id, { targetName: name }).then(ackSend);
        });
    }
    // The inverse: lift the ethereal flag so memory may form again from now on. The forget-floor is
    // deliberately left in place, so it starts fresh rather than re-reading the erased past.
    function rememberMe(id, name) {
      function ackSend(m) { return typeof cfg.send === 'function' ? Promise.resolve(cfg.send(cfg.channelId, m)) : Promise.resolve(); }
      return clearEthereal(id).then(function (was) {
        if (!was) return ackSend('you\u2019re already on the record with me, ' + name + ' \u2014 nothing to undo.');
        return ackSend('welcome back, ' + name + ' \u2014 I\u2019ll start getting to know you again from here (I won\u2019t dig up anything from before you asked me to forget).');
      });
    }
    // Erase any image-request history held for a user in this bucket (called by forgetMe). Tolerant
    // of the field not existing yet — image memory is added on the image surface; this keeps the
    // GDPR erase complete regardless of build order.
    function dropImageMemory(id) {
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (!p || !p.images) return;
        delete p.images;
        return userStore().set(partKey(id), p);
      });
    }
    function greetTierFor(info, p, now) {
      if (info.brandNew) return 'intro';
      if (p && p.lastGreetedAt && (now - p.lastGreetedAt) < cfg.greetCooldownMs) return 'none';
      if (info.gapMs != null && info.gapMs >= cfg.greetReturnAfterMs) return 'return';
      return 'none';
    }

    // Process commands and select reply/volunteer/greeting candidates from the messages that are
    // NOT commands and NOT from suppressed users. State gates BEFORE judgment runs.
    function processCommandsAndSelect(incoming, touched, imageEligible, isStartupBatch) {
      // imageEligible: null = normal (any message may trigger image gen); an object {id:true} = startup
      // clamp, only those message ids may trigger image gen (the rest are ingested but never painted).
      // isStartupBatch: true on the first poll after a COLD start / Reset State (no cursor), where
      // `incoming` is a slice of history, not live messages. We seed state from it but must NOT replay
      // historical ACTIONS — no re-running old commands, no re-moderating old messages, no replying to
      // a stale mention. (Greetings are already settled separately; images use the 5-recent clamp.)
      // A WARM restart (cursor present) is genuine catch-up and is never treated as a startup batch.
      function mayPaint(m) { return !imageEligible || !!imageEligible[m.id]; }
      var authorIds = [];
      incoming.forEach(function (m) { if (authorIds.indexOf(m.author.id) < 0) authorIds.push(m.author.id); });
      return Promise.all(authorIds.map(function (id) { return Promise.resolve(userStore().get(partKey(id))); })).then(function (parts) {
        var now = clock.now();
        var stateById = {}, commandAuthors = {};
        authorIds.forEach(function (id, i) { var p = parts[i]; if (p) { applyExpiry(p, now); stateById[id] = p.state || 'active'; } else stateById[id] = 'active'; });
        var acks = [], embeds = [], notices = [], commandCount = 0, addressedName = null, imageReqName = null;
          var channelLangTouched = false, channelLangVal = null;   // v0.90.21: a lang default change rides the summary to the queen (cf. engageMode)
          var actPolicyTouched = false, actPolicyVal = null, actGrantsTouched = false, actGrantsVal = null;   // A1/A4: policy + always-grants ride the same path (queen persists in onPoll)
          var modListTouched = false, modListVal = null;   // A7: elevate/demote/undo ride the same path
          var beatsTouched = false, beatsVal = null, autoModRulesTouched = false, autoModRulesVal = null, procRulesTouched = false, procRulesVal = null;   // A8: a quarantine-release undo restores the live sets it overwrote
          var quarantineTouched = false, quarantineVal = null;   // A8: an undo re-holds released/dropped sets (queen re-stashes in onPoll)
          var dmAcks = [];   // A6/save: {to, text} — delivered via DM first, fail-closed (never falls back to channel)
          var ackSrc = [];   // message id behind each ack (single-source batches reply-reference)
        var canEmbed = typeof cfg.sendEmbed === 'function';
        var chain = Promise.resolve();
        incoming.forEach(function (m) {
          chain = chain.then(function () {
            var c = parseCommand(m.content);
            if (c) c.messageId = m.id;   // lets handlers ack the triggering message (e.g. recap's search indicator)
            if (c) {
              // CAMPAIGN item 2 — BOT-DIRECTIVE GATE: a bot author's message may ENGAGE conversationally but may NEVER
              // be acted on as a command/directive (not a mod command, not the open-command path, not do/tools), even if
              // it posts `!chloe block @u`. This closes the gap where the OPEN-command path (modOnly:false) was reachable
              // by ANY author. Gated by trustHardening (OFF => byte-identical: bots hit the same paths as before).
              if (!mayActOnCommand(m.author)) { log('[wire:trust] BOT command refused (tier=' + trustTier(m.author) + '): "' + String(m.content || '').slice(0, 40) + '" from ' + ((m.author && (m.author.username || m.author.id)) || '?')); return; }
              // Cold-start backlog: don't replay historical commands. EXCEPTION: the image command
              // follows the 5-most-recent image clamp instead (the user wants recent images on startup).
              if (isStartupBatch && c.cmd !== 'image') { log('[chloe.T3] startup: not replaying a backlog command (' + c.cmd + ')'); return; }
              c.messageId = m.id; c.authorName = m.author.username;   // for queue-ack reaction + caption
              if (m.referenced_message) c.referenced = { id: m.referenced_message.id, text: m.referenced_message.content || '', authorName: (m.referenced_message.author && m.referenced_message.author.username) || '' };
              commandCount++; commandAuthors[m.author.id] = true;
              if (c.cmd === 'image' && !mayPaint(m)) { log('[chloe.img] startup: skipping a backlog image command'); return; }   // startup clamp
              if (c.cmd === 'forget') {
                var fa = String(c.rawArgs || '').trim();
                if (fa && !/^me$/i.test(fa) && cfg.factMemory) {   // "forget <a thing>" drops matching facts, keeps the person
                  return forgetFact(m.author.id, fa).then(function (n) { ackSrc.push(m.id); acks.push(n ? ('done \u2014 dropped ' + n + ' thing' + (n === 1 ? '' : 's') + ' I had about you') : ("I wasn\u2019t holding onto anything matching that")); }, function (e) { ackSrc.push(m.id); acks.push('forget hit a snag \u2014 try again in a moment'); log('[chloe.T3] command "forget" failed (' + ((e && e.message) || e) + ') \u2014 batch continues'); });
                }
                return Promise.resolve(forgetMe(m.author.id, m.author.username)).then(null, function (e) { ackSrc.push(m.id); acks.push('forget hit a snag \u2014 try again in a moment'); log('[chloe.T3] command "forget" failed (' + ((e && e.message) || e) + ') \u2014 batch continues'); });  // "forget" / "forget me" wipes the person + goes ethereal
              }
              if (c.cmd === 'remember') {
                return Promise.resolve(rememberMe(m.author.id, m.author.username)).then(null, function (e) { ackSrc.push(m.id); acks.push('remember hit a snag \u2014 try again in a moment'); log('[chloe.T3] command "remember" failed (' + ((e && e.message) || e) + ') \u2014 batch continues'); });   // "remember me" lifts ethereal; memory may form again
              }
              if (c.entry && c.entry.modOnly === false) return execCommand(m.author.id, c).then(function (res) { if (res) { if (res.react) ackReact(m.id, res.react); if (res.channelLangTouched) { channelLangTouched = true; channelLangVal = res.channelLang || null; } if (res.actPolicyTouched) { actPolicyTouched = true; actPolicyVal = res.actPolicy; } if (res.actGrantsTouched) { actGrantsTouched = true; actGrantsVal = res.actGrants; } if (res.modListTouched) { modListTouched = true; modListVal = res.modList; } if (res.beatsTouched) { beatsTouched = true; beatsVal = res.beats; } if (res.autoModRulesTouched) { autoModRulesTouched = true; autoModRulesVal = res.autoModRules; } if (res.procRulesTouched) { procRulesTouched = true; procRulesVal = res.procRules; } if (res.quarantineTouched) { quarantineTouched = true; quarantineVal = res.quarantine; } if (res.dmTo) dmAcks.push({ to: res.dmTo, text: res.dmBody || res.ack }); if (canEmbed && res.embed) embeds.push({ em: res.embed, card: res.thoughtCard === 'cmd' ? THOUGHTCARD_CMD : null }); else if (res.ack) { ackSrc.push(m.id); acks.push(res.ack); } } }, function (e) { ackSrc.push(m.id); acks.push('that ' + c.cmd + ' hit a snag \u2014 try again in a moment'); log('[chloe.T3] command "' + c.cmd + '" failed (' + ((e && e.message) || e) + ') \u2014 batch continues'); });  // open to anyone
              if (isMod(m.author.id)) return execCommand(m.author.id, c).then(function (res) { if (res) { if (res.react) ackReact(m.id, res.react); if (res.channelLangTouched) { channelLangTouched = true; channelLangVal = res.channelLang || null; } if (res.actPolicyTouched) { actPolicyTouched = true; actPolicyVal = res.actPolicy; } if (res.actGrantsTouched) { actGrantsTouched = true; actGrantsVal = res.actGrants; } if (res.modListTouched) { modListTouched = true; modListVal = res.modList; } if (res.beatsTouched) { beatsTouched = true; beatsVal = res.beats; } if (res.autoModRulesTouched) { autoModRulesTouched = true; autoModRulesVal = res.autoModRules; } if (res.procRulesTouched) { procRulesTouched = true; procRulesVal = res.procRules; } if (res.quarantineTouched) { quarantineTouched = true; quarantineVal = res.quarantine; } if (res.dmTo) dmAcks.push({ to: res.dmTo, text: res.dmBody || res.ack }); if (canEmbed && res.embed) embeds.push({ em: res.embed, card: res.thoughtCard === 'cmd' ? THOUGHTCARD_CMD : null }); else if (res.ack) { ackSrc.push(m.id); acks.push(res.ack); } } }, function (e) { ackSrc.push(m.id); acks.push('that ' + c.cmd + ' hit a snag \u2014 try again in a moment'); log('[chloe.T3] command "' + c.cmd + '" failed (' + ((e && e.message) || e) + ') \u2014 batch continues'); });
              log('[chloe.T3] ignoring command from non-mod ' + (m.author.username || m.author.id));
              return;
            }
            if (looksLikeCommand(m.content)) log('[chloe.T3] "' + String(m.content || '').slice(0, 40) + '" starts with ' + cfg.commandPrefix + ' but is not a known command \u2014 treating as normal chat');
            // AFK (front-end only, no AI call): the author speaking clears their own away state, and
            // pinging someone who is away gets a quiet heads-up. Runs on normal chat, before the
            // engagement gates, so it works even for people Chloe otherwise wouldn't reply to.
            var afkChain = Promise.resolve();
            afkChain = afkChain.then(function () {
              return clearAfk(m.author.id).then(function (prior) {
                if (prior) { var since = clock.now() - prior.since; if (since > 120000) notices.push('welcome back, ' + (m.author.username || 'friend') + ' \u2014 away ' + humanGap(since)); }
              });
            });
            var pings = String(m.content || '').match(/<@!?(\d+)>/g) || [];
            if (pings.length) {
              var seen = {};
              pings.forEach(function (tok) {
                var id = tok.replace(/<@!?(\d+)>/, '$1');
                if (id === m.author.id || id === cfg.botUserId || seen[id]) return;
                seen[id] = true;
                afkChain = afkChain.then(function () {
                  return getAfk(id).then(function (a) {
                    if (!a) return;
                    var key = id;
                    if (now - (afkNoticed[key] || 0) < cfg.afkNoticeCooldownMs) return;   // don't spam the same notice
                    if (!(key in afkNoticed)) { afkNoticedKeys.push(key); if (afkNoticedKeys.length > 500) { var oldK = afkNoticedKeys.shift(); delete afkNoticed[oldK]; } }
                    afkNoticed[key] = now;
                    notices.push((a.name || 'they') + ' is away' + (a.reason ? ' (' + a.reason.slice(0, 80) + ')' : '') + ' \u2014 since ' + humanGap(now - a.since) + ' ago');
                  });
                });
              });
            }
            return afkChain.then(function () {
            // Auto-mod watches everyone except mods, BEFORE the engagement-suppression gate, so a
            // repeat offender who is already ignored/timed-out still escalates up the strike ladder.
            // Skip only the terminal soft-ban (already maximally handled reversibly — re-moderating is moot).
            if (autoModEnabled() && !isStartupBatch && !isMod(m.author.id) && stateById[m.author.id] !== 'soft-ban') {
              var rule = matchAutoMod(m.content);
              if (rule) {
                commandAuthors[m.author.id] = true;   // handled — don't also reply/greet this person this batch
                if (rule.action === 'warn') {   // C1: escalate along the strike ladder
                  log('[chloe.automod] rule "' + String(rule.pattern).slice(0, 30) + '" (' + (rule.type || 'text') + ') matched ' + (m.author.username || m.author.id) + ' \u2192 warn');
                  return applyStrike(m.author.id, { reason: rule.reason || ('auto-mod: ' + rule.pattern), byModId: 'auto' });
                }
                var act = REVERSIBLE_ACTIONS[rule.action] ? rule.action : 'ignore';   // never auto-permaban (F1)
                log('[chloe.automod] rule "' + String(rule.pattern).slice(0, 30) + '" (' + (rule.type || 'text') + ') matched ' + (m.author.username || m.author.id) + ' \u2192 ' + act);
                return applyModAction(act, m.author.id, { durationMs: rule.durationMs, reason: rule.reason || ('auto-mod: ' + rule.pattern), byModId: 'auto' });
              }
            }
            if (stateById[m.author.id] && stateById[m.author.id] !== 'active') return; // suppressed: invisible to engagement
            if (engageMode === 'locked' && !isMod(m.author.id)) {   // raid lockdown: only mods get engagement (auto-mod above still ran)
              if (addressKind(m.content) !== 'none') { ackWorking(m.id, cfg.ackLockdownEmoji); scheduleAckClear(m.id, cfg.ackLockdownEmoji); }   // 🔒 honest mods-only signal (lockdown is a PUBLIC mode; quiet moderation stays quiet)
              return;
            }
            var addressed = isAddressed(m.content) || (engageMode === 'open');
            if (imageEnabled() && addressed && mayPaint(m) && cfg.imageMemory) {
              var partForEdit = parts[authorIds.indexOf(m.author.id)];
              var lastImg = partForEdit && partForEdit.lastImage;
              var editText = parseImageEdit(m.content, lastImg, now);
              if (editText) {
                if (paint.queue.length >= cfg.imageQueueMax) {
                  log('[chloe.img] queue full (' + paint.queue.length + '/' + cfg.imageQueueMax + '); dropping edit from ' + (m.author.username || m.author.id));
                  if (typeof cfg.send === 'function') { try { Promise.resolve(cfg.send(cfg.channelId, 'i\u2019ve got a few images going already, ' + m.author.username + ' \u2014 ask me again in a moment')).catch(function (e) { log('[chloe.img] queue-full notice send failed (' + ((e && e.message) || e) + ')'); }); } catch (e) { log('[chloe.img] queue-full notice send failed (' + ((e && e.message) || e) + ')'); } }
                  return;
                }
                // rebuild the prompt: prefer the AI hook (handles arbitrary natural language), fall
                // back to the deterministic rewrite. Either way it's a fresh generation (no img2img).
                var mref = m, lref = lastImg, eref = editText;
                var rebuild = (typeof cfg.editPrompt === 'function')
                  ? Promise.resolve(cfg.editPrompt({ prev: lref.prompt, request: eref })).then(function (r) {
                      var np = (r && r.ok && typeof r.value === 'string') ? r.value.trim() : '';
                      if (!np || np.replace(/[^a-z0-9]/ig, '').length < 2) return buildEditedPrompt(lref.prompt, eref);
                      return { prompt: np.slice(0, 400), resolution: pickResolution(np + ' ' + eref) };
                    }, function () { return buildEditedPrompt(lref.prompt, eref); })
                  : Promise.resolve(buildEditedPrompt(lref.prompt, eref));
                return rebuild.then(function (built) {
                  var qItem = { messageId: mref.id, authorId: mref.author.id, authorName: mref.author.username, prompt: built.prompt, resolution: built.resolution, dm: !!lref.dm, at: now, isEdit: true };
                  if (lref.guidanceScale != null) qItem.guidanceScale = lref.guidanceScale;
                  if (lref.removeBackground) qItem.removeBackground = true;
                  paint.queue.push(qItem);
                  if (paint.painting || paint.queue.length > 1) setQueueAck(qItem, queueEmojiFor(paint.queue.length));
                  if (reply.queue[mref.author.id]) delete reply.queue[mref.author.id];
                  if (greet.pending && greet.pending.authorId === mref.author.id) greet.pending = null;
                  imageReqName = mref.author.username;
                  log('[chloe.img] edit from ' + mref.author.username + ': \u201c' + eref.slice(0, 40) + '\u201d \u2192 \u201c' + built.prompt.slice(0, 50) + '\u201d');
                });
              }
            }
            if (imageEnabled() && addressed && mayPaint(m)) {
              var imgReq = parseImageRequest(m.content);
              if (imgReq) {
                if (paint.queue.length >= cfg.imageQueueMax) {
                  log('[chloe.img] queue full (' + paint.queue.length + '/' + cfg.imageQueueMax + '); dropping request from ' + (m.author.username || m.author.id));
                  if (typeof cfg.send === 'function') { try { Promise.resolve(cfg.send(cfg.channelId, 'i\u2019ve got a few images going already, ' + m.author.username + ' \u2014 ask me again in a moment')).catch(function (e) { log('[chloe.img] queue-full notice send failed (' + ((e && e.message) || e) + ')'); }); } catch (e) { log('[chloe.img] queue-full notice send failed (' + ((e && e.message) || e) + ')'); } }
                } else {
                  var qItem = { messageId: m.id, authorId: m.author.id, authorName: m.author.username, prompt: imgReq.prompt, resolution: imgReq.resolution, dm: imgReq.dm, at: now };
                  if (imgReq.guidanceScale != null) qItem.guidanceScale = imgReq.guidanceScale;
                  if (imgReq.removeBackground) qItem.removeBackground = true;
                  paint.queue.push(qItem);
                  // place in line: if something's already painting or ahead, show their number now.
                  if (paint.painting || paint.queue.length > 1) setQueueAck(qItem, queueEmojiFor(paint.queue.length));
                }
                if (reply.queue[m.author.id]) delete reply.queue[m.author.id];   // image supersedes a text reply this turn
                if (greet.pending && greet.pending.authorId === m.author.id) greet.pending = null;
                imageReqName = m.author.username;
                return;
              }
            }
            if (replyEnabled() && addressed && !isStartupBatch) {
              var gi = touched && touched.greetInfo && touched.greetInfo[m.author.id];
              var newUser = !!(gi && gi.brandNew);
              var pri = replyPriority({ isMod: isMod(m.author.id), kind: addressKind(m.content), isNew: newUser, trusted: !!(gi && gi.trusted) });
              reply.queue[m.author.id] = { messageId: m.id, authorId: m.author.id, authorName: m.author.username, content: contentWithAttach(m), at: now, priority: pri };
              if (greet.pending && greet.pending.authorId === m.author.id) greet.pending = null;  // replying IS the engagement
              addressedName = m.author.username;
            } else if (gateEnabled() && engageMode === 'normal' && !isStartupBatch) {
              gate.pending = { messageId: m.id, authorId: m.author.id, authorName: m.author.username, content: contentWithAttach(m), at: now, reactions: summarizeReactions(m) };
              addrNote(m);   // v0.90.14: say WHY it was not treated as addressed (silent for plain chatter)
            }
            });   // end afkChain.then wrapper
          });
        });
        return chain.then(function () {
          if (imageReqName) log('[chloe.img] image requested by ' + imageReqName + '; queued (debounce ' + cfg.debounceMs + 'ms)');
          if (addressedName) log('[chloe.T1] addressed by ' + addressedName + '; reply queued (debounce ' + cfg.debounceMs + 'ms)');
          // T5: pick at most one greeting candidate (intro beats return); never the person we're already
          // engaging, never a command author this batch, never a suppressed user — and not during the
          // settle window right after Start (people already in the room aren't fresh arrivals).
          if (greetEnabled() && engageMode !== 'locked' && touched && touched.greetInfo && !inGreetSettle(now)) {
            var pick = null;
            authorIds.forEach(function (id, i) {
              var info = touched.greetInfo[id]; if (!info) return;
              if (stateById[id] && stateById[id] !== 'active') return;
              if (commandAuthors[id]) return;
              if (reply.queue[id]) return;
              var tier = greetTierFor(info, parts[i], now);
              if (tier === 'none') return;
              if (!pick || (tier === 'intro' && pick.tier !== 'intro')) pick = { authorId: id, tier: tier, gapMs: info.gapMs, name: info.name, at: now };
            });
            if (pick) { greet.pending = pick; log('[chloe.T5] greeting queued for ' + pick.name + ' (' + pick.tier + ', settle ' + cfg.greetDebounceMs + 'ms)'); }
          }
          if (greetEnabled() && inGreetSettle(now) && !greetSettleLogged) {
            greetSettleLogged = true;
            log('[chloe.T5] greetings paused for ~' + Math.round(cfg.greetSettleMs / 1000) + 's after start (current speakers treated as already-present, not arrivals)');
          }
          // AFK heads-ups + welcome-backs flush regardless of the ackCommands toggle — they're a
          // user-facing utility, not a command confirmation.
          if (notices.length && typeof cfg.send === 'function') {
            try { Promise.resolve(cfg.send(cfg.channelId, notices.join('\n'))).catch(function (e) { log('[chloe.T3] notices send failed (' + ((e && e.message) || e) + ')'); }); } catch (e) { log('[chloe.T3] notices send threw (' + ((e && e.message) || e) + ')'); }
          }
          // A6/save: DM-bound acks deliver FIRST, unconditionally (a requested DM is the
          // command's effect, not its confirmation) and fail-closed — a transcript never
          // falls back to the channel; a failed DM joins the channel acks as error text only.
          var dmJob = Promise.resolve();
          (dmAcks || []).forEach(function (d) {
            dmJob = dmJob.then(function () {
              return sendDmText(d.to, d.text).then(function (r) {
                if (!r.ok) { log('[chloe.save] DM failed for ' + d.to + ' (' + r.reason + ')'); acks.push('couldn\'t DM that (' + r.reason + ') — nothing was posted'); }
              });
            });
          });
          return dmJob.then(function () {
            if ((acks.length || embeds.length) && cfg.ackCommands) {
              log('[chloe.T3] ran ' + commandCount + ' command(s)' + (embeds.length ? (' (' + embeds.length + ' embed)') : ''));
              var outs = [];
              if (acks.length && typeof cfg.send === 'function') outs.push(Promise.resolve(cfg.send(cfg.channelId, acks.join('\n'), (cfg.replyReference !== false && acks.length === 1 && ackSrc[0]) ? { replyTo: ackSrc[0] } : undefined)));   // a lone ack attaches to its command
              embeds.forEach(function (slot) {
                if (slot && slot.card) {
                  outs.push(thoughtCardPublish(slot.card, cfg.channelId, 'embed', function () {
                    return Promise.resolve(cfg.sendEmbed(cfg.channelId, slot.em));
                  }, slot.em).then(function () {}, function () {}));
                } else outs.push(Promise.resolve(cfg.sendEmbed(cfg.channelId, slot && slot.em ? slot.em : slot)));
              });
              return Promise.all(outs.map(function (p) { return p.then(function () {}, function () {}); })).then(function () { return { commands: commandCount, channelLangTouched: channelLangTouched, channelLang: channelLangVal, actPolicyTouched: actPolicyTouched, actPolicy: actPolicyVal, actGrantsTouched: actGrantsTouched, actGrants: actGrantsVal, modListTouched: modListTouched, modList: modListVal, beatsTouched: beatsTouched, beats: beatsVal, autoModRulesTouched: autoModRulesTouched, autoModRules: autoModRulesVal, procRulesTouched: procRulesTouched, procRules: procRulesVal, quarantineTouched: quarantineTouched, quarantine: quarantineVal }; });
            }
            return { commands: commandCount, channelLangTouched: channelLangTouched, channelLang: channelLangVal, actPolicyTouched: actPolicyTouched, actPolicy: actPolicyVal, actGrantsTouched: actGrantsTouched, actGrants: actGrantsVal, modListTouched: modListTouched, modList: modListVal, beatsTouched: beatsTouched, beats: beatsVal, autoModRulesTouched: autoModRulesTouched, autoModRules: autoModRulesVal, procRulesTouched: procRulesTouched, procRules: procRulesVal, quarantineTouched: quarantineTouched, quarantine: quarantineVal };
          });
        });
      });
    }

    // T5 greeting dispatch: fires after the settling debounce, re-checks suppression + cooldown at
    // fire time, asks the brain for a line, sends it, and records lastGreetedAt (one per crossing).
    function processGreet() {
      if (!greetEnabled() || !greet.pending || greet.greeting) return Promise.resolve(null);
      var g = greet.pending; var now = clock.now();
      if (now - g.at < cfg.greetDebounceMs) return Promise.resolve(null);   // still settling
      if (now - lastActAt < cfg.globalCooldownMs) return Promise.resolve(null);    // light global gap
      greet.pending = null; greet.greeting = true;
      return Promise.resolve(userStore().get(partKey(g.authorId))).then(function (p) {
        if (!p || isSuppressed(p, now) || (p.lastGreetedAt && (now - p.lastGreetedAt) < cfg.greetCooldownMs)) { greet.greeting = false; return null; }
        return assembleContext(p).then(function (context) {
          var gctx = { kind: g.tier, person: { id: p.id, name: p.name }, interactionCount: p.interactionCount || 0, gapMs: g.gapMs, recent: context };
          indicateTyping();
          return Promise.resolve(cfg.greetFn(gctx)).then(function (res) {
            if (!res || !res.ok || !res.value) { greet.greeting = false; log('[chloe.T5] greet brain declined/failed for ' + p.name + ' — staying quiet this round'); return null; }
            // commit-point revalidation: were they moderated while it was composing the hello?
            return Promise.resolve(userStore().get(partKey(p.id))).then(function (pp2) {
              if (pp2 && isSuppressed(pp2, clock.now())) {
                greet.greeting = false;
                log('[chloe.abandon] greeting not sent — ' + p.name + ' was moderated mid-generation');
                return null;
              }
            return Promise.resolve(cfg.send(cfg.channelId, hygiene(String(res.value)))).then(function () {
              p.lastGreetedAt = now; lastActAt = now;
              return userStore().set(partKey(p.id), p).then(function () {
                greet.greeting = false;
                log('[chloe.T5] greeted ' + p.name + ' (' + g.tier + ')');
                return { authorId: p.id, tier: g.tier };
              });
            });
            });
          });
        });
      }).catch(function (e) { greet.greeting = false; log('[chloe.T5] greet error: ' + e.message); return null; });
    }

    // ---- A1/A4: actuation policy + approvals (autonomous output only) --------
    // Classes: beats | checkins | lull | thoughts | news. Grants (cfg.actGrants, ChloeModAudit)
    // suppress holds per channel; approve-once flags let one held instance
    // through on the next poll; dismissals snooze the class for 24h.
    function actPolicy() { var p = cfg.actPolicy; return (p === 'ask' || p === 'deny') ? p : 'allow'; }
    function getPendingAct() {
      return Promise.resolve(store.get(ACTPEND_KEY)).then(function (l) {
        if (!Array.isArray(l)) return [];
        return l.filter(function (e) { return e && typeof e.id === 'string' && typeof e.class === 'string'; });
      });
    }
    function pruneSnooze(snooze, now) {
      var out = {};
      if (snooze && typeof snooze === 'object' && !Array.isArray(snooze)) {
        Object.keys(snooze).forEach(function (k) { if (Number(snooze[k]) > now) out[k] = Number(snooze[k]); });
      }
      return out;
    }
    // 'go' | 'hold' | 'deny'. Consumes one-shot approvals; never throws.
    // Precedence: deny (kill switch — nothing actuates, not even grants) ->
    // approve-once (explicit release) -> snooze (explicit quiet) -> grants ->
    // ask (hold) -> allow (go).
    var ACTLOG_MAX = 30;
    function getActLog() {
      return Promise.resolve(store.get(ACTLOG_KEY)).then(function (l) {
        if (!Array.isArray(l)) return [];
        return l.filter(function (e) { return e && typeof e.at === 'number' && typeof e.class === 'string' && typeof e.verdict === 'string'; }).slice(-ACTLOG_MAX);
      });
    }
    // Fire-and-forget: the verdict is returned without waiting for the write
    // (the store never rejects, so this can't produce an unhandled rejection).
    function logActDecision(cls, verdict, why) {
      try {
        Promise.resolve(store.get(ACTLOG_KEY)).then(function (l) {
          var list = Array.isArray(l) ? l.filter(function (e) { return e && typeof e.at === 'number'; }) : [];
          list.push({ at: clock.now(), class: String(cls), verdict: String(verdict), why: String(why || '').slice(0, 120) });
          return store.set(ACTLOG_KEY, list.slice(-ACTLOG_MAX));
        });
      } catch (e) { log('[chloe.act] journal write failed (' + ((e && e.message) || e) + ')'); }
      return null;
    }
    // Shared gate evaluation. consume=true spends an approve-once flag (the real
    // path); consume=false only peeks (the what-if dry run). Never journals.
    function actGateEval(cls, policyOverride, consume) {
      var now = clock.now();
      var p = (policyOverride === 'ask' || policyOverride === 'deny') ? policyOverride : ((policyOverride === 'allow') ? 'allow' : actPolicy());
      if (p === 'deny') return Promise.resolve({ verdict: 'deny', why: 'policy:deny' });
      return Promise.resolve(store.get(ACTONCE_KEY)).then(function (flags) {
        flags = (flags && typeof flags === 'object' && !Array.isArray(flags)) ? flags : {};
        if (flags[cls]) {
          if (!consume) return { verdict: 'go', why: 'approve-once' };
          delete flags[cls];
          return store.set(ACTONCE_KEY, flags).then(function () { return { verdict: 'go', why: 'approve-once' }; });
        }
        return Promise.resolve(store.get(ACTSNOOZE_KEY)).then(function (sn) {
          var snooze = pruneSnooze(sn, now);
          if (snooze[cls]) return { verdict: 'deny', why: 'snoozed' };
          var grants = Array.isArray(cfg.actGrants) ? cfg.actGrants : [];
          var g = null;
          if (typeof ChloeModAudit !== 'undefined' && ChloeModAudit.validateGrants) {
            var list = ChloeModAudit.validateGrants(grants);
            for (var i = 0; i < list.length; i++) {
              if (list[i].action === cls && (list[i].resource === '*' || list[i].resource === cfg.channelId) && (list[i].until == null || now < list[i].until)) { g = list[i]; break; }
            }
          }
          if (g) return { verdict: 'go', why: 'grant:' + g.action + '@' + g.resource };
          if (p === 'ask') return { verdict: 'hold', why: 'policy:ask' };
          return { verdict: 'go', why: 'policy:allow' };
        });
      });
    }
    // 'go' | 'hold' | 'deny'. Consumes one-shot approvals; never throws.
    // Every real verdict is journaled (fire-and-forget) for replay/why-silent.
    function actGate(cls) {
      return actGateEval(cls, null, true).then(function (r) {
        if (r.verdict === 'deny') log('[chloe.act] ' + cls + ' suppressed (' + r.why + ')');
        logActDecision(cls, r.verdict, r.why);
        return r.verdict;
      });
    }
    // Read-only schedule snapshot: what is due / quiet, and when.
    function actSchedule() {
      var now = clock.now();
      var out = { beats: [], lull: null, checkins: null, aipass: {} };
      return Promise.resolve(store.get(BEATS_KEY)).then(function (st) {
        st = (st && typeof st === 'object' && !Array.isArray(st)) ? st : {};
        (Array.isArray(cfg.beats) ? cfg.beats : []).forEach(function (b) {
          if (!b || !b.id || !b.intervalMs) return;
          var last = Number(st[b.id]) || 0;
          out.beats.push({ id: String(b.id), lastMs: last, dueInMs: last ? Math.max(0, (last + Number(b.intervalMs)) - now) : 0 });
        });
        return Promise.resolve(store.get(RHYTHM_KEY));
      }).then(function (rh) {
        var lastActivity = (rh && typeof rh.lastActivity === 'number') ? rh.lastActivity : null;
        out.lull = { silentForMs: lastActivity == null ? null : Math.max(0, now - lastActivity), patienceMs: cfg.lullPatienceMs || 86400000 };
        return Promise.resolve(store.get(CHECKIN_KEY));
      }).then(function (ci) {
        ci = (ci && typeof ci === 'object' && !Array.isArray(ci)) ? ci : {};
        out.checkins = { lastMs: Number(ci.__last) || 0, gapMs: cfg.checkinGapMs || 86400000 };
        return Promise.resolve(store.get(LULLDIAG_KEY));
      }).then(function (ld) {
        if (ld && ld.lastAt) out.lull.diag = { lastAt: ld.lastAt, lastResult: ld.lastResult, lastError: ld.lastError };
        return Promise.resolve(store.get(CHECKINDIAG_KEY));
      }).then(function (cd) {
        if (cd && cd.lastAt) out.checkins.diag = { lastAt: cd.lastAt, lastResult: cd.lastResult, lastError: cd.lastError };
        return Promise.resolve(store.get(AIPASS_KEY));
      }).then(function (ap) {
        out.aipass = (ap && typeof ap === 'object' && !Array.isArray(ap)) ? ap : {};
        return out;
      });
    }
    // Open-display mapping for journal reasons: coarse verdicts for anyone
    // (grant resources stay mod-side; `whatif` shows full detail to mods).
    function coarseActWhy(why) {
      var w = String(why || '');
      if (w === 'policy:deny') return 'denied by policy';
      if (w === 'policy:ask') return 'held by policy';
      if (w === 'policy:allow') return 'allowed by policy';
      if (w === 'approve-once') return 'released by a mod';
      if (w === 'snoozed') return 'quiet after dismiss';
      if (w.indexOf('grant:') === 0) return 'always-allowed';
      return w.slice(0, 40) || 'decided';
    }
    // Full why-silent snapshot: policy, grants, holds, flags, journal, schedule.
    function actWhy() {
      var now = clock.now();
      return getPendingAct().then(function (pending) {
        return Promise.resolve(store.get(ACTONCE_KEY)).then(function (flags) {
          flags = (flags && typeof flags === 'object' && !Array.isArray(flags)) ? flags : {};
          return Promise.resolve(store.get(ACTSNOOZE_KEY)).then(function (sn) {
            return getActLog().then(function (log) {
              return actSchedule().then(function (sched) {
                var grants = (typeof ChloeModAudit !== 'undefined' && ChloeModAudit.validateGrants && Array.isArray(cfg.actGrants)) ? ChloeModAudit.validateGrants(cfg.actGrants) : [];
                return {
                  policy: actPolicy(),
                  grants: grants.map(function (g) { return { action: g.action, resource: g.resource, scope: g.scope }; }),
                  pending: pending,
                  once: Object.keys(flags).filter(function (k) { return !!flags[k]; }),
                  snoozed: pruneSnooze(sn, now),
                  log: log.slice(-10),
                  sched: sched
                };
              });
            });
          });
        });
      });
    }
    // Dry run: gate verdicts per class under a hypothetical policy. Reads live
    // flags/snoozes/grants, consumes nothing, writes nothing (no holds, no
    // journal). Verdicts are gate-level: what would happen IF the class is due.
    function actWhatIf(policy) {
      var p = String(policy || '').toLowerCase();
      if (p !== 'allow' && p !== 'ask' && p !== 'deny') return Promise.resolve({ ok: false, reason: 'policy must be allow|ask|deny' });
      var classes = ['beats', 'checkins', 'lull', 'thoughts', 'news'];
      return actSchedule().then(function (sched) {
        var chain = Promise.resolve(), res = {};
        classes.forEach(function (cls) {
          chain = chain.then(function () { return actGateEval(cls, p, false).then(function (r) { res[cls] = r; }); });
        });
        return chain.then(function () { return { ok: true, policy: p, results: res, sched: sched }; });
      });
    }
    function holdAct(cls, reason) {
      var now = clock.now();
      return getPendingAct().then(function (list) {
        var fresh = list.filter(function (e) { return (now - (e.at || 0)) < 86400000; }).slice(-19);
        if (fresh.some(function (e) { return e.class === cls; })) return false;   // one hold per class
        fresh.push({ id: 'a' + now.toString(36) + cls.slice(0, 2), class: cls, at: now, reason: String(reason || '').slice(0, 140) });
        return store.set(ACTPEND_KEY, fresh).then(function () {
          log('[chloe.act] ' + cls + ' held for approval (' + reason + ')');
          return true;
        });
      });
    }
    function approveAct(idOrAll, always, by) {
      var now = clock.now();
      return getPendingAct().then(function (list) {
        var all = (String(idOrAll).toLowerCase() === 'all');
        var hit = list.filter(function (e) { return all || e.id === idOrAll; });
        if (!hit.length) return { approved: [], classes: [], grants: [] };
        var ids = {}; hit.forEach(function (e) { ids[e.id] = true; });
        var rest = list.filter(function (e) { return !ids[e.id]; });
        return store.set(ACTPEND_KEY, rest).then(function () {
          return Promise.resolve(store.get(ACTONCE_KEY)).then(function (flags) {
            flags = (flags && typeof flags === 'object' && !Array.isArray(flags)) ? flags : {};
            var classes = [];
            hit.forEach(function (e) { if (classes.indexOf(e.class) < 0) classes.push(e.class); flags[e.class] = 1; });
            return store.set(ACTONCE_KEY, flags).then(function () {
              var grants = [];
              if (always && typeof ChloeModAudit !== 'undefined' && ChloeModAudit.grant) {
                classes.forEach(function (c) {
                  var g = ChloeModAudit.grant(c, cfg.channelId, 'always', now);
                  if (g) grants.push(g);
                });
              }
              log('[chloe.act] approved ' + hit.length + ' held action(s)' + (always ? ' (+ always-granted)' : ''));
              // A6: the approval AND the always-grants are separate stack entries (undo pops
              // the grants first, then the approval — newest inverse first).
              var chainU = pushUndoEntry({ kind: 'approve-once', by: (by == null ? null : String(by)), summary: 'approved ' + hit.length + ' (' + classes.join(', ') + ')' + (always ? ' + always-granted' : ''), inverse: { classes: classes } });
              if (grants.length) chainU = chainU.then(function () { return pushUndoEntry({ kind: 'grant-add', by: (by == null ? null : String(by)), summary: 'always-granted ' + classes.join(', '), inverse: { grants: grants } }); });
              return chainU.then(function () { return { approved: hit.map(function (e) { return e.id; }), classes: classes, grants: grants }; });
            });
          });
        });
      });
    }
    function dismissAct(idOrAll, by) {
      var now = clock.now();
      return getPendingAct().then(function (list) {
        var all = (String(idOrAll).toLowerCase() === 'all');
        var hit = list.filter(function (e) { return all || e.id === idOrAll; });
        if (!hit.length) return { dismissed: [] };
        var ids = {}; hit.forEach(function (e) { ids[e.id] = true; });
        var rest = list.filter(function (e) { return !ids[e.id]; });
        var classes = [];
        hit.forEach(function (e) { if (e && e.class && classes.indexOf(e.class) < 0) classes.push(e.class); });
        return store.set(ACTPEND_KEY, rest).then(function () {
          return Promise.resolve(store.get(ACTSNOOZE_KEY)).then(function (sn) {
            var snooze = pruneSnooze(sn, now);
            hit.forEach(function (e) { snooze[e.class] = now + 86400000; });   // dismissed = quiet for a day
            return store.set(ACTSNOOZE_KEY, snooze).then(function () {
              log('[chloe.act] dismissed ' + hit.length + ' held action(s) (class quiet 24h)');
              return pushUndoEntry({ kind: 'snooze', by: (by == null ? null : String(by)), summary: 'dismissed ' + hit.length + ' (' + classes.join(', ') + ')', inverse: { classes: classes } }).then(function () {
                return { dismissed: hit.map(function (e) { return e.id; }) };
              });
            });
          });
        });
      });
    }

   // A fire supersedes any pending hold for the class (the output happened — there is
   // nothing left to approve). No-op when the class has no holds (e.g. after approve).
   function clearHolds(cls) {
     return getPendingAct().then(function (list) {
       var rest = list.filter(function (e) { return e.class !== cls; });
       if (rest.length === list.length) return false;
       return store.set(ACTPEND_KEY, rest).then(function () {
         log('[chloe.act] cleared ' + (list.length - rest.length) + ' stale hold(s) for ' + cls + ' (already fired)');
         return true;
       });
     });
   }

    // Follow-up diagnostics (F/K): lull + check-in terminal outcomes and AI-pass
    // last runs. Record-only: never gates anything, failures swallowed.
    function noteLullDiag(result, error) {
      return Promise.resolve(store.set(LULLDIAG_KEY, { lastAt: clock.now(), lastResult: result, lastError: String(error || '').slice(0, 160) })).then(function () {}, function () {});
    }
    function noteCheckinDiag(result, error) {
      return Promise.resolve(store.set(CHECKINDIAG_KEY, { lastAt: clock.now(), lastResult: result, lastError: String(error || '').slice(0, 160) })).then(function () {}, function () {});
    }
    function noteAiPass(name, result, error) {
      return Promise.resolve(store.get(AIPASS_KEY)).then(function (st) {
        st = (st && typeof st === 'object' && !Array.isArray(st)) ? st : {};
        st[name] = { lastAt: clock.now(), lastResult: result, lastError: String(error || '').slice(0, 160) };
        return store.set(AIPASS_KEY, st);
      }).then(function () {}, function () {});
    }
    // One gated AI pass ran: persist a fired/failed stamp for `!chloe timers`.
    // A due-checked pass that found nothing to do records nothing (schedule
    // unchanged, timers keeps "never fired") — and failures rethrow so the
    // poll chain sees exactly what it saw before.
    function runAiPassTracked(cand) {
      return Promise.resolve(cand.run()).then(function (r) {
        if (r == null) return r;
        return noteAiPass(cand.name, 'fired', '').then(function () { return r; });
      }, function (e) {
        return noteAiPass(cand.name, 'failed', (e && e.message) || e).then(function () { throw e; });
      });
    }

    // ---- A6: undo (revert the last applied autonomous/mod action) ------------------
    // Per-channel stack, bounded. Every entry carries its own inverse; popping applies
    // it through the normal validated paths (never shadow code). Rule R: entries are
    // rebuilt defensively — a corrupt stack reads as empty, never throws.
    var UNDO_MAX = 10;
    var UNDO_KINDS = ['modaction', 'strike', 'policy', 'approve-once', 'grant-add', 'grant-remove', 'snooze', 'elevate', 'demote', 'quarantine-release', 'quarantine-drop', 'modlist-add', 'modlist-remove'];
    function cleanUndoEntry(raw) {
      if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
      if (UNDO_KINDS.indexOf(raw.kind) < 0) return null;
      var at = Number(raw.at); if (!isFinite(at) || at < 0) return null;
      var summary = String(raw.summary || '').slice(0, 140); if (!summary) return null;
      var e = { at: Math.floor(at), kind: raw.kind, summary: summary };
      if (raw.targetId != null) e.targetId = String(raw.targetId).slice(0, 32);
      if (raw.name != null) e.name = String(raw.name).slice(0, 64);
      if (raw.by !== undefined) e.by = (raw.by == null ? null : String(raw.by).slice(0, 64));
      if (raw.action !== undefined) e.action = String(raw.action).slice(0, 24);
      e.inverse = (raw.inverse && typeof raw.inverse === 'object' && !Array.isArray(raw.inverse)) ? raw.inverse : {};
      return e;
    }
    function getUndoStack() {
      return Promise.resolve(store.get(UNDO_KEY)).then(function (l) {
        if (!Array.isArray(l)) return [];
        return l.map(cleanUndoEntry).filter(Boolean).slice(-UNDO_MAX);
      });
    }
    function pushUndoEntry(raw) {
      if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return Promise.resolve(false);
      if (raw.at == null) raw.at = clock.now();   // stamp BEFORE validation (at is required)
      var e = cleanUndoEntry(raw);
      if (!e) return Promise.resolve(false);
      return getUndoStack().then(function (list) {
        list.push(e);
        return store.set(UNDO_KEY, list.slice(-UNDO_MAX)).then(function () { return true; });
      });
    }
    function peekUndo() {
      return getUndoStack().then(function (list) {
        if (!list.length) return null;
        var top = list[list.length - 1];
        return { summary: top.summary, at: top.at };
      });
    }
    function popUndoEntry() {
      return getUndoStack().then(function (list) {
        if (!list.length) return null;
        var top = list.pop();
        return store.set(UNDO_KEY, list).then(function () { return top; });
      });
    }
    // Restore a mod-action/strike before-snapshot. `existed:false` means the undone
    // action created this partition — remove it entirely (index + key).
    function restoreModState(targetId, snap, meta) {
      meta = meta || {};
      snap = snap || {};
      var before = snap.before || null;
      if (!snap.existed || !before) {
        return Promise.resolve(removeFromIndex(String(targetId))).then(function () {
          var k = partKey(String(targetId));
          return (userStore().del ? Promise.resolve(userStore().del(k)) : Promise.resolve(userStore().set(k, null))).then(function () {
            return appendModLog({ action: 'undo', targetId: String(targetId), name: (meta.name || String(targetId)), byModId: meta.byModId || null, reason: 'undo of ' + (meta.action || 'mod action') + ' (partition created by it — removed)', at: clock.now() }).then(function () {
              return { ok: true, summary: 'undid ' + (meta.action || 'mod action') + ' on ' + (meta.name || String(targetId)) + ' (new record removed)' };
            });
          });
        });
      }
      return Promise.resolve(userStore().get(partKey(String(targetId)))).then(function (p) {
        if (!p) p = { id: String(targetId), name: meta.name || String(targetId), firstSeen: clock.now(), lastSeen: clock.now(), interactionCount: 0, state: 'active', recent: [] };
        p.state = before.state || 'active';
        p.until = (before.until == null ? null : before.until);
        p.strikes = before.strikes || 0;
        p.lastStrikeAt = (before.lastStrikeAt == null ? null : before.lastStrikeAt);
        if (before.modNote == null) delete p.modNote; else p.modNote = before.modNote;
        p.byModId = meta.byModId || null; p.modAt = clock.now();
        return ensureIndexed(String(targetId)).then(function () {
          return userStore().set(partKey(String(targetId)), p).then(function () {
            return appendModLog({ action: 'undo', targetId: String(targetId), name: p.name || String(targetId), byModId: meta.byModId || null, reason: 'undo of ' + (meta.action || 'mod action'), at: clock.now(), state: p.state }).then(function () {
              return { ok: true, summary: 'undid ' + (meta.action || 'mod action') + ' on ' + (p.name || String(targetId)) + ' (state back to ' + p.state + ')' };
            });
          });
        });
      });
    }
    function clearOnceFlags(classes) {
      return Promise.resolve(store.get(ACTONCE_KEY)).then(function (flags) {
        flags = (flags && typeof flags === 'object' && !Array.isArray(flags)) ? flags : {};
        var had = false;
        (Array.isArray(classes) ? classes : []).forEach(function (c) { if (flags[c]) { had = true; delete flags[c]; } });
        return store.set(ACTONCE_KEY, flags).then(function () { return had; });
      });
    }
    function clearSnooze(classes) {
      return Promise.resolve(store.get(ACTSNOOZE_KEY)).then(function (sn) {
        var snooze = (sn && typeof sn === 'object' && !Array.isArray(sn)) ? sn : {};
        (Array.isArray(classes) ? classes : []).forEach(function (c) { delete snooze[c]; });
        return store.set(ACTSNOOZE_KEY, snooze).then(function () { return true; });
      });
    }
    // Mechanical tier restore for undo: applies the recorded `from` tier with NO rung
    // logic and NO refusal (undo must be total, never partial). The caller re-reads
    // clearanceOf afterwards and reports the ACTUAL tier, so accrued history shows.
    function undoToTier(targetId, name, tier, by) {
      var id = String(targetId || '');
      if (tier === 'admin') {
        var ml = Array.isArray(cfg.modList) ? cfg.modList.slice() : [];
        if (ml.indexOf(id) < 0) ml.push(id);
        cfg.modList = ml;
        return Promise.resolve({ tier: 'admin', persist: { modList: ml } });
      }
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (!p) p = { id: id, name: name || id, firstSeen: clock.now(), lastSeen: clock.now(), interactionCount: 0, state: 'active', recent: [] };
        if (tier === 'resident') p.recognized = { by: by || null, at: clock.now() };
        else if (p.recognized) delete p.recognized;
        return ensureIndexed(id).then(function () {
          return userStore().set(partKey(id), p).then(function () { return { tier: tier }; });
        });
      });
    }
    // Pop the newest entry and apply its inverse engine-locally. Global state
    // (policy/grants/modList) mutates the engine cfg copy; the caller (chat verb
    // via touched-flags, wiring act.undo via cfgSet+patchEngines) persists it.
    // Returns {ok, summary, persist:{...}} or {ok:false, reason}.
    function undoLastApplied() {
      return popUndoEntry().then(function (e) {
        if (!e) return { ok: false, reason: 'nothing undoable — no applied actions on record' };
        var inv = e.inverse || {};
        var done;
        if (e.kind === 'modaction' || e.kind === 'strike') {
          done = restoreModState(e.targetId, { before: inv.before || null, existed: inv.existed !== false }, { name: e.name, byModId: 'undo' + (e.by ? ':' + e.by : ''), action: e.action || e.kind });
        } else if (e.kind === 'policy') {
          var prevPol = (inv.before === 'ask' || inv.before === 'deny') ? inv.before : 'allow';
          cfg.actPolicy = prevPol;
          log('[chloe.act] undo: policy back to ' + prevPol);
          done = Promise.resolve({ ok: true, summary: 'undid policy change (back to ' + prevPol + ')', persist: { actPolicy: prevPol } });
        } else if (e.kind === 'approve-once') {
          done = clearOnceFlags(inv.classes).then(function (had) {
            return { ok: true, summary: had ? 'undid approval (' + (inv.classes || []).join(', ') + ' held again)' : 'approval already fired — nothing left to take back (entry cleared)' };
          });
        } else if (e.kind === 'grant-add') {
          var drop = Array.isArray(inv.grants) ? inv.grants : [];
          var curG = Array.isArray(cfg.actGrants) ? cfg.actGrants.slice() : [];
          var kept = curG.filter(function (g) { return !drop.some(function (d) { return d && g && d.action === g.action && d.resource === g.resource && d.scope === g.scope; }); });
          var n = curG.length - kept.length;
          cfg.actGrants = kept;
          log('[chloe.act] undo: revoked ' + n + ' always-grant(s)');
          done = Promise.resolve({ ok: true, summary: 'undid always-grant (' + n + ' revoked)', persist: { actGrants: kept } });
        } else if (e.kind === 'grant-remove') {
          var back = Array.isArray(inv.grants) ? inv.grants : [];
          var curG2 = Array.isArray(cfg.actGrants) ? cfg.actGrants.slice() : [];
          back.forEach(function (g) {
            if (g && g.action && g.resource && g.scope && !curG2.some(function (x) { return x && x.action === g.action && x.resource === g.resource && x.scope === g.scope; })) curG2.push(g);
          });
          cfg.actGrants = curG2;
          log('[chloe.act] undo: restored ' + back.length + ' grant(s)');
          done = Promise.resolve({ ok: true, summary: 'undid grant revocation (' + back.length + ' restored)', persist: { actGrants: curG2 } });
        } else if (e.kind === 'snooze') {
          done = clearSnooze(inv.classes).then(function () {
            return { ok: true, summary: 'undid dismissal (' + (inv.classes || []).join(', ') + ' will hold again when due)' };
          });
        } else if (e.kind === 'elevate') {
          done = undoToTier(e.targetId, e.name, inv.from || 'guest', 'undo' + (e.by ? ':' + e.by : '')).then(function (mech) {
            return clearanceOf(e.targetId).then(function (t) {
              return { ok: true, summary: 'undid elevation of ' + (e.name || e.targetId) + ' (now ' + t.tier + ', ' + t.basis + ')', persist: mech.persist };
            });
          });
        } else if (e.kind === 'demote') {
          done = undoToTier(e.targetId, e.name, inv.from || 'resident', 'undo' + (e.by ? ':' + e.by : '')).then(function (mech) {
            return clearanceOf(e.targetId).then(function (t) {
              return { ok: true, summary: 'undid demotion of ' + (e.name || e.targetId) + ' (now ' + t.tier + ', ' + t.basis + ')', persist: mech.persist };
            });
          });
        } else if (e.kind === 'quarantine-release') {
          // A8: re-hold what a release let out. `before` carries the live sets
          // the release overwrote (prior-or-null per kind; null = key absent).
          // Engine-local cfg restore; the CALLER persists (chat touched-flags,
          // wiring cfgSet+patchEngines) and re-stashes the released sets.
          var qrel = (inv.released && typeof inv.released === 'object' && !Array.isArray(inv.released)) ? inv.released : {};
          var qbef = (inv.before && typeof inv.before === 'object' && !Array.isArray(inv.before)) ? inv.before : {};
          var qkeys = ['beats', 'autoModRules', 'procRules'].filter(function (k) { return Array.isArray(qrel[k]); });
          var qpersist = { restash: {} };
          qkeys.forEach(function (k) {
            qpersist.restash[k] = qrel[k].slice();
            var prior = Object.prototype.hasOwnProperty.call(qbef, k) ? qbef[k] : null;
            if (Array.isArray(prior)) { cfg[k] = prior.slice(); qpersist[k] = prior.slice(); }
            else { cfg[k] = null; qpersist[k] = null; }
          });
          log('[chloe.act] undo: quarantine release reverted (' + (qkeys.join(', ') || 'nothing held') + ')');
          done = Promise.resolve({ ok: true, summary: qkeys.length ? 'undid quarantine release (' + qkeys.join(', ') + ' live again, released sets re-held)' : 'undid quarantine release (nothing to restore)', persist: qpersist });
        } else if (e.kind === 'quarantine-drop') {
          // A8: a drop destroyed stash only (live sets untouched) — undo re-holds.
          var qdr = (inv.dropped && typeof inv.dropped === 'object' && !Array.isArray(inv.dropped)) ? inv.dropped : {};
          var dkeys = ['beats', 'autoModRules', 'procRules'].filter(function (k) { return Array.isArray(qdr[k]); });
          var dpersist = { restash: {} };
          dkeys.forEach(function (k) { dpersist.restash[k] = qdr[k].slice(); });
          log('[chloe.act] undo: quarantine drop reverted (' + (dkeys.join(', ') || 'nothing held') + ')');
          done = Promise.resolve({ ok: true, summary: dkeys.length ? 'undid quarantine drop (' + dkeys.join(', ') + ' re-held for review)' : 'undid quarantine drop (nothing to restore)', persist: dpersist });
        } else if (e.kind === 'modlist-add') {
          // A8: panel mod.addMod path — mechanical removal of exactly the added id.
          var madd = (inv.id != null) ? String(inv.id) : '';
          var mlA = (Array.isArray(cfg.modList) ? cfg.modList.slice() : []).filter(function (x) { return x !== madd; });
          cfg.modList = mlA;
          log('[chloe.act] undo: mod add reverted (' + madd + ')');
          done = Promise.resolve({ ok: true, summary: 'undid mod add (' + madd + ' removed)', persist: { modList: mlA } });
        } else if (e.kind === 'modlist-remove') {
          // A8: panel mod.removeMod path — mechanical re-add (dedupe: no-op if back already).
          var mrem = (inv.id != null) ? String(inv.id) : '';
          var mlR = Array.isArray(cfg.modList) ? cfg.modList.slice() : [];
          if (mrem && mlR.indexOf(mrem) < 0) mlR.push(mrem);
          cfg.modList = mlR;
          log('[chloe.act] undo: mod removal reverted (' + mrem + ')');
          done = Promise.resolve({ ok: true, summary: 'undid mod removal (' + mrem + ' restored)', persist: { modList: mlR } });
        } else {
          done = Promise.resolve({ ok: false, reason: 'unknown undo kind (entry cleared)' });
        }
        return done.then(function (r) {
          if (r.ok && e.kind !== 'modaction' && e.kind !== 'strike') {
            // mod-action undos journal inside restoreModState; everything else journals here.
            return appendModLog({ action: 'undo', targetId: e.targetId || null, name: e.name || e.kind, byModId: 'undo' + (e.by ? ':' + e.by : ''), reason: r.summary, at: clock.now() }).then(function () { return r; }, function () { return r; });
          }
          return r;
        });
      });
    }

    // ---- A7: clearance (tiers displayed + elevation flow) ---------------------------
    // Data model (guest < resident < admin) lives in ChloeModAudit; these wire it into
    // the engine. Distinct from wire trust tiers (mod/user/bot) and the bond ladder.
    function clearanceOf(uid) {
      var id = String(uid || '');
      if (!id) return Promise.resolve({ tier: 'guest', basis: 'stranger' });
      if (isMod(id)) return Promise.resolve({ tier: 'admin', basis: 'mod list' });
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (p) return { tier: 'resident', basis: p.recognized ? ('recognized by ' + (p.recognized.by || 'a mod')) : 'known by history' };
        if (typeof knownFromOtherSurfaces === 'function') {
          return knownFromOtherSurfaces(id, '').then(function (k) {
            if (k && k.known) return { tier: 'resident', basis: 'known by history (' + (k.where || 'prior record') + ')' };
            return { tier: 'guest', basis: 'stranger' };
          }, function () { return { tier: 'guest', basis: 'stranger' }; });
        }
        return { tier: 'guest', basis: 'stranger' };
      });
    }
    function elevateUser(targetId, targetName, modId, opts) {
      opts = opts || {};
      var id = String(targetId || '');
      if (!/^\d{15,25}$/.test(id)) return Promise.resolve({ ok: false, reason: 'target must be a Discord user id' });
      if (isMod(id)) return Promise.resolve({ ok: false, reason: 'already admin' });
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        var now = clock.now();
        if (p) {
          // resident -> admin: mod-list add (engine cfg copy; the caller persists it).
          var ml = Array.isArray(cfg.modList) ? cfg.modList.slice() : [];
          if (ml.indexOf(id) < 0) ml.push(id);
          cfg.modList = ml;
          var nm = p.name || targetName || id;
          var ep = opts.noUndo ? Promise.resolve(false) : pushUndoEntry({ kind: 'elevate', targetId: id, name: nm, by: modId || null, summary: 'elevated ' + nm + ' to admin', inverse: { from: 'resident', to: 'admin' } });
          return ep.then(function () {
            return appendModLog({ action: 'elevate', targetId: id, name: nm, byModId: modId || null, reason: 'resident -> admin', at: now }).then(function () {
              return { ok: true, tier: 'admin', persist: { modList: ml } };
            });
          });
        }
        // guest -> resident: recognition = remembering (partition + flag).
        var np = { id: id, name: targetName || id, firstSeen: now, lastSeen: now, interactionCount: 0, state: 'active', recent: [], recognized: { by: modId || null, at: now } };
        return ensureIndexed(id).then(function () {
          return userStore().set(partKey(id), np).then(function () {
            var ep2 = opts.noUndo ? Promise.resolve(false) : pushUndoEntry({ kind: 'elevate', targetId: id, name: targetName || id, by: modId || null, summary: 'elevated ' + (targetName || id) + ' to resident', inverse: { from: 'guest', to: 'resident' } });
            return ep2.then(function () {
              return appendModLog({ action: 'elevate', targetId: id, name: targetName || id, byModId: modId || null, reason: 'guest -> resident (recognized)', at: now }).then(function () {
                return { ok: true, tier: 'resident' };
              });
            });
          });
        });
      });
    }
    function demoteUser(targetId, modId, opts) {
      opts = opts || {};
      var id = String(targetId || '');
      if (!/^\d{15,25}$/.test(id)) return Promise.resolve({ ok: false, reason: 'target must be a Discord user id' });
      if (isMod(id)) {
        var ml = (Array.isArray(cfg.modList) ? cfg.modList.slice() : []).filter(function (x) { return x !== id; });
        cfg.modList = ml;
        return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
          var nm = (p && p.name) || id;
          var ep = opts.noUndo ? Promise.resolve(false) : pushUndoEntry({ kind: 'demote', targetId: id, name: nm, by: modId || null, summary: 'demoted ' + nm + ' to resident', inverse: { from: 'admin', to: 'resident' } });
          return ep.then(function () {
            return appendModLog({ action: 'demote', targetId: id, name: nm, byModId: modId || null, reason: 'admin -> resident', at: clock.now() }).then(function () {
              return { ok: true, tier: 'resident', persist: { modList: ml } };
            });
          });
        });
      }
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (!p) return { ok: false, reason: 'stranger already — nothing to demote' };
        // Rule R floor: history-known users re-derive resident — refusing loudly beats a
        // pretend demotion that the next lookup would contradict.
        if (!p.recognized) return { ok: false, reason: 'known by history, not by recognition — clear their data first, recognition can\'t drop below what we remember' };
        delete p.recognized;
        p.byModId = modId || null; p.modAt = clock.now();
        return Promise.resolve(userStore().set(partKey(id), p)).then(function () {
          var ep2 = opts.noUndo ? Promise.resolve(false) : pushUndoEntry({ kind: 'demote', targetId: id, name: p.name || id, by: modId || null, summary: 'demoted ' + (p.name || id) + ' to stranger', inverse: { from: 'resident', to: 'guest' } });
          return ep2.then(function () {
            return appendModLog({ action: 'demote', targetId: id, name: p.name || id, byModId: modId || null, reason: 'resident -> stranger (recognition withdrawn)', at: clock.now() }).then(function () {
              return { ok: true, tier: 'guest' };
            });
          });
        });
      });
    }
    // Own recent lines (scrubbed, clipped) for the `save` verb. Self-only: the caller
    // passes their own id; nothing here reads anyone else.
    function transcriptFor(uid, maxLines) {
      var n = Math.max(1, Math.min(40, parseInt(maxLines, 10) || 20));
      return Promise.resolve(userStore().get(partKey(String(uid || '')))).then(function (p) {
        var lines = ((p && p.recent) || []).slice(-n).map(function (ln) {
          return scrubDiscordTokens(String((ln && ln.content) || '')).slice(0, 240);
        }).filter(function (t) { return !!t; });
        return lines;
      });
    }
    // DM-safe chunking: split on line boundaries at <= max chars; cap chunks; the
    // remainder becomes a truncation note (never silently dropped).
    function chunkDm(text, max, cap) {
      max = max || 1900; cap = cap || 4;
      var lines = String(text || '').split('\n'), out = [], cur = '';
      lines.forEach(function (ln) {
        while (ln.length > max) { if (cur) { out.push(cur); cur = ''; } out.push(ln.slice(0, max)); ln = ln.slice(max); }
        if ((cur ? cur.length + 1 : 0) + ln.length > max) { out.push(cur); cur = ''; }
        cur = cur ? cur + '\n' + ln : ln;
      });
      if (cur) out.push(cur);
      if (out.length > cap) return out.slice(0, cap).concat(['… (' + (out.length - cap) + ' more part(s) not sent — ask for fewer lines)']);
      return out.length ? out : ['(nothing to send)'];
    }
    // DM delivery that FAILS CLOSED: no openDM, a falsy/failed open, or a target
    // resolving back to the channel => loud reason, transcript NEVER posted
    // in-channel. Never throws.
    function sendDmText(to, text) {
      if (typeof cfg.openDM !== 'function') return Promise.resolve({ ok: false, reason: 'no DM channel available (openDM unavailable)' });
      return Promise.resolve(cfg.openDM(to)).then(function (chId) {
        if (!chId || chId === cfg.channelId) return { ok: false, reason: 'could not open a DM channel' };
        var cuts = chunkDm(text), chain = Promise.resolve(), failed = null;
        cuts.forEach(function (c) {
          chain = chain.then(function () {
            if (failed) return;
            return Promise.resolve(cfg.send(chId, c)).then(function () {}, function (e) { failed = ((e && e.message) || e); });
          });
        });
        return chain.then(function () {
          if (failed) { log('[chloe.save] DM send failed (' + failed + ')'); return { ok: false, reason: 'DM send failed (' + failed + ')' }; }
          log('[chloe.save] transcript DM-sent to ' + to + ' (' + cuts.length + ' part(s))');
          return { ok: true, parts: cuts.length };
        });
      }, function (e) { return { ok: false, reason: 'could not open a DM channel (' + ((e && e.message) || e) + ')' }; });
    }

    // #12: scheduled proactive beats. Interval-based (last_run + intervalMs), heavily activity-gated:
    // never to a dead room, never during lockdown, never while replying/painting, at most one per poll,
    // with a global min gap. A beat is seeded (not fired) the first time it's seen so nothing fires at boot.
    function beatsEnabled() { return Array.isArray(cfg.beats) && cfg.beats.length > 0; }
    function pickBeatText(b) {
      if (b.texts && b.texts.length) return String(b.texts[Math.floor(Math.random() * b.texts.length)]);
      if (b.text) return String(b.text);
      return null;
    }
    function processBeats() {
      if (!beatsEnabled() || engageMode === 'locked' || reply.replying || paint.painting) return Promise.resolve(null);
      if (inProactiveSettle(clock.now())) return Promise.resolve(null);   // don't fire a scheduled beat on the first poll after start
      var now = clock.now();
      return Promise.resolve(store.get(BEATS_KEY)).then(function (state) {
        state = state || {};
        if (state.__lastAny && (now - state.__lastAny) < (cfg.beatMinGapMs || 0)) return null;   // global gap
        return Promise.resolve(store.get(RHYTHM_KEY)).then(function (rh) {
          var lastActivity = rh && rh.lastActivity;
          var fired = null;
          for (var i = 0; i < cfg.beats.length; i++) {
            var b = cfg.beats[i]; if (!b || !b.id || !b.intervalMs) continue;
            if (state[b.id] == null) { state[b.id] = now; continue; }            // seed, don't fire on first sight
            if (now - state[b.id] < b.intervalMs) continue;                       // interval not elapsed
            var win = (b.activeWithinMs != null) ? b.activeWithinMs : (cfg.beatActiveWithinMs || 0);
            if (win > 0 && (lastActivity == null || (now - lastActivity) > win)) continue;   // dead room: skip
            fired = b; break;                                                     // one beat per poll
          }
          if (!fired) return store.set(BEATS_KEY, state).then(function () { return null; });
          return actGate('beats').then(function (gate) {
            if (gate !== 'go') {
              if (gate === 'hold') return holdAct('beats', 'beat "' + fired.id + '" due').then(function () { return null; });
              return null;   // deny (already logged) — schedule untouched, stays due
            }
          state[fired.id] = now; state.__lastAny = now;
          return clearHolds('beats').then(function () {   // the fire supersedes any pending hold
          return store.set(BEATS_KEY, state).then(function () {
            function deliver(text) {
              if (!text || typeof cfg.send !== 'function') return null;
              indicateTyping();
              return Promise.resolve(cfg.send(cfg.channelId, text)).then(function () {
                lastActAt = clock.now();
                log('[chloe.beat] fired "' + fired.id + '"');
                return { beat: fired.id };
              }, function (e) { log('[chloe.beat] send failed for "' + fired.id + '" (' + ((e && e.message) || e) + ') — schedule consumed, retries next interval'); return null; });
            }
            if (fired.prompt && typeof cfg.beatFn === 'function') {
              // v0.57: beats ride the assembler — mood, time, procmode, channel arc all apply now.
              return assembleContext({ authorId: '', authorName: '', content: '' }).then(function (actx) {
                actx.id = fired.id; actx.prompt = fired.prompt;
                return cfg.beatFn(actx);
              }).then(function (res) {
                return deliver((res && res.ok && res.value) ? hygiene(String(res.value)) : pickBeatText(fired));
              }, function (e) { log('[chloe.beat] brain failed for "' + fired.id + '" (' + ((e && e.message) || e) + ') — falling back to canned text'); return deliver(pickBeatText(fired)); });
            }
            return deliver(pickBeatText(fired));
          });
          });
          });   // actGate('beats')
        });
      });
    }

    // Lull filler (Neuro-sama PATIENCE pattern): if the room was recently active and has now gone
    // quiet for `lullPatienceMs`, it may proactively say something to fill the silence. Unlike beats
    // (fixed schedule), this is keyed to actual activity — it fires after a real conversation lulls,
    // not on a clock. Uses the brain (proactive speech needs generation) but is gated hard: only one
    // per lullMinGapMs, only on a real lull, never mid-action, and it respects the global send budget.
    function processLull() {
      if (!cfg.lullFiller || typeof cfg.lullFn !== 'function') return Promise.resolve(null);
      if (engageMode === 'locked' || reply.replying || paint.painting || hasPendingReply()) return Promise.resolve(null);
      if (inProactiveSettle(clock.now())) return Promise.resolve(null);   // don't fill a "lull" that's really just startup
      if (botLoopReplyChance() < 1) return Promise.resolve(null);        // not into a bot-only loop
      if (typeof cfg.canSend === 'function' && !cfg.canSend('text')) return Promise.resolve(null);
      var now = clock.now();
      return Promise.resolve(store.get(RHYTHM_KEY)).then(function (rh) {
        var lastActivity = rh && rh.lastActivity;
        if (lastActivity == null) return null;                                   // never active -> nothing to fill
        var silentFor = now - lastActivity;
        if (silentFor < cfg.lullPatienceMs) return null;                         // not quiet long enough yet
        if (silentFor > cfg.lullActiveWithinMs) return null;                     // dead room, not a lull — leave it
        return Promise.resolve(store.get(LULL_KEY)).then(function (last) {
          if (last && (now - last) < cfg.lullMinGapMs) return null;              // already filled recently
          if (now - lastActAt < cfg.lullMinGapMs) return null;                   // it spoke recently anyway
          return actGate('lull').then(function (gate) {
            if (gate !== 'go') {
              if (gate === 'hold') return holdAct('lull', 'silence filler due').then(function () { return noteLullDiag('held', 'held by policy'); }).then(function () { return null; });
              return noteLullDiag('denied', 'denied by policy').then(function () { return null; });   // deny — schedule untouched, stays due
            }
          reply.replying = true; reply.startedAt = clock.now();
          var lullEpoch = deferGen; var lullStartedAt = now;
          if (typeof cfg.noteSend === 'function') cfg.noteSend('text');
          return assembleContext({ authorId: '', authorName: '', content: '' }).then(function (ctx) {
            ctx.lull = true;   // hint to the brain: the room went quiet, gently re-open it
            return cfg.lullFn(ctx);
          }).then(function (r) {
            var text = (r && r.ok) ? hygiene(String(r.value || '').trim()) : '';
            if (!text) { reply.replying = false; if (typeof cfg.releaseSend === 'function') cfg.releaseSend('text'); return noteLullDiag('nothing', 'brain empty').then(function () { return null; }); }
            // commit-point revalidation: did the room wake up while it was composing?
            return Promise.resolve(store.get(RHYTHM_KEY)).then(function (rh2) {
              if (lullEpoch !== deferGen || (rh2 && rh2.lastActivity > lullStartedAt)) {
                reply.replying = false;
                if (typeof cfg.releaseSend === 'function') cfg.releaseSend('text');
                log('[chloe.abandon] lull filler not sent — ' + (lullEpoch !== deferGen ? 'engine stopped mid-generation' : 'the room woke up on its own (the silence it was filling is over)'));
                return noteLullDiag('nothing', (lullEpoch !== deferGen) ? 'engine stopped' : 'room woke up').then(function () { return null; });
              }
            indicateTyping();
            return Promise.resolve(cfg.send(cfg.channelId, text)).then(function () {
              lastActAt = clock.now(); reply.replying = false; rememberReply(text);
              log('[chloe.lull] filled a ' + Math.round(silentFor / 1000) + 's silence');
              return clearHolds('lull').then(function () { return store.set(LULL_KEY, clock.now()); }).then(function () { return noteLullDiag('fired', ''); }).then(function () { return { lull: text }; });
            }, function (e) { reply.replying = false; log('[chloe.lull] reply send failed, silence not filled (' + ((e && e.message) || e) + ')'); return noteLullDiag('failed', (e && e.message) || e).then(function () { return null; }); });
            });
          }).catch(function (e) { reply.replying = false; log('[chloe.lull] filler failed (' + ((e && e.message) || e) + ')'); if (typeof cfg.releaseSend === 'function') cfg.releaseSend('text'); return noteLullDiag('failed', (e && e.message) || e).then(function () { return null; }); });
          });   // actGate('lull')
        });
      });
    }

    // Favorite-user check-in: scan the roster for someone it's interacted with a lot who's been
    // absent for days, and post a warm "haven't seen you" — @mentioning them (the output gate
    // decides whether that actually pings). Discord-paced: absence in days, throttled per-user (~2wk)
    // and globally (~1/day). Picks the most-missed candidate: highest interaction, longest absent.
    function processCheckin() {
      if (!cfg.checkins || typeof cfg.checkinFn !== 'function') return Promise.resolve(null);
      if (engageMode !== 'normal' || reply.replying || paint.painting || hasPendingReply()) return Promise.resolve(null);
      if (typeof cfg.canSend === 'function' && !cfg.canSend('text')) return Promise.resolve(null);
      if (inProactiveSettle(clock.now())) return Promise.resolve(null);   // observe before pinging an "absent" favorite on startup
      var now = clock.now();
      return Promise.resolve(store.get(CHECKIN_KEY)).then(function (ci) {
        ci = (ci && typeof ci === 'object') ? ci : { __last: 0, byUser: {} };
        if (ci.__last && (now - ci.__last) < cfg.checkinGapMs) return null;     // already checked in recently
        return getRoster().then(function (roster) {
          var best = null, toArchive = [];
          roster.forEach(function (u) {
            if (!u || !u.id) return;
            var noPing = Array.isArray(cfg.checkinBlacklist) ? cfg.checkinBlacklist : [];   // Rule R: never trust the stored shape — a string would substring-match
            if (noPing.indexOf(u.id) >= 0) return;                          // operator blacklist: never proactively ping
            var pinned = Array.isArray(cfg.checkinFavorites) ? cfg.checkinFavorites : [];
            var pinnedFav = pinned.indexOf(u.id) >= 0;
            if (!pinnedFav && (u.interactionCount || 0) < cfg.checkinMinInteractions) return;  // not a favorite
            if (u.state && u.state !== 'active') return;                         // not suppressed/blocked
            var absent = now - (u.lastSeen || 0);
            if (absent < cfg.checkinAbsenceMs) return;                           // not absent long enough
            var rec = (ci.byUser && ci.byUser[u.id]) || null;
            // If they've been seen since the last check-in, that cycle is over — treat as a fresh start.
            var returned = rec && (u.lastSeen || 0) > (rec.seenAt || 0);
            var count = (rec && !returned) ? (rec.count || 0) : 0;
            if (count >= cfg.checkinMaxAttempts) { toArchive.push({ id: u.id, name: u.name }); return; }  // gave up: archive, don't ping
            if (rec && !returned && (now - (rec.at || 0)) < cfg.checkinPerUserGapMs) return;  // cooling down
            // most-missed = most interaction, then longest absent
            var score = (u.interactionCount || 0) * 1e9 + absent;
            if (!best || score > best.score) best = { id: u.id, name: u.name, absent: absent, interactions: u.interactionCount || 0, summary: factSummary(u), seenAt: (u.lastSeen || 0), count: count, score: score };
          });
          // Give up on anyone who's ignored every check-in: move them to historical friends so it
          // stops pinging someone who isn't coming back (life happens), and the hot roster stays lean.
          var archChain = Promise.resolve();
          if (cfg.archiveStale) toArchive.forEach(function (t) { archChain = archChain.then(function () { return archiveUser(t.id, 'checkin-exhausted').then(function () { if (ci.byUser) delete ci.byUser[t.id]; }); }); });
          return archChain.then(function () {
            if (!best) return toArchive.length ? store.set(CHECKIN_KEY, ci).then(function () { return null; }) : null;
            return actGate('checkins').then(function (gate) {
              if (gate !== 'go') {
                if (gate === 'hold') return holdAct('checkins', 'check-in on ' + best.name + ' due').then(function () { return noteCheckinDiag('held', 'held by policy'); }).then(function () { return null; });
                return noteCheckinDiag('denied', 'denied by policy').then(function () { return null; });   // deny — schedule untouched, stays due
              }
            reply.replying = true; reply.startedAt = clock.now();
            if (typeof cfg.noteSend === 'function') cfg.noteSend('text');
            // v0.57: check-ins ride the assembler with the ABSENT FRIEND as the addressed person —
            // its facts, insights, and trust tier arrive via the PERSON band for free.
            var ciEpoch = deferGen; var ciStartedAt = clock.now();
            return assembleContext({ authorId: best.id, authorName: best.name, content: '' }).then(function (actx) {
              actx.name = best.name; actx.absentMs = best.absent; actx.interactions = best.interactions; actx.summary = best.summary;
              return cfg.checkinFn(actx);
            }).then(function (r) {
              var text = (r && r.ok) ? hygiene(String(r.value || '').trim()) : '';
              if (!text) { reply.replying = false; if (typeof cfg.releaseSend === 'function') cfg.releaseSend('text'); return noteCheckinDiag('nothing', 'brain empty').then(function () { return null; }); }
              var body = '<@' + best.id + '> ' + text;   // the mention only actually pings if the gate allows it
              // commit-point revalidation: did they come back while it was composing? A
              // “haven't seen you in a while” landing mid-conversation is the worst kind of stale.
              return Promise.resolve(userStore().get(partKey(best.id))).then(function (pp2) {
                if (ciEpoch !== deferGen || (pp2 && pp2.lastSeen > ciStartedAt)) {
                  reply.replying = false;
                  if (typeof cfg.releaseSend === 'function') cfg.releaseSend('text');
                  log('[chloe.abandon] check-in not sent — ' + (ciEpoch !== deferGen ? 'engine stopped mid-generation' : best.name + ' came back on their own while it was writing it'));
                  return noteCheckinDiag('nothing', (ciEpoch !== deferGen) ? 'engine stopped' : 'came back').then(function () { return null; });   // no attempt counted, no gaps touched — the premise vanished
                }
              indicateTyping();
              return Promise.resolve(cfg.send(cfg.channelId, body)).then(function () {
                lastActAt = clock.now(); reply.replying = false;
                ci.__last = clock.now(); ci.byUser = ci.byUser || {};
                ci.byUser[best.id] = { at: clock.now(), count: best.count + 1, seenAt: best.seenAt };
                log('[chloe.checkin] checked in on ' + best.name + ' (absent ' + Math.round(best.absent / 86400000) + 'd, attempt ' + (best.count + 1) + '/' + cfg.checkinMaxAttempts + ')');
                return clearHolds('checkins').then(function () { return store.set(CHECKIN_KEY, ci); }).then(function () { return noteCheckinDiag('fired', ''); }).then(function () { return { checkin: best.name }; });
              }, function (e) { reply.replying = false; log('[chloe.checkin] send failed, mention not sent (' + ((e && e.message) || e) + ')'); return noteCheckinDiag('failed', (e && e.message) || e).then(function () { return null; }); });
              });
            }).catch(function (e) { reply.replying = false; log('[chloe.checkin] check-in failed (' + ((e && e.message) || e) + ')'); if (typeof cfg.releaseSend === 'function') cfg.releaseSend('text'); return noteCheckinDiag('failed', (e && e.message) || e).then(function () { return null; }); });
            });   // actGate('checkins')
          });
        });
      });
    }

    // A flat, time-ordered recent transcript of the channel (reused by the rolling summary pass).
    function recentTranscript(maxLines) {
      return getRoster().then(function (roster) {
        var now = clock.now();
        roster = roster.filter(function (u) { return !isSuppressed(u, now); });
        var lines = [];
        roster.forEach(function (u) { (u.recent || []).forEach(function (ln) { if (ln && ln.ch && ln.ch !== cfg.channelId) return; lines.push({ who: u.name, text: scrubDiscordTokens(ln.content).slice(0, 240), ts: ln.ts }); }); });   // per-line clip: 40 unclipped 1900-char messages would eat the entire 5000-token request ceiling
        lines.sort(function (a, b) { return a.ts - b.ts; });
        if (lines.length > (maxLines || 40)) lines = lines.slice(-(maxLines || 40));
        return lines.map(function (l) { return l.who + ': ' + l.text; });
      });
    }
    // A bare variant for the rolling rollups (channel summary, episodes): message texts
    // with NO "Name: " prefix. The rollup prompts want the gist, not message-by-message
    // attribution — names in the input echo back as "Alice said… Bob said…" style.
    function recentTranscriptStamped(maxLines) {
      return getRoster().then(function (roster) {
        var now = clock.now();
        roster = roster.filter(function (u) { return !isSuppressed(u, now); });
        var texts = [];
        roster.forEach(function (u) { (u.recent || []).forEach(function (ln) { if (ln && ln.ch && ln.ch !== cfg.channelId) return; texts.push({ text: scrubDiscordTokens(ln.content).slice(0, 240), ts: ln.ts }); }); });
        texts.sort(function (a, b) { return a.ts - b.ts; });
        if (texts.length > (maxLines || 40)) texts = texts.slice(-(maxLines || 40));
        return texts;
      });
    }
    function recentTranscriptTexts(maxLines) {
      return recentTranscriptStamped(maxLines).then(function (stamped) {
        return stamped.map(function (t) { return t.text; });
      });
    }
    // Freshness of the rollup bucket: how many transcript lines are newer than the last
    // summary / episode pass. One roster read + two cheap store gets; the poll chain uses
    // it to load-gate the rollups (empty bucket -> timer doesn't fire; full bucket -> early run).
    // Baseline is max(persisted marker, paceLastAI run stamp): a pass that ran but wrote
    // nothing new (e.g. episodes with zero proposals) still counts as "checked", so it can't
    // re-fire every poll on the same lines. Restart-safe: paceLastAI starts empty, persisted wins.
    function rollupFreshness() {
      return Promise.all([
        Promise.resolve(store.get(CHANSUM_KEY)),
        Promise.resolve(store.get(EPI_KEY)),
        recentTranscriptStamped(40),
        Promise.resolve(store.get(NEWS_KEY)).then(function (ns) { return ns; }, function () { return null; })
      ]).then(function (got) {
        var prev = got[0], ring = Array.isArray(got[1]) ? got[1] : [], stamped = got[2];
        var sumAt = (prev && typeof prev.at === 'number') ? prev.at : 0;
        if (paceLastAI.summary > sumAt) sumAt = paceLastAI.summary;
        var epiAt = 0, i;
        for (i = 0; i < ring.length; i++) { if (ring[i] && typeof ring[i].at === 'number' && ring[i].at > epiAt) epiAt = ring[i].at; }
        if (paceLastAI.episodes > epiAt) epiAt = paceLastAI.episodes;
        var freshSum = 0, freshEpi = 0;
        for (i = 0; i < stamped.length; i++) { if (stamped[i].ts > sumAt) freshSum++; if (stamped[i].ts > epiAt) freshEpi++; }
        // Redirect freshness: a news post newer than the last summary counts as one
        // fresh line for the SUMMARY bucket (episodes are user moments — untouched),
        // so the timer pass that would otherwise stay silent folds the marker in.
        // One rewrite per post max: storing the summary advances sumAt past it.
        var sent = (got[3] && Array.isArray(got[3].sent)) ? got[3].sent : [];
        for (i = 0; i < sent.length; i++) { if (sent[i] && sent[i].at > sumAt) freshSum++; }
        return { sumAt: sumAt, epiAt: epiAt, freshSum: freshSum, freshEpi: freshEpi };
      });
    }
    // Rolling recursive channel summary: fold recent activity into a running ≤W-word summary, feeding
    // the prior summary back in so it accretes the channel's arc rather than restarting. Gated to a
    // cadence (it's an AI call). No send — it's memory, not a message.
    // Redirect target: the latest own 📰 rollup as ONE bracketed line for the rolling
    // summary input, so Thoughts knows a roundup went out without ingesting its body.
    // Full headline text stays out (it already had its channel post); the marker is
    // small enough to ride the chansum provider into replies as one line of summary.
    function newsMarkerLine() {
      return Promise.resolve(store.get(NEWS_KEY)).then(function (ns) {
        var sent = (ns && Array.isArray(ns.sent)) ? ns.sent : [];
        var latest = null;
        sent.forEach(function (s) { if (s && s.at && s.feed && (!latest || s.at > latest.at)) latest = s; });
        if (!latest || (clock.now() - latest.at) >= 604800000) return null;   // ring prunes at 7d; belt-and-suspenders here
        return '[I posted a news roundup from "' + String(latest.feed).slice(0, 60) + '" (' + (latest.count || 0) + ' items)]';
      }, function () { return null; });
    }
    function processChannelSummary() {
      if (!cfg.channelSummary || typeof cfg.summaryFn !== 'function') return Promise.resolve(null);
      return recentTranscriptTexts(40).then(function (lines) {
        return newsMarkerLine().then(function (marker) {
          if (!lines.length && !marker) return null;   // marker-only runs still count (a news post is activity worth one Thought)
          var inLines = marker ? lines.concat([marker]) : lines;
          return Promise.resolve(store.get(CHANSUM_KEY)).then(function (prev) {
            var prior = (prev && typeof prev.text === 'string') ? prev.text : '';
            return Promise.resolve(cfg.summaryFn({ prior: prior, lines: inLines, words: cfg.channelSummaryWords || 60 })).then(function (r) {
              var text = (r && r.ok && typeof r.value === 'string') ? r.value.trim() : '';
              if (!text) return null;
              return store.set(CHANSUM_KEY, { text: text, at: clock.now() }).then(function () { log('[chloe.sum] channel summary updated (' + text.length + ' chars)'); return text; });
            });
          });
        });
      });
    }
    // One live thoughts card per surface: `!chloe thoughts` replies (per source
    // channel) and thoughts-feed posts (per target channel) EDIT in place instead of
    // piling up. Pointer keys persist {id, target, at} in the source bucket, so a
    // restart recovers: a stale pointer (404 on edit/delete) just posts fresh.
    // Crash order is delete-first/post-second only on the no-edit fallback; the edit
    // path never duplicates (same id, idempotent), so interruption strands nothing.
    // Card ops are hygiene like unreact (ungated — they only ever touch the bot's own
    // recorded card ids); the POST itself stays speak-gated via send/sendTo.
    var THOUGHTCARD_CMD = 'thoughtcard:cmd';
    var THOUGHTCARD_FEED = 'thoughtcard:feed';
    function thoughtCardPublish(key, channelId, kind, postFn, editBody) {
      return Promise.resolve(store.get(key)).then(function (ptr) {
        var id = ptr && ptr.id;
        function record(posted) {
          var mid = posted && (posted.id || posted.messageId);
          if (!mid) return posted;   // posted but no id (or gated) — leave pointer; next rotation retries
          var rec = { id: mid, target: channelId, at: clock.now() };
          return Promise.resolve(store.set(key, rec)).then(function () { return posted; }, function () { return posted; });
        }
        function postFresh() {
          // Target switch (feed): the old card lives in the previous target channel.
          var delCh = (ptr && ptr.target && ptr.target !== channelId) ? ptr.target : channelId;
          var del = (id && typeof cfg.deleteMessage === 'function')
            ? Promise.resolve(cfg.deleteMessage(delCh, id)).then(function () { return true; }, function () { return false; })
            : Promise.resolve(false);   // no delete fn (old shell): post-only, pointer still advances
          return del.then(function () { return Promise.resolve(postFn()); }).then(record);
        }
        if (!id) return postFresh();
        if (ptr.target && ptr.target !== channelId) return postFresh();   // switched target: drop the old card, post in the new one
        var editFn = (kind === 'embed') ? cfg.editEmbed : cfg.editMessage;
        if (typeof editFn !== 'function') return postFresh();
        return Promise.resolve(editFn(channelId, id, editBody)).then(function () {
          var rec = { id: id, target: channelId, at: clock.now() };
          return Promise.resolve(store.set(key, rec)).then(function () { return { edited: true, id: id }; }, function () { return { edited: true, id: id }; });
        }, function () { return postFresh(); });   // 404/gone/perm — stale pointer heals by posting fresh
      });
    }
    // F1 thoughts-feed: post a fresh summary to the configured Discord channel
    // (per-source-channel target, lang-vertical mirror). Autonomous output, so
    // policy-gated like beats/lull; the TARGET speak gate is enforced in
    // cfg.sendTo (wiring). Beats-deliver precedent: no voice-budget claim.
    // One live card per target: edited in place, never piled up (see above).
    function postThoughtsFeed(text) {
      var target = cfg.thoughtsFeedTarget ? String(cfg.thoughtsFeedTarget) : '';
      if (!text || !target || typeof cfg.sendTo !== 'function') return Promise.resolve(null);
      if (!/^\d{15,25}$/.test(target)) return Promise.resolve(null);
      return actGate('thoughts').then(function (gate) {
        if (gate === 'hold') return holdAct('thoughts', 'fresh channel summary due').then(function () { return { held: true }; });
        if (gate !== 'go') return { denied: true };   // deny: stays due, panel stays quiet too
        return thoughtCardPublish(THOUGHTCARD_FEED, target, 'text', function () {
          return Promise.resolve(cfg.sendTo(target, text));
        }, text).then(function () {
          log('[chloe.thoughts] posted fresh summary to ' + target);
          return { thoughts: target, feed: target };
        }, function () { return { feed: target }; });
      });
    }
    // Episodic extraction: fold recent activity into 0-2 short episode records. Gated cadence (one
    // AI pass per poll, shared chain). No send — it's memory, not a message.
    // ---- event-graph: cheap edges from fields episodes already carry (no LLM) ----------------
    function jaccard(a, b) {
      a = a || []; b = b || [];
      if (!a.length || !b.length) return 0;
      var setA = {}; a.forEach(function (x) { setA[String(x).toLowerCase()] = true; });
      var inter = 0, seen = {};
      b.forEach(function (x) { var k = String(x).toLowerCase(); if (setA[k] && !seen[k]) { inter++; seen[k] = true; } });
      var unionN = Object.keys(setA).length; b.forEach(function (x) { var k = String(x).toLowerCase(); if (!setA[k]) unionN++; });
      return unionN ? inter / unionN : 0;
    }
    function episodeEdgeWeight(a, b) {
      var wp = jaccard(a.participants, b.participants) * (cfg.episodeLinkWp || 0.5);
      var wt = jaccard(a.topics, b.topics) * (cfg.episodeLinkWt || 0.3);
      var gap = Math.abs((a.at || 0) - (b.at || 0));
      var wd = Math.pow(0.5, gap / (cfg.episodeLinkHalfLifeMs || 21600000)) * (cfg.episodeLinkWd || 0.2);
      return wp + wt + wd;
    }
    // ---- semantic recall + FSRS-lite helpers (DESIGN-semantic) -----------------------------------
    // Unified bounded store (DESIGN-eviction, roadmap #8): keep all PINNED items plus the newest unpinned
    // ones up to `cap`, evicting oldest-unpinned-first and preserving order. Pinned items survive even if
    // they alone exceed the cap. Replaces the scattered slice(-cap) + bespoke operator-fact protection,
    // so the next "protect this from eviction" need is one predicate, not new bespoke code.
    function boundedEvict(items, cap, isPinned) {
      if (!Array.isArray(items) || items.length <= cap) return items;
      isPinned = isPinned || function () { return false; };
      var pinnedCount = 0, i;
      for (i = 0; i < items.length; i++) { if (isPinned(items[i])) pinnedCount++; }
      var room = Math.max(0, cap - pinnedCount), kept = 0, keepFlag = new Array(items.length);
      for (i = items.length - 1; i >= 0; i--) {          // walk newest -> oldest
        if (isPinned(items[i])) keepFlag[i] = true;      // pinned always survives
        else if (kept < room) { keepFlag[i] = true; kept++; }
        else keepFlag[i] = false;
      }
      return items.filter(function (_, idx) { return keepFlag[idx]; });
    }
    function cosine(a, b) {
      if (!a || !b || a.length !== b.length) return 0;
      var dot = 0, na = 0, nb = 0;
      for (var i = 0; i < a.length; i++) { var x = a[i], y = b[i]; dot += x * y; na += x * x; nb += y * y; }
      if (na <= 0 || nb <= 0) return 0;
      return dot / (Math.sqrt(na) * Math.sqrt(nb));
    }
    // FSRS power forgetting curve (FSRS-4.5/5): R(t) = (1 + FACTOR·t/S)^DECAY, with the constants chosen
    // so R(S) = 0.9 — i.e. stability S is the elapsed time at which retrievability has fallen to 90%.
    var FSRS_DECAY = -0.5, FSRS_FACTOR = 0.2345679012345679;   // = 0.9^(1/DECAY) - 1
    function fsrsRetrievability(stabDays, ageMs) {
      var t = Math.max(0, ageMs || 0) / 86400000;
      var S = Math.max(0.1, stabDays || (cfg.fsrsInitialStability || 4));
      return Math.pow(1 + FSRS_FACTOR * t / S, FSRS_DECAY);
    }
    // On recall, stability grows (the spacing effect) so a revisited memory decays slower next time.
    function fsrsStrengthen(stabDays) {
      var base = stabDays || (cfg.fsrsInitialStability || 4);
      return Math.min(cfg.fsrsMaxStability || 365, base * (cfg.fsrsRecallGrowth || 1.9));
    }
    // Embed a batch of texts via the page broker; resolves to null if unavailable (keyword fallback).
    function embedTexts(texts) {
      if (!cfg.semanticRecall || typeof cfg.embedFn !== 'function' || !texts || !texts.length) return Promise.resolve(null);
      return Promise.resolve(cfg.embedFn(texts)).then(function (vecs) {
        return (Array.isArray(vecs) && vecs.length === texts.length) ? vecs : null;
      }, function () { return null; });   // a failed embed is a no-op -> keyword path
    }
    var episodeSeq = 0;
    function mintEpisodeId() { episodeSeq++; return 'e' + clock.now().toString(36) + episodeSeq.toString(36); }
    // Link a freshly-added episode to its single strongest existing neighbor (mutual: upgrade the
    // neighbor's link too if this new edge beats its current one). Sparse: only above the floor.
    function linkEpisode(ring, fresh) {
      if (!cfg.episodeGraph) return;
      var floor = cfg.episodeLinkFloor || 0.15;
      var best = null, bestW = floor;
      ring.forEach(function (other) {
        if (other === fresh || !other.id) return;
        var w = episodeEdgeWeight(fresh, other);
        if (w > bestW) { bestW = w; best = other; }
        // mutual upgrade: does THIS edge beat the neighbor's current best?
        if (w >= floor && (!other.relatesTo || w > other.relatesTo.weight)) other.relatesTo = { id: fresh.id, weight: w };
      });
      fresh.relatesTo = best ? { id: best.id, weight: bestW } : null;
    }

    // ---- user-facing episodic search (SPEC-agents `recall`, shipped v46) ----
    // Tokenization is the single shared helper: the episodes RECALL provider
    // below delegates its local toks() to this, and !recall scores through it,
    // so the two paths can never drift apart (DESIGN §7a: lowercase,
    // punctuation-stripped, tokens >= 3 chars, exact overlap).
    function episodeQueryTokens(s) {
      return String(s || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(function (w) { return w.length >= 3; });
    }
    // Keyword scoring for an explicit query: overlap (must be >0) x importance
    // x decay. Mirrors the provider's keyword-fallback branch exactly: rel is
    // normalized by query size in semantic mode (so it mixes with FSRS R) and
    // raw overlap otherwise; decay is FSRS retrievability when the record
    // carries stability, else the half-life curve. Read-only: never persists.
    function scoreEpisodesForQuery(queryText, ring, now) {
      var qset = {}, qsize = 0;
      episodeQueryTokens(queryText).forEach(function (w) { if (!qset[w]) { qset[w] = true; qsize++; } });
      if (!qsize) return [];
      var semantic = !!cfg.semanticRecall, half = cfg.episodeRecencyHalfLifeMs || 604800000;
      var scored = [];
      (Array.isArray(ring) ? ring : []).forEach(function (e) {
        if (!e || typeof e.text !== 'string') return;
        var eset = {};
        (e.topics || []).forEach(function (t) { episodeQueryTokens(t).forEach(function (w) { eset[w] = true; }); });
        episodeQueryTokens(e.text).forEach(function (w) { eset[w] = true; });
        var overlap = 0;
        Object.keys(eset).forEach(function (w) { if (qset[w]) overlap++; });
        if (!overlap) return;
        var rel = semantic ? (overlap / Math.max(1, qsize)) : overlap;
        var decay;
        if (semantic && e.stab != null) decay = fsrsRetrievability(e.stab, now - (e.lastRecallAt || e.at || 0));
        else decay = Math.pow(0.5, Math.max(0, now - (e.at || 0)) / half);
        scored.push({ e: e, score: rel * (e.importance || 5) * decay });
      });
      scored.sort(function (a, b) { return b.score - a.score; });
      return scored;
    }
    // Explicit recall query: top-3 matches + the top hit's one-hop neighbor.
    // Read-only on purpose (unlike the provider, which strengthens surfaced
    // memories): a query must never rewrite memory.
    function searchEpisodes(queryText) {
      var q = String(queryText || '').trim().slice(0, 300);
      if (!q) return Promise.resolve({ ok: false, reason: 'empty' });
      return Promise.resolve(store.get(EPI_KEY)).then(function (ring) {
        ring = Array.isArray(ring) ? ring : [];
        if (!ring.length) return { ok: false, reason: 'empty' };
        var now = clock.now();
        var scored = scoreEpisodesForQuery(q, ring, now);
        if (!scored.length) return { ok: false, reason: 'no-match', total: ring.length };
        var top = scored.slice(0, 3);
        var pickedIds = {};
        top.forEach(function (x) { if (x.e.id) pickedIds[x.e.id] = true; });
        var hop = null;
        if (cfg.episodeGraph && top.length && top[0].e.relatesTo && top[0].e.relatesTo.id) {
          var nb = ring.filter(function (e2) { return e2.id === top[0].e.relatesTo.id; })[0];
          if (nb && !pickedIds[nb.id]) hop = nb.text;
        }
        return { ok: true, total: ring.length,
          matches: top.map(function (x) { return { text: x.e.text, at: x.e.at, participants: x.e.participants || [], topics: x.e.topics || [], importance: x.e.importance || 5, score: x.score }; }),
          hop: hop };
      });
    }
    function processEpisodes() {
      if (!cfg.episodicMemory || typeof cfg.episodeFn !== 'function') return Promise.resolve(null);
      return recentTranscriptTexts(40).then(function (lines) {
        if (!lines.length) return null;
        return Promise.resolve(store.get(EPI_KEY)).then(function (ring) {
          ring = Array.isArray(ring) ? ring : [];
          var known = ring.slice(-6).map(function (e) { return e.text; });
          return Promise.resolve(cfg.episodeFn({ lines: lines, known: known })).then(function (r) {
            var proposed = (r && r.ok && Array.isArray(r.value)) ? r.value : [];
            if (!proposed.length) return null;
            var added = 0;
            var fresh = [];
            proposed.forEach(function (raw) {
              if (!raw || typeof raw !== 'object' || typeof raw.t !== 'string' || !raw.t.trim()) return;
              var ep = { id: mintEpisodeId(), text: raw.t.trim().slice(0, 120), at: clock.now(),
                          participants: Array.isArray(raw.who) ? raw.who.map(function (w) { return String(w).slice(0, 40); }).slice(0, 6) : [],
                          topics: Array.isArray(raw.topics) ? raw.topics.map(function (t) { return String(t).toLowerCase().slice(0, 24); }).slice(0, 6) : [],
                          importance: Math.max(1, Math.min(10, Math.round(Number(raw.i)) || 5)), relatesTo: null };
              if (cfg.semanticRecall) { ep.stab = cfg.fsrsInitialStability || 4; ep.lastRecallAt = ep.at; }   // FSRS-lite seed
              ring.push(ep);
              linkEpisode(ring, ep);   // cheap edge to its strongest existing neighbor (no LLM)
              fresh.push(ep);
              added++;
            });
            if (!added) return null;
            ring = boundedEvict(ring, cfg.episodesPerChannel);
            // semantic recall: embed the new episodes once, at creation (cached on the record). If the
            // embedder isn't available this is a no-op and recall falls back to keyword overlap.
            return embedTexts(fresh.map(function (e) { return e.text + ' ' + (e.topics || []).join(' '); })).then(function (vecs) {
              if (vecs) fresh.forEach(function (e, i) { if (Array.isArray(vecs[i])) e.vec = vecs[i]; });
              return store.set(EPI_KEY, ring).then(function () { log('[chloe.epi] recorded ' + added + ' episode(s)' + (vecs ? ' (embedded)' : '')); return added; });
            });
          });
        });
      });
    }
    // Erasure: forget/purge must cover episodes the person took part in (participant name match).
    function dropEpisodesFor(id, name) {
      var m = String(name || '').toLowerCase();
      if (!m) return Promise.resolve(0);
      return Promise.resolve(store.get(EPI_KEY)).then(function (ring) {
        if (!Array.isArray(ring) || !ring.length) return 0;
        var before = ring.length;
        ring = ring.filter(function (e) {
          return !(e.participants || []).some(function (w) { return String(w).toLowerCase() === m; });
        });
        var removed = before - ring.length;
        if (!removed) return 0;
        return store.set(EPI_KEY, ring).then(function () { log('[chloe.epi] erased ' + removed + ' episode(s) for ' + name); return removed; });
      });
    }

    // ---- F2 news sitemap rollups -------------------------------------------------
    // Hourly-per-feed rollups from news sitemaps (discovered via robots.txt),
    // posted to the feed's target channel (the engine whose channelId matches).
    // Deterministic when the voice prompt is cleared: no AI pass consumed. Pure helpers (no store/clock) so they
    // stay headless-testable; only processNews touches the network + store.
    // VOICE (user-editable, panel Setup -> News voice): newsPrompt (undefined/null = default
    // AI voice below; '' = classic deterministic list; other = custom instruction with
    // {feed} {date} {items} placeholders) + newsPostTemplate (null = default template below).
    // AI path fail-opens to the classic list; the Links gate still strips URLs at send time.
    // Per-story voice: the default prompt covers ONE headline per AI call (more
    // room per story than a whole-batch prompt). The URL is detached — the model
    // never sees or copies it; the engine re-attaches it at pack time.
    var DEFAULT_NEWS_PROMPT =
      'You post a short news blurb for the "{feed}" feed in a chat channel, in your own voice.\n' +
      'One fresh headline ({date}):\n{item}\n\n' +
      'Say why it is worth knowing in one or two sentences — concrete, no press-release filler. ' +
      'Do NOT include any link or URL (it is attached separately) — never guess or reconstruct one from the headline either. ' +
      'Respond with ONLY the blurb text, at most 400 characters, no preamble.';
    var DEFAULT_NEWS_TEMPLATE = '📰 {feed} — {date}\n{body}';
    var DEFAULT_PODCAST_PROMPT =
      'You post a short blurb for a new episode of the "{feed}" podcast in a chat channel, in your own voice.\n' +
      'One fresh episode ({date}, {cadence}):\n{item}\n\n' +
      'Say why it is worth a listen in one or two sentences — concrete, no press-release filler. ' +
      'Do NOT include any link or URL (it is attached separately) — never guess or reconstruct one from the episode title either. ' +
      'Respond with ONLY the blurb text, at most 400 characters, no preamble.';
    var DEFAULT_PODCAST_TEMPLATE = '🎙️ {feed} — {date}\n{body}';
    var NEWS_PROMPT_MAX = 2000, NEWS_TEMPLATE_MAX = 500;
    var NEWS_KIND_NEWS = 'news', NEWS_KIND_POD = 'podcast';
    var NEWS_DEFAULT_EVERY = 3600000, NEWS_POD_DEFAULT_EVERY = 43200000;   // new-draft cadence per kind (panel mirrors)
    var NEWS_ITEM_MAX = 450;   // per-story blurb cap (the prompt asks for <=400)
    var NEWS_POST_MAX = 1900;  // hard post cap: Discord allows 2000, the send path slices at 1900
   var NEWS_KEY = 'news:' + cfg.channelId;   // { byFeed: { id: { lastRun, seen: [urls] } } }
    // Double-post guard: a news run (fetch chain + AI compose + post) can outlast
    // the 45s run-lock and a queen handover, so a second engine — or a second
    // `news now` — can fetch the same fresh items before the first run marks them
    // seen, and both post. Claim a per-channel in-flight marker BEFORE the first
    // fetch; concurrent runs see it and stand down. The claim heartbeats per feed
    // (so only a single feed's worst case must fit the TTL); a stale claim (e.g.
    // a crashed run) is taken over, never blocking forever.
    var NEWSRUN_KEY = 'news:run:' + cfg.channelId, NEWSRUN_TTL = 300000;
    var newsRunLocal = false;   // in-process re-entry guard (same tick, two dispatches)
    function newsClaimRun() {
      if (newsRunLocal) return Promise.resolve(false);
      newsRunLocal = true;   // synchronously: a same-tick second caller sees it before any await resolves
      var now = clock.now();
      return Promise.resolve(store.get(NEWSRUN_KEY)).then(function (c) {
        if (c && c.id && c.id !== runId && (now - (c.at || 0)) < NEWSRUN_TTL) { newsRunLocal = false; return false; }   // a live run elsewhere owns this channel
        return Promise.resolve(store.set(NEWSRUN_KEY, { id: runId, at: now })).then(function () { return true; }, function () { return true; });   // a dropped claim write (goldfish) must not block the run
      }, function () { return true; });
    }
    function newsHeartbeat() {
      if (!newsRunLocal) return Promise.resolve(false);
      return Promise.resolve(store.set(NEWSRUN_KEY, { id: runId, at: clock.now() })).then(function () { return true; }, function () { return false; });
    }
    function newsReleaseRun() {
      newsRunLocal = false;
      return Promise.resolve(store.get(NEWSRUN_KEY)).then(function (c) {
        if (c && c.id === runId) return Promise.resolve(store.del(NEWSRUN_KEY)).then(function () {}, function () {});
      }, function () {});
    }
    var NEWS_NAMED_ENTS = { nbsp: ' ', amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", hellip: '…', mdash: '—', ndash: '–', laquo: '«', raquo: '»', lsquo: '‘', rsquo: '’', ldquo: '“', rdquo: '”', copy: '©', reg: '®', trade: '™', deg: '°', agrave: 'à', aacute: 'á', acirc: 'â', atilde: 'ã', auml: 'ä', aring: 'å', ccedil: 'ç', egrave: 'è', eacute: 'é', ecirc: 'ê', euml: 'ë', igrave: 'ì', iacute: 'í', icirc: 'î', iuml: 'ï', ntilde: 'ñ', ograve: 'ò', oacute: 'ó', ocirc: 'ô', otilde: 'õ', ouml: 'ö', ugrave: 'ù', uacute: 'ú', ucirc: 'û', uuml: 'ü', yacute: 'ý', yuml: 'ÿ' };
    function newsUnescape(s) {
      return String(s || '').replace(/&(#\d+|#x[0-9a-fA-F]+|[a-zA-Z]+);/g, function (m, code) {
        if (code.charAt(0) === '#') {
          var n = (code.charAt(1).toLowerCase() === 'x') ? parseInt(code.slice(2), 16) : parseInt(code.slice(1), 10);
          if (isFinite(n) && n > 0 && n < 1114112) { try { return (typeof String.fromCodePoint === 'function') ? String.fromCodePoint(n) : String.fromCharCode(n); } catch (e) {} }
          return m;
        }
        var k = code.toLowerCase();
        return (k in NEWS_NAMED_ENTS) ? NEWS_NAMED_ENTS[k] : m;
      });
    }
    // robots.txt -> sitemap urls (Sitemap: lines; comments/blank lines skipped).
    function newsParseRobots(text) {
      var out = [];
      String(text || '').split(/\r?\n/).forEach(function (ln) {
        var m = ln.match(/^\s*Sitemap\s*:\s*(\S+)\s*$/i);
        if (m) out.push(m[1].trim());
      });
      return out;
    }
    // Prefer a news-flavored sitemap; .gz only as a last resort (no gunzip here).
    function newsPickSitemap(urls) {
      urls = (Array.isArray(urls) ? urls : []).filter(function (u) { return /^https?:\/\//i.test(u || ''); });
      if (!urls.length) return null;
      var plain = urls.filter(function (u) { return !/\.gz(\?|$)/i.test(u); });
      var pool = plain.length ? plain : urls;
      function score(u) {
        var s = String(u).toLowerCase();
        if (/google-?news|news-?today|sitemap-news|news\.xml|news_sitemap/.test(s)) return 3;
        if (/news/.test(s)) return 2;
        if (/article/.test(s)) return 1;
        return 0;
      }
      pool.sort(function (a, b) { return score(b) - score(a); });
      return pool[0];
    }
    // Sitemap XML -> [{url, title, date, keywords[]}]. Google News tags first,
    // plain urlset (loc + lastmod) as fallback. Caps scan at ~200 url blocks.
    function newsParseItems(xml) {
      var items = [];
      var blocks = String(xml || '').match(/<url[\s>][\s\S]*?<\/url\s*>/gi) || [];
      blocks = blocks.slice(0, 200);
      blocks.forEach(function (b) {
        var loc = (b.match(/<loc\s*>([\s\S]*?)<\/loc\s*>/i) || [])[1];
        if (!loc) return;
        var url = newsUnescape(loc).trim();
        if (!/^https?:\/\//i.test(url)) return;
        var title = newsUnescape(((b.match(/<news:title\s*>([\s\S]*?)<\/news:title\s*>/i) || [])[1] || '')).trim().slice(0, 160);
        var date = (((b.match(/<news:publication_date\s*>([\s\S]*?)<\/news:publication_date\s*>/i) || [])[1] || '').trim() ||
                    ((b.match(/<lastmod\s*>([\s\S]*?)<\/lastmod\s*>/i) || [])[1] || '').trim()).slice(0, 30);
        var kwRaw = ((b.match(/<news:keywords\s*>([\s\S]*?)<\/news:keywords\s*>/i) || [])[1] || '');
        var keywords = newsUnescape(kwRaw).split(',').map(function (k) { return k.trim().toLowerCase(); }).filter(Boolean).slice(0, 12);
        items.push({ url: url.slice(0, 500), title: title, date: date, keywords: keywords });
      });
      return items;
    }
    // Direct-feed XML -> [{url, title, date, keywords: []}]. RSS 2.0 <item>
    // (title/link/pubDate, guid as a URL fallback) + Atom <entry> (title,
    // <link href>, updated/published). Same shape as newsParseItems, minus
    // keywords (feeds rarely carry them; the filter falls back to URL path).
    // CDATA unwrapped per field, entities unescaped, non-http(s) skipped.
    function newsFieldText(b, tag) {
      var m = null;
      try { m = b.match(new RegExp('<' + tag + '[^>]*>([\\s\\S]*?)<\\/' + tag + '\\s*>', 'i')); } catch (e) { m = null; }
      var inner = (m && m[1]) || '';
      inner = String(inner).replace(/<!\[CDATA\[([\s\S]*?)\]\]>/gi, '$1');
      return newsUnescape(inner).trim();
    }
    function newsKindOf(feed) { return (feed && feed.kind === NEWS_KIND_POD) ? NEWS_KIND_POD : NEWS_KIND_NEWS; }
    function newsKindEmoji(kind) { return (kind === NEWS_KIND_POD) ? '🎙️' : '📰'; }
    function newsKindLabel(kind) { return (kind === NEWS_KIND_POD) ? 'podcast' : 'news'; }
    // Human cadence for the {cadence} prompt slot + Discord lines ("every 30 minutes").
    function newsCadence(ms) {
      var v = Number(ms) || NEWS_DEFAULT_EVERY;
      var mins = Math.round(v / 60000);
      if (mins < 60) return 'every ' + mins + ' minute' + (mins === 1 ? '' : 's');
      var hrs = mins / 60;
      if (hrs < 48) { var h = Math.round(hrs * 2) / 2; return 'every ' + h + ' hour' + (h === 1 ? '' : 's'); }
      var d = Math.round(hrs / 24); return 'every ' + d + ' day' + (d === 1 ? '' : 's');
    }
    function newsParseFeedItems(xml) {
      var items = [];
      var blocks = String(xml || '').match(/<(item|entry)[\s>][\s\S]*?<\/\1\s*>/gi) || [];
      blocks = blocks.slice(0, 200);
      blocks.forEach(function (b) {
        var url = '';
        var hrefs = [];
        var hre = /<link[^>]*href\s*=\s*["']([^"']+)["']/gi, hm;
        while ((hm = hre.exec(b)) && hrefs.length < 10) hrefs.push(newsUnescape(hm[1]).trim());
        var bare = newsFieldText(b, 'link');
        if (bare) hrefs.push(bare);
        var guid = newsFieldText(b, 'guid');
        for (var i = 0; i < hrefs.length; i++) { if (/^https?:\/\//i.test(hrefs[i])) { url = hrefs[i]; break; } }
        if (!url && /^https?:\/\//i.test(guid)) url = guid;
        if (!url) return;
        var title = newsFieldText(b, 'title').replace(/\s+/g, ' ').slice(0, 160);
        var date = (newsFieldText(b, 'pubDate') || newsFieldText(b, 'updated') || newsFieldText(b, 'published')).slice(0, 30);
        // Podcast extras: enclosure audio URL + duration + show-notes snippet.
        var audio = '';
        try {
          var encRe = /<enclosure[^>]*>/gi, em, cands = [];
          while ((em = encRe.exec(b)) && cands.length < 10) {
            var eu = (em[0].match(/url\s*=\s*["']([^"']+)["']/i) || [])[1] || '';
            var et = (em[0].match(/type\s*=\s*["']([^"']+)["']/i) || [])[1] || '';
            eu = newsUnescape(eu).trim();
            if (/^https?:\/\//i.test(eu)) cands.push({ url: eu.slice(0, 500), audio: /audio\//i.test(et) || /\.(mp3|m4a|ogg|opus|wav|mp4)(\?|#|$)/i.test(eu) });
          }
          if (cands.length) {
            var aud = null;
            for (var ai = 0; ai < cands.length; ai++) { if (cands[ai].audio) { aud = cands[ai]; break; } }
            audio = (aud || cands[0]).url;
          }
        } catch (e) {}
        if (!audio) {
          for (var li = 0; li < hrefs.length; li++) { if (/\.(mp3|m4a|ogg|opus|wav|mp4)(\?|#|$)/i.test(hrefs[li])) { audio = hrefs[li].slice(0, 500); break; } }
        }
        var duration = '';
        try { duration = (newsFieldText(b, 'itunes:duration') || newsFieldText(b, 'duration')).replace(/\s+/g, ' ').slice(0, 20); } catch (e) {}
        var desc = '';
        try {
          desc = newsFieldText(b, 'description') || newsFieldText(b, 'content:encoded') || newsFieldText(b, 'itunes:summary') || newsFieldText(b, 'itunes:subtitle') || newsFieldText(b, 'summary');
          desc = String(desc).replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 300);
        } catch (e) {}
        items.push({ url: url.slice(0, 500), title: title, date: date, keywords: [], audio: audio, duration: duration, desc: desc });
      });
      return items;
    }
    // Drop seen urls, ban-word hits (title+url), category misses. Case-insensitive
    // substring; categories match keywords + url path segments.
    function newsFilterItems(items, opts) {
      opts = opts || {};
      var seen = {};
      (opts.seen || []).forEach(function (u) { seen[String(u)] = true; });
      var bans = (opts.banWords || []).map(function (w) { return String(w).toLowerCase(); }).filter(Boolean);
      var allow = (opts.allowCats || []).map(function (w) { return String(w).toLowerCase(); }).filter(Boolean);
      var block = (opts.blockCats || []).map(function (w) { return String(w).toLowerCase(); }).filter(Boolean);
      return (Array.isArray(items) ? items : []).filter(function (it) {
        if (!it || !it.url || seen[it.url]) return false;
        var hay = ((it.title || '') + ' ' + it.url + ' ' + (it.desc || '')).toLowerCase();
        for (var i = 0; i < bans.length; i++) { if (bans[i] && hay.indexOf(bans[i]) >= 0) return false; }
        if (allow.length || block.length) {
          var path = '';
          try { path = String(it.url.match(/^https?:\/\/[^\/]+\/(.*)$/i)[1] || '').replace(/[\/_-]+/g, ' ').toLowerCase(); } catch (e) {}
          var cathay = (it.keywords || []).join(' ') + ' ' + path;
          for (var j = 0; j < block.length; j++) { if (block[j] && cathay.indexOf(block[j]) >= 0) return false; }
          if (allow.length) {
            var hit = false;
            for (var k = 0; k < allow.length; k++) { if (allow[k] && cathay.indexOf(allow[k]) >= 0) { hit = true; break; } }
            if (!hit) return false;
          }
        }
        return true;
      });
    }
    function newsFormatRollup(name, items, max) {
      items = (Array.isArray(items) ? items : []).slice(0, Math.max(1, Math.min(10, max || 5)));
      if (!items.length) return '';
      var day = '';
      try { day = new Date().toISOString().slice(0, 10); } catch (e) {}
      var lines = ['📰 ' + String(name || 'news').slice(0, 60) + (day ? ' — ' + day : '')];
      items.forEach(function (it) {
        lines.push('• ' + (it.title || it.url).slice(0, 140));
        lines.push(it.url);
      });
      return lines.join('\n').slice(0, 1900);
    }
    // Classic deterministic body: bullet lines, no header (the header lives in
    // the post template). Refactored out of newsFormatRollup; byte-identical lines.
    function newsClassicBody(items, max, kind) {
      items = (Array.isArray(items) ? items : []).slice(0, Math.max(1, Math.min(10, max || 5)));
      if (!items.length) return '';
      var lines = [];
      items.forEach(function (it) {
        lines.push('• ' + (it.title || it.url).slice(0, 140));
        lines.push(it.url);
        if (kind === NEWS_KIND_POD && it && it.audio && it.audio !== it.url) lines.push(it.audio);
      });
      return lines.join('\n');
    }
    function newsToday() {
      try { return new Date().toISOString().slice(0, 10); } catch (e) { return ''; }
    }
    // Post template: {feed} {date} {count} {body} replaced; a template without
    // {body} gets the body appended (never silently dropped).
    function newsApplyTemplate(tpl, parts) {
      parts = parts || {};
      var body = String(parts.body || '');
      var t = (tpl == null) ? DEFAULT_NEWS_TEMPLATE : String(tpl);
      var out = t.split('{feed}').join(String(parts.feed || 'news').slice(0, 60))
                 .split('{date}').join(String(parts.date || ''))
                 .split('{count}').join(String(parts.count == null ? '' : parts.count));
      if (out.indexOf('{body}') < 0) return (out + '\n' + body).slice(0, 1900);
      return out.split('{body}').join(body).slice(0, 1900);
    }
    function newsResolveItemPrompt(feed) {
      var kind = newsKindOf(feed);
      if (kind === NEWS_KIND_POD) {
        if (cfg.newsPodcastPrompt === '') return '';   // cleared: classic list, no AI
        var pp = (cfg.newsPodcastPrompt == null) ? DEFAULT_PODCAST_PROMPT : String(cfg.newsPodcastPrompt);
        return pp.trim() ? pp : '';
      }
      if (cfg.newsPrompt === '') return '';   // cleared: classic list, no AI
      var p = (cfg.newsPrompt == null) ? DEFAULT_NEWS_PROMPT : String(cfg.newsPrompt);
      return p.trim() ? p : '';
    }
    function newsResolveTemplate(feed) {
      if (cfg.newsPostTemplate != null) return String(cfg.newsPostTemplate);
      return (newsKindOf(feed) === NEWS_KIND_POD) ? DEFAULT_PODCAST_TEMPLATE : DEFAULT_NEWS_TEMPLATE;
    }
    // AI-context hygiene: the model must never see a URL it can copy or
    // rebuild. newsStripUrls removes bare/www/markdown links, newsDeSlug
    // turns slug-like fragments (underscores, dash-packed paths) into plain
    // words, and newsSubtitle picks a title — or, when the title is missing,
    // a de-slugged tail of the URL path — so the context is words only.
    function newsStripUrls(s) {
      var t = String(s || '');
      t = t.replace(/\[([^\]]*)\]\([^)]*\)/g, '$1');
      t = t.replace(/<https?:\/\/[^>\s]+>/gi, ' ');
      t = t.replace(/https?:\/\/[^\s)'"<>]+/gi, ' ');
      t = t.replace(/(^|[\s(>"'])www\.[^\s)'"<>]+/gi, '$1 ');
      return t;
    }
    function newsDeSlug(s) {
      var t = newsStripUrls(s).replace(/[_–—-]+/g, ' ');
      return t.replace(/\s+/g, ' ').trim();
    }
    function newsSlugTail(url) {
      try {
        var path = String(String(url || '').match(/^https?:\/\/[^\/]+(.*)$/i)[1] || '');
        var segs = path.split('/').filter(function (x) { return !!x; });
        var tail = segs.length ? segs[segs.length - 1] : '';
        tail = tail.split(/[?#]/)[0].replace(/\.(html?|php|aspx?|xml|rss)$/i, '');
        try { tail = decodeURIComponent(tail); } catch (e) {}
        return tail.replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim();
      } catch (e) { return ''; }
    }
    function newsSubtitle(it) {
      var title = String((it && it.title) || '').trim();
      var words = title ? newsDeSlug(title) : newsSlugTail((it && it.url) || '');
      return (words || 'untitled story').slice(0, 140);
    }
    // Post-compose hygiene: strip any link the model emitted anyway (copied
    // or reconstructed from a sluggy headline) so the engine-attached
    // canonical links underneath stay the ONLY links — no doubles in
    // Discord. Markdown links collapse to their words; a blurb that is
    // nothing but a link resolves empty and fails open to classic below.
    function newsCleanBlurb(t) {
      var s = String(t || '');
      s = s.replace(/\[([^\]]*)\]\([^)]*\)/g, '$1');
      s = s.replace(/<https?:\/\/[^>\s]+>/gi, '');
      s = s.replace(/https?:\/\/[^\s)'"<>]+/gi, '');
      s = s.replace(/(^|[\s(>"'])www\.[^\s)'"<>]+/gi, '$1');
      s = s.split('\n').map(function (ln) {
        return ln.replace(/[ \t]+/g, ' ').trim().replace(/\(\s*\)/g, '').replace(/\[\s*\]/g, '').trim();
      }).join('\n');
      return s.replace(/\n{3,}/g, '\n\n').trim();
    }
    // One story's line for the AI context (subtitle words only — the URL stays
    // detached; underscores/dashes are de-slugged so the model can't rebuild
    // a link from them). Podcasts add the episode length + a link-free
    // show-notes snippet for room to riff.
    function newsItemLine(it, kind) {
      var base = '- ' + newsSubtitle(it);
      if (kind === NEWS_KIND_POD && it) {
        var extra = '';
        if (it.duration) extra += ' (' + String(it.duration).slice(0, 20) + ')';
        if (it.desc) {
          var d = newsDeSlug(it.desc).slice(0, 140);
          if (d) extra += ' — ' + d;
        }
        if (extra) base = (base + extra).slice(0, 280);
      }
      return base;
    }
    // Greedy pack of per-story blocks into the template's remaining room. The
    // overhead is measured by rendering the template with an empty body and the
    // widest count (10), so a packed post never exceeds NEWS_POST_MAX. Returns
    // {body, posted} — overflow stories are left OUT (they stay unseen and come
    // back next run) instead of being silently sliced off the end, which is
    // where the old whole-post slice used to kill trailing URLs.
    function newsPackPost(tpl, parts, blocks) {
      var probe = newsApplyTemplate(tpl, { feed: parts.feed, date: parts.date, count: 10, body: '' });
      var room = NEWS_POST_MAX - probe.length;
      var kept = [];
      blocks.forEach(function (b) {
        var need = String(b.block || '').length + (kept.length ? 2 : 0);
        if (need <= room) { kept.push(b); room -= need; }
      });
      return { body: kept.map(function (b) { return b.block; }).join('\n\n'), posted: kept.map(function (b) { return b.it; }) };
    }
    // Full post text: template wrapped around the classic body or the per-story
    // AI voice. Resolves {text, posted} — posted is the subset that fit (seen
    // marks only those). AI fail-opens to classic (missing newsFn, failure, or
    // empty text), per story and as a whole.
    function newsComposeText(feed, items, max, dateOverride, tplOverride) {
      var name = (feed && (feed.name || feed.id)) || 'news';
      var kind = newsKindOf(feed);
      var n = Math.max(1, Math.min(10, (feed && feed.maxItems) || max || 5));
      var list = (Array.isArray(items) ? items : []).slice(0, n);
      var day = dateOverride || newsToday();
      var tpl = (tplOverride === undefined) ? newsResolveTemplate(feed) : tplOverride;
      var prompt = newsResolveItemPrompt(feed);
      var cadence = newsCadence(feed && feed.intervalMs);
      function classic() {
        return { text: newsApplyTemplate(tpl, { feed: name, date: day, count: list.length, body: newsClassicBody(list, n, kind) }), posted: list.slice() };
      }
      if (!prompt || !list.length || typeof cfg.newsFn !== 'function') return Promise.resolve(classic());
      // Per-story voice: one AI pass per headline (more room per story), URLs
      // detached (the model never sees or copies them) and re-attached at pack.
      // Podcasts re-attach the audio enclosure too (second link line).
      var blurbs = [];
      var chain = Promise.resolve();
      function newsBlockLinks(it) {
        var url = String((it && it.url) || '');
        var audio = String((it && it.audio) || '');
        return url + ((audio && audio !== url) ? '\n' + audio : '');
      }
      list.forEach(function (it) {
        chain = chain.then(function () {
          return Promise.resolve(cfg.newsFn({ feed: name, date: day, kind: kind, cadence: cadence,
            item: { title: String((it && it.title) || (it && it.url) || '').slice(0, 160), duration: String((it && it.duration) || ''), audio: String((it && it.audio) || ''), desc: String((it && it.desc) || '').slice(0, 300) },
            items: [it], itemText: newsItemLine(it, kind), prompt: prompt,
            duration: String((it && it.duration) || ''), audio: String((it && it.audio) || ''), desc: String((it && it.desc) || '').slice(0, 300) })).then(function (r) {
            var t = (r && r.ok && typeof r.value === 'string') ? r.value.trim() : '';
            t = newsCleanBlurb(t);
            blurbs.push(t ? t.slice(0, NEWS_ITEM_MAX) : null);
          }, function () { blurbs.push(null); });
        });
      });
      return chain.then(function () {
        var blocks = [], fallbacks = 0;
        list.forEach(function (it, i) {
          var url = String((it && it.url) || '');
          var shaped = { title: String((it && it.title) || url).slice(0, 160), url: url, audio: String((it && it.audio) || ''), duration: String((it && it.duration) || ''), desc: String((it && it.desc) || '').slice(0, 300) };
          var links = newsBlockLinks(it);
          if (blurbs[i]) blocks.push({ it: shaped, block: blurbs[i] + (links ? '\n' + links : '') });
          else { fallbacks++; blocks.push({ it: shaped, block: '• ' + String((it && it.title) || url).slice(0, 140) + (links ? '\n' + links : '') }); }
        });
        var packed = newsPackPost(tpl, { feed: name, date: day }, blocks);
        if (!packed.posted.length || !packed.body) return classic();
        if (fallbacks || packed.posted.length < list.length) log('[chloe.news] voice composed ' + packed.posted.length + '/' + list.length + ' stories' + (fallbacks ? ' (' + fallbacks + ' classic fallback)' : '') + (packed.posted.length < list.length ? ', ' + (list.length - packed.posted.length) + ' deferred (post full)' : ''));
        return { text: newsApplyTemplate(tpl, { feed: name, date: day, count: packed.posted.length, body: packed.body }), posted: packed.posted };
      });
    }
    function newsFeedsForHere() {
      return (Array.isArray(cfg.newsFeeds) ? cfg.newsFeeds : []).filter(function (f) {
        return f && f.id && f.site && String(f.channelId || '') === String(cfg.channelId);
      });
    }
    function newsStateGet() {
      return Promise.resolve(store.get(NEWS_KEY)).then(function (st) {
        var out = (st && st.byFeed && typeof st.byFeed === 'object') ? st : { byFeed: {} };
        if (!Array.isArray(out.sent)) out.sent = [];   // redirect ring: recent own 📰 posts (old shapes lack it)
        if (!Array.isArray(out.queue)) out.queue = [];   // review queue: staged rollups (old shapes lack it)
        if (out.lastRun != null && (typeof out.lastRun !== 'object' || Array.isArray(out.lastRun))) out.lastRun = null;   // honest-run summary (old shapes lack it)
        return out;
      });
    }
    // Per-feed diagnostic write: records the last attempt WITHOUT touching the
    // interval clock (lastRun) unless told to — a hold/deny/failure stays due so
    // approval (or the next poll) can still fire, but `!chloe news` can show it.
    function newsDiagRecord(st, feedId, patch, advanceClock) {
      var rec = (st.byFeed && st.byFeed[feedId]) || { lastRun: 0, seen: [] };
      if (patch) for (var k in patch) rec[k] = patch[k];
      rec.lastAt = rec.lastAt || clock.now();
      if (advanceClock) rec.lastRun = clock.now();
      st.byFeed[feedId] = rec;
      return rec;
    }
    // Redirect signature: matches an echoed own 📰 post even after the Links gate
    // strips its URLs at send time (transport rewrites what Discord echoes, so an
    // exact clip would miss whenever Links is OFF). Normalized both sides.
    function newsOwnSig(text) {
      return String(text || '').replace(/https?:\/\/\S+/gi, '').replace(/\s+/g, ' ').trim().slice(0, 160);
    }
    // Fetch chain: robots -> sitemap (one index level) -> parse + filter — or,
    // when the site is a direct URL (feed or sitemap, not a bare root), fetch
    // it as-is (RSS/Atom via newsParseFeedItems, sitemap via newsParseItems).
    // Resolves {via, items, total} or {error}. Never throws, never touches the store.
    function newsFetchFeed(feed, seen) {
      if (typeof cfg.fetchText !== 'function') return Promise.resolve({ error: 'fetch unavailable' });
      var site = String((feed && feed.site) || '').replace(/\/+$/, '');
      if (!/^https?:\/\//i.test(site)) return Promise.resolve({ error: 'bad site url' });
      var fid = (feed && feed.id) || site;
      function fail(why) { log('[chloe.news] feed "' + fid + '" skipped (' + why + ')'); return { error: why }; }
      function finish(got) {
        if (got && got.error) return got;
        if (!got) return fail('sitemap unreachable');
        var parsed = (got.feed) ? newsParseFeedItems(got.xml) : newsParseItems(got.xml);
        var items = newsFilterItems(parsed, {
          seen: seen, banWords: feed.banWords, allowCats: feed.allowCats, blockCats: feed.blockCats
        });
        return { via: got.via, items: items, total: parsed.length };
      }
      var rootPath = '';
      try { rootPath = String(site.match(/^https?:\/\/[^\/:?#]+(.*)$/i)[1] || ''); } catch (e) {}
      if (rootPath && rootPath !== '/') {
        return Promise.resolve(cfg.fetchText(site)).then(function (r) {
          if (!r || !r.ok || !r.value) return fail('feed unreachable' + ((r && r.reason) ? ' (' + r.reason + ')' : ''));
          var isFeed = /<(rss|feed|rdf)[:\s>]/i.test(r.value);
          var isMap = /<(urlset|sitemapindex)[\s>]/i.test(r.value);
          if (!isFeed && !isMap) return fail('not a feed (no RSS/Atom/sitemap at this URL)');
          return finish({ xml: r.value, via: site, feed: isFeed && !isMap });
        }, function () { return fail('fetch threw'); });
      }
      return Promise.resolve(cfg.fetchText(site + '/robots.txt')).then(function (r) {
        if (!r || !r.ok || !r.value) return fail('robots unreachable' + ((r && r.reason) ? ' (' + r.reason + ')' : ''));
        var maps = newsParseRobots(r.value);
        if (!maps.length) return fail('no sitemaps in robots.txt');
        var first = newsPickSitemap(maps);
        if (!first) return fail('no usable sitemap');
        // One index level: if the pick is a sitemapindex, take its best child.
        return Promise.resolve(cfg.fetchText(first)).then(function (r2) {
          if (!r2 || !r2.ok || !r2.value) return fail('sitemap unreachable' + ((r2 && r2.reason) ? ' (' + r2.reason + ')' : ''));
          var child = null;
          if (/<sitemapindex[\s>]/i.test(r2.value)) {
            var kids = [];
            var re = /<sitemap[\s>][\s\S]*?<\/sitemap\s*>/gi, m;
            while ((m = re.exec(r2.value)) && kids.length < 60) {
              var kl = (m[0].match(/<loc\s*>([\s\S]*?)<\/loc\s*>/i) || [])[1];
              if (kl) kids.push(newsUnescape(kl).trim());
            }
            child = newsPickSitemap(kids);
            if (!child) return fail('index has no usable child');
            return Promise.resolve(cfg.fetchText(child)).then(function (r3) {
              if (!r3 || !r3.ok || !r3.value) return fail('news sitemap unreachable' + ((r3 && r3.reason) ? ' (' + r3.reason + ')' : ''));
              return { xml: r3.value, via: child };
            });
          }
          return { xml: r2.value, via: first };
        }).then(function (got) {
          return finish(got);
        });
      }, function () { return fail('fetch threw'); });
    }
    // One due feed -> fetch, filter, compose (AI voice or classic). Returns {feed, text, urls, items},
    // {text:'',...} when nothing new, or {error} when the fetch/compose failed. Never throws.
    function newsRunFeed(feed, seen) {
      return newsFetchFeed(feed, seen).then(function (got) {
        if (!got || got.error) return { error: (got && got.error) || 'fetch failed' };   // fetch failed — lastRun untouched, retries next poll
        if (!got.items.length) { log('[chloe.news] feed "' + feed.id + '" — nothing new'); return { feed: feed, text: '', urls: [], items: [] }; }
        var n = Math.max(1, Math.min(10, feed.maxItems || 5));
        return newsComposeText(feed, got.items, feed.maxItems).then(function (composed) {
          if (!composed || !composed.text) return { error: 'compose failed' };
          var posted = (composed.posted && composed.posted.length) ? composed.posted : got.items.slice(0, n);
          return { feed: feed, text: composed.text, urls: posted.map(function (x) { return x.url; }),
                   items: posted.map(function (x) { return { title: String(x.title || x.url).slice(0, 160), url: x.url, audio: String(x.audio || ''), duration: String(x.duration || ''), desc: String(x.desc || '').slice(0, 300) }; }) };
        });
      });
    }
    // Rule S S2/R2: single filter-word validator — testNewsFeed + runNewsFeedNow
    // carried byte-identical inline copies (Test accepting what Run rejects = silent skew).
    function newsStrArr(v, cap) {
      if (v == null) return [];
      if (!Array.isArray(v)) return null;
      var out = [];
      for (var i = 0; i < v.length; i++) {
        var w = String(v[i] == null ? '' : v[i]).trim().toLowerCase();
        if (!w) continue;
        if (w.length > 40) return null;
        out.push(w);
      }
      if (out.length > cap) return null;
      return out;
    }
    // Dry-run for the panel Test button: same fetch chain, empty seen-set, the
    // feed's own filters applied. Never writes the store, never posts, never marks seen.
    function testNewsFeed(feed) {
      feed = feed || {};
      var site = String(feed.site || '').trim().replace(/\/+$/, '');
      if (!/^https?:\/\/[^\s\/:?#]+(\.[^\s\/:?#]+)+(\/\S*)?$/i.test(site)) return Promise.resolve({ ok: false, reason: 'site must be an https root URL or feed URL (e.g. https://kotaku.com or https://example.com/feed.xml)' });
      var bw = newsStrArr(feed.banWords, 50), ac = newsStrArr(feed.allowCats, 30), bc = newsStrArr(feed.blockCats, 30);
      if (bw === null || ac === null || bc === null) return Promise.resolve({ ok: false, reason: 'filter words must be ≤40 chars (drop ≤50, topics ≤30)' });
      var kind = (feed.kind === 'podcast') ? 'podcast' : 'news';
      return newsFetchFeed({ id: feed.id || site, site: site, kind: kind, banWords: bw, allowCats: ac, blockCats: bc }, []).then(function (r) {
        if (!r || r.error) return { ok: false, reason: (r && r.error) || 'fetch failed' };
        return { ok: true, via: r.via, total: r.total, count: r.items.length, kind: kind,
          sample: r.items.slice(0, 3).map(function (it) { return { title: it.title || it.url, url: it.url, audio: it.audio || '', duration: it.duration || '', desc: (it.desc || '').slice(0, 300) }; }) };
      });
    }
    // Immediate single-feed run for the panel Run button: same fetch+filter+
    // compose chain as the timer lane, but for one caller-supplied feed config
    // (a saved feed or an unsaved draft — no save required). Seen is keyed by
    // feed id, so a later Save won't repost these stories; lastRun advances on
    // posted/queued/nothing (hold/deny/fail stay due, like the timer lane).
    // Resolves {ok, ran, detail} or {ok:false, reason}. Never throws.
    function runNewsFeedNow(feed) {
      feed = feed || {};
      var id = String(feed.id || '').trim().toLowerCase();
      var site = String(feed.site || '').trim().replace(/\/+$/, '');
      var target = String(feed.channelId || '');
      if (!id || !/^[a-z0-9-]{1,32}$/.test(id)) return Promise.resolve({ ok: false, reason: 'missing feed id' });
      if (!/^https?:\/\/[^\s\/:?#]+(\.[^\s\/:?#]+)+(\/\S*)?$/i.test(site)) return Promise.resolve({ ok: false, reason: 'site must be an https root URL or feed URL (e.g. https://kotaku.com or https://example.com/feed.xml)' });
      if (!target) return Promise.resolve({ ok: false, reason: 'assign a Posts-to channel first — Unassigned sources stay dormant' });
      if (target !== String(cfg.channelId)) return Promise.resolve({ ok: false, reason: 'that feed posts to a different channel' });
      var bw = newsStrArr(feed.banWords, 50), ac = newsStrArr(feed.allowCats, 30), bc = newsStrArr(feed.blockCats, 30);
      if (bw === null || ac === null || bc === null) return Promise.resolve({ ok: false, reason: 'filter words must be ≤40 chars (drop ≤50, topics ≤30)' });
      var mx = Math.max(1, Math.min(10, Math.round(Number(feed.maxItems) || 5)));
      var iv = Number(feed.intervalMs);
      if (!isFinite(iv) || iv < 600000 || iv > 86400000) iv = (feed.kind === 'podcast') ? NEWS_POD_DEFAULT_EVERY : NEWS_DEFAULT_EVERY;
      var kind = (feed.kind === 'podcast') ? 'podcast' : 'news';
      var f = { id: id, name: String(feed.name || id).slice(0, 60), site: site, kind: kind, channelId: target, intervalMs: iv, maxItems: mx, banWords: bw, allowCats: ac, blockCats: bc };
      var now = clock.now();
      return newsClaimRun().then(function (got) {
        if (!got) return { ok: false, reason: 'a news run is already in progress — try again in a bit' };
        function done(r) { return newsReleaseRun().then(function () { return r; }, function () { return r; }); }
        return newsStateGet().then(function (st) {
          var rec = (st.byFeed && st.byFeed[id]) || { lastRun: 0, seen: [] };
          var seen = rec.seen || [];
          return newsRunFeed(f, seen).then(function (out) {
            if (!out || out.error) {
              var why = (out && out.error) || 'fetch failed';
              newsDiagRecord(st, id, { lastResult: 'failed', lastAt: now, lastCount: 0, lastError: String(why).slice(0, 160) }, false);
              return store.set(NEWS_KEY, st).then(function () { return done({ ok: false, reason: why }); });
            }
            if (!out.text) {
              newsDiagRecord(st, id, { lastResult: 'nothing', lastAt: now, lastCount: 0, lastError: '' }, true);
              return store.set(NEWS_KEY, st).then(function () { return done({ ok: true, ran: 'nothing', detail: 'checked — nothing new' }); });
            }
            var n = (out.items || []).length;
            if (cfg.newsReview) return newsEnqueue(f, out, st, now).then(function (r) {
              if (r && r.queued) {
                newsDiagRecord(st, id, { lastResult: 'queued', lastAt: now, lastCount: n, lastError: '' }, false);
                return store.set(NEWS_KEY, st).then(function () { return done({ ok: true, ran: 'queued', detail: 'queued for review (' + n + ' items) — see Setup → News queue' }); });
              }
              newsDiagRecord(st, id, { lastResult: 'failed', lastAt: now, lastCount: 0, lastError: 'enqueue failed' }, false);
              return store.set(NEWS_KEY, st).then(function () { return done({ ok: false, reason: 'enqueue failed' }); });
            });
            return newsPostComposed(f, out, st, now).then(function (r) {
              if (r && r.posted) {
                newsDiagRecord(st, id, { lastResult: 'posted', lastAt: now, lastCount: (out.urls || []).length, lastError: '' }, false);
                return store.set(NEWS_KEY, st).then(function () { return done({ ok: true, ran: 'posted', detail: 'posted rollup (' + (out.urls || []).length + ' items)' }); });
              }
              if (r && r.held) {
                newsDiagRecord(st, id, { lastResult: 'held', lastAt: now, lastCount: n, lastError: 'held by policy' }, false);
                return store.set(NEWS_KEY, st).then(function () { return done({ ok: true, ran: 'held', detail: 'held for approval — approve with ' + cfg.commandPrefix + ' approve' }); });
              }
              if (r && r.denied) {
                newsDiagRecord(st, id, { lastResult: 'denied', lastAt: now, lastCount: n, lastError: 'denied by policy' }, false);
                return store.set(NEWS_KEY, st).then(function () { return done({ ok: true, ran: 'denied', detail: 'denied by policy' }); });
              }
              newsDiagRecord(st, id, { lastResult: 'failed', lastAt: now, lastCount: 0, lastError: 'send failed' }, false);
              return store.set(NEWS_KEY, st).then(function () { return done({ ok: false, reason: 'send failed' }); });
            });
          }).then(function (r) { return newsHeartbeat().then(function () { return r; }); });
        });
      });
    }
    // Review queue helpers (F2 review mode: cfg.newsReview stages composed
    // rollups instead of posting). Entries live in NEWS_KEY `queue`, capped at
    // 10 with >7d pruned on write. A queued entry reserves its urls (seen is
    // consumed at enqueue), so discard means "skip those stories".
    var NEWS_QUEUE_MAX = 10, newsQSeq = 0;
    function newsQid() { newsQSeq++; return 'q' + clock.now().toString(36) + 'n' + newsQSeq.toString(36); }
    function newsQueuePrune(st, now) {
      var q = Array.isArray(st.queue) ? st.queue : [];
      var weekAgo = now - 604800000;
      q = q.filter(function (e) { return e && e.qid && e.at && e.at >= weekAgo; });
      while (q.length > NEWS_QUEUE_MAX) q.shift();   // oldest first
      st.queue = q;
      return q;
    }
    function newsEnqueue(f, out, st, now) {
      var rec = st.byFeed[f.id] || { lastRun: 0, seen: [] };
      rec.seen = (rec.seen || []).concat(out.urls);
      if (rec.seen.length > 200) rec.seen = rec.seen.slice(-200);
      st.byFeed[f.id] = { lastRun: now, seen: rec.seen };
      var q = newsQueuePrune(st, now);
      var entry = { qid: newsQid(), feedId: f.id, name: (f.name || f.id), kind: newsKindOf(f), max: Math.max(1, Math.min(10, f.maxItems || 5)),
                    target: String(cfg.channelId), at: now, items: out.items || [], text: out.text };
      q.push(entry);
      newsQueuePrune(st, now);   // the push may have overflowed the cap (oldest drops, never the new one... unless overfull already — shift order keeps arrival order)
      return store.set(NEWS_KEY, st).then(function () {
        log('[chloe.news] queued rollup from "' + (f.name || f.id) + '" (' + (out.items || []).length + ' items) — review in Setup → News queue');
        return { queued: entry.qid, id: f.id };
      });
    }
    // Shared post tail: policy gate -> send -> sent-ring/marker records.
    // Resolves {posted, id} / {held} / {denied} / {failed}. Never throws.
    function newsPostComposed(f, out, st, now) {
      return actGate('news').then(function (gate) {
        if (gate === 'hold') return holdAct('news', 'rollup from ' + (f.name || f.id)).then(function () { return { held: true }; });
        if (gate !== 'go') return { denied: true };   // deny: lastRun untouched, stays due (queue entries stay queued)
        // go: consume the urls into seen (a hold/deny above never touches seen,
        // so an approved hold re-fetches the same stories instead of losing them)
        var rec = st.byFeed[f.id] || { lastRun: 0, seen: [] };
        var seen = (rec.seen || []).concat(out.urls);
        if (seen.length > 200) seen = seen.slice(-200);
        st.byFeed[f.id] = { lastRun: now, seen: seen };
        return store.set(NEWS_KEY, st).then(function () {
          return Promise.resolve(cfg.send(cfg.channelId, out.text)).then(function () {
            log('[chloe.news] posted rollup from "' + (f.name || f.id) + '" (' + out.urls.length + ' items)');
            // Redirect record: the post itself stays out of chat context (the
            // ownline capture below skips it unless newsInContext), but its
            // signature joins the sent ring so Thoughts can note that it went out.
            var sent = Array.isArray(st.sent) ? st.sent : [];
            sent.push({ feed: (f.name || f.id), fid: f.id, count: out.urls.length, at: now, sig: newsOwnSig(out.text) });
            var weekAgo = now - 604800000;
            sent = sent.filter(function (s) { return s && s.at && s.at >= weekAgo; });
            while (sent.length > 10) sent.shift();
            st.sent = sent;
            return store.set(NEWS_KEY, st).then(function () { return { posted: true, id: f.id }; });
          }, function () { return { failed: true }; });
        });
      });
    }
    function newsQueueFind(st, qid) {
      var q = Array.isArray(st.queue) ? st.queue : [];
      for (var i = 0; i < q.length; i++) { if (q[i] && q[i].qid === qid) return { entry: q[i], index: i, queue: q }; }
      return null;
    }
    function newsQueueValidItems(items) {
      if (!Array.isArray(items) || !items.length || items.length > 10) return null;
      var out = [];
      for (var i = 0; i < items.length; i++) {
        var it = items[i] || {};
        var title = String(it.title == null ? '' : it.title).trim().slice(0, 160);
        var url = String(it.url == null ? '' : it.url).trim().slice(0, 500);
        if (!title || !/^https?:\/\//i.test(url)) return null;
        out.push({ title: title, url: url, audio: String(it.audio || '').slice(0, 500), duration: String(it.duration || '').slice(0, 20), desc: String(it.desc || '').slice(0, 300) });
      }
      return out;
    }
    function listNewsQueue() {
      return newsStateGet().then(function (st) { return { channel: String(cfg.channelId), queue: newsQueuePrune(st, clock.now()).slice() }; });
    }
    // Panel + timers surface: per-feed diagnostics + last-run summary (async store reads; old engines lack it).
    function newsDiag() {
      return newsStateGet().then(function (st) {
        return { channel: String(cfg.channelId), byFeed: st.byFeed || {}, lastRun: st.lastRun || null,
                 queue: Array.isArray(st.queue) ? st.queue.length : 0 };
      });
    }
    function updateNewsQueue(args) {
      var qid = String((args && args.qid) || '');
      if (!qid) return Promise.resolve({ ok: false, reason: 'no queued item' });
      return newsStateGet().then(function (st) {
        var hit = newsQueueFind(st, qid);
        if (!hit) return { ok: false, reason: 'queued item gone' };
        if (args.items !== undefined) {
          var items = newsQueueValidItems(args.items);
          if (!items) return { ok: false, reason: 'items must be 1–10 {title (≤160), url} rows' };
          hit.entry.items = items;
        }
        if (args.text !== undefined) {
          var t = String(args.text == null ? '' : args.text).slice(0, 1900);
          if (!t.trim()) return { ok: false, reason: 'text must not be empty' };
          hit.entry.text = t;
        }
        newsQueuePrune(st, clock.now());
        return store.set(NEWS_KEY, st).then(function () { return { ok: true, value: hit.entry }; });
      });
    }
    function regenNewsQueue(args) {
      var qid = String((args && args.qid) || '');
      if (!qid) return Promise.resolve({ ok: false, reason: 'no queued item' });
      return newsStateGet().then(function (st) {
        var hit = newsQueueFind(st, qid);
        if (!hit) return { ok: false, reason: 'queued item gone' };
        var live = null;
        (newsFeedsForHere() || []).forEach(function (f) { if (f && f.id === hit.entry.feedId) live = f; });
        var meta = { name: (live && live.name) || hit.entry.name || hit.entry.feedId, kind: (live && live.kind) || hit.entry.kind || 'news',
                     maxItems: (live && live.maxItems) || hit.entry.max || 5 };
        return newsComposeText(meta, hit.entry.items, meta.maxItems).then(function (composed) {
          if (!composed || !composed.text) return { ok: false, reason: 'compose failed' };
          hit.entry.text = composed.text;
          newsQueuePrune(st, clock.now());
          return store.set(NEWS_KEY, st).then(function () {
            log('[chloe.news] regenerated queued rollup from "' + meta.name + '"');
            return { ok: true, value: hit.entry };
          });
        });
      });
    }
    function dropNewsQueue(args) {
      var qid = String((args && args.qid) || '');
      if (!qid) return Promise.resolve({ ok: false, reason: 'no queued item' });
      return newsStateGet().then(function (st) {
        var hit = newsQueueFind(st, qid);
        if (!hit) return { ok: false, reason: 'queued item gone' };
        hit.queue.splice(hit.index, 1);
        return store.set(NEWS_KEY, st).then(function () {
          log('[chloe.news] discarded queued rollup from "' + (hit.entry.name || hit.entry.feedId) + '" (its stories stay marked seen)');
          return { ok: true, value: { dropped: qid } };
        });
      });
    }
    var newsPostingQids = {};   // one in-flight manual post per queued entry (double-click guard)
    function postNewsQueue(args) {
      var qid = String((args && args.qid) || '');
      if (!qid) return Promise.resolve({ ok: false, reason: 'no queued item' });
      // Double-click guard: two rapid "Post now" presses dispatch twice before the
      // first send drains the entry — without this, both post. Set synchronously
      // (before the first await) so the second dispatch on the same tick sees it.
      if (newsPostingQids[qid]) return Promise.resolve({ ok: false, reason: 'already posting that entry' });
      newsPostingQids[qid] = true;
      function donePost(r) { delete newsPostingQids[qid]; return r; }
      var now = clock.now();
      return newsStateGet().then(function (st) {
        var hit = newsQueueFind(st, qid);
        if (!hit) return { ok: false, reason: 'queued item gone' };
        if (args.text !== undefined) {
          var t = String(args.text == null ? '' : args.text).slice(0, 1900);
          if (!t.trim()) return { ok: false, reason: 'text must not be empty' };
          hit.entry.text = t;
        }
        if (!hit.entry.text || !(hit.entry.items || []).length) return { ok: false, reason: 'nothing to post' };
        var live = null;
        (newsFeedsForHere() || []).forEach(function (f) { if (f && f.id === hit.entry.feedId) live = f; });
        if (!live) return { ok: false, reason: 'its feed no longer posts to this channel' };
        var out = { text: hit.entry.text, urls: hit.entry.items.map(function (x) { return x.url; }) };
        return newsPostComposed(live, out, st, now).then(function (r) {
          if (r && r.posted) {
            hit.queue.splice(hit.index, 1);
            return store.set(NEWS_KEY, st).then(function () { return { ok: true, value: { posted: true, qid: qid, feed: live.id } }; });
          }
          if (r && r.held) return { ok: false, reason: 'held by policy (stays queued)' };
          if (r && r.denied) return { ok: false, reason: 'denied by policy (stays queued)' };
          return { ok: false, reason: 'send failed (stays queued)' };
        });
      }).then(function (r) { return donePost(r); }, function (e) { delete newsPostingQids[qid]; throw e; });
    }
    // The news lane: for each feed targeting this channel, run when its
    // interval elapsed (seed-not-fire like beats). No activity gate — a
    // feed-only channel is quiet by design. Autonomous output: policy-gated.
    // Review mode stages composed rollups in the queue instead of posting.
    // Honest reporting: ALWAYS resolves a structured result (never bare null on
    // a forced run) — {feeds, queued, held, denied, failed, nothing, checked}
    // plus {busy}/{blocked}/{empty}/{noFetch}/{idle} — and persists per-feed
    // lastResult/lastError + a global lastRun summary for `!chloe news/timers`.
    function processNews(force) {
      var feeds = newsFeedsForHere();
      var ids = feeds.map(function (f) { return f.id; });
      if (!feeds.length) return Promise.resolve({ empty: true, checked: [] });
      if (typeof cfg.fetchText !== 'function') return Promise.resolve({ noFetch: true, checked: ids });
      if (engageMode === 'locked') return Promise.resolve({ blocked: 'locked down', checked: ids });
      if (reply.replying) return Promise.resolve({ blocked: 'a reply is in flight', checked: ids });
      if (paint.painting) return Promise.resolve({ blocked: 'an image is painting', checked: ids });
      if (inProactiveSettle(clock.now())) return Promise.resolve({ blocked: 'just started (settle)', checked: ids });
      var now = clock.now();
      return newsStateGet().then(function (st) {
        var due = feeds.filter(function (f) {
          var rec = st.byFeed[f.id] || {};
          if (force) return true;
          if (rec.lastRun == null) return false;   // seed, don't fire on first sight
          return (now - rec.lastRun) >= (Number(f.intervalMs) || 3600000);
        });
        // Seed unseen feeds so the interval starts now, never at boot.
        var seeded = false;
        feeds.forEach(function (f) { if (!st.byFeed[f.id]) { st.byFeed[f.id] = { lastRun: now, seen: [] }; seeded = true; } });
        if (!due.length) {
          if (seeded) return store.set(NEWS_KEY, st).then(function () { return { idle: true, checked: [] }; });
          return { idle: true, checked: [] };
        }
        return newsClaimRun().then(function (got) {
          if (!got) {
            log('[chloe.news] a news run is already in flight for this channel — standing down (no double-post)');
            return { busy: true, checked: ids };
          }
          function doneRun(res) {
            res = res || {};
            res.checked = due.map(function (f) { return f.id; });
            st.lastRun = { at: now, forced: !!force,
              checked: res.checked.slice(),
              posted: (res.feeds || []).slice(), queued: (res.queued || []).slice(),
              held: (res.held || []).slice(), denied: (res.denied || []).slice(),
              failed: (res.failed || []).slice(), nothing: (res.nothing || []).slice(),
              errors: (res.failed || []).map(function (e) { return (e && e.id) + ': ' + ((e && e.error) || 'failed'); }) };
            if (res.busy) st.lastRun.busy = true;
            if (res.blocked) st.lastRun.blocked = res.blocked;
            return store.set(NEWS_KEY, st).then(function () { return newsReleaseRun().then(function () { return res; }, function () { return res; }); },
              function () { return newsReleaseRun().then(function () { return res; }, function () { return res; }); });
          }
          var chain = Promise.resolve(), fired = [], queued = [], held = [], denied = [], failed = [], nothing = [];
          due.forEach(function (f) {
            chain = chain.then(function () {
              var rec = st.byFeed[f.id] || { lastRun: 0, seen: [] };
              return newsRunFeed(f, rec.seen).then(function (out) {
                if (!out || out.error) {   // fetch/compose failed — interval clock untouched, retries next poll
                  var why = (out && out.error) || 'fetch failed';
                  log('[chloe.news] feed "' + f.id + '" failed (' + why + ')');
                  newsDiagRecord(st, f.id, { lastResult: 'failed', lastAt: now, lastCount: 0, lastError: String(why).slice(0, 160) }, false);
                  failed.push({ id: f.id, error: why });
                  return store.set(NEWS_KEY, st);
                }
                if (!out.text) {   // nothing new: advance the clock anyway (hourly cadence, not catch-up spam)
                  log('[chloe.news] feed "' + f.id + '" — nothing new');
                  newsDiagRecord(st, f.id, { lastResult: 'nothing', lastAt: now, lastCount: 0, lastError: '' }, true);
                  nothing.push(f.id);
                  return store.set(NEWS_KEY, st);
                }
                if (cfg.newsReview) return newsEnqueue(f, out, st, now).then(function (r) {
                  if (r && r.queued) {
                    newsDiagRecord(st, f.id, { lastResult: 'queued', lastAt: now, lastCount: (out.items || []).length, lastError: '' }, false);
                    queued.push(f.id);
                  } else {
                    newsDiagRecord(st, f.id, { lastResult: 'failed', lastAt: now, lastCount: 0, lastError: 'enqueue failed' }, false);
                    failed.push({ id: f.id, error: 'enqueue failed' });
                  }
                });
                return newsPostComposed(f, out, st, now).then(function (r) {
                  if (r && r.posted) {
                    newsDiagRecord(st, f.id, { lastResult: 'posted', lastAt: now, lastCount: (out.urls || []).length, lastError: '' }, false);
                    fired.push(f.id);
                  } else if (r && r.held) {
                    newsDiagRecord(st, f.id, { lastResult: 'held', lastAt: now, lastCount: (out.urls || []).length, lastError: 'held by policy' }, false);
                    held.push(f.id);
                  } else if (r && r.denied) {
                    newsDiagRecord(st, f.id, { lastResult: 'denied', lastAt: now, lastCount: (out.urls || []).length, lastError: 'denied by policy' }, false);
                    denied.push(f.id);
                  } else {
                    newsDiagRecord(st, f.id, { lastResult: 'failed', lastAt: now, lastCount: 0, lastError: 'send failed' }, false);
                    failed.push({ id: f.id, error: 'send failed' });
                  }
                  return store.set(NEWS_KEY, st);
                });
              }).then(function (r) { return newsHeartbeat().then(function () { return r; }); });
            });
          });
          return chain.then(function () {
            var res = {};
            if (fired.length) res.feeds = fired;
            if (queued.length) res.queued = queued;
            if (held.length) res.held = held;
            if (denied.length) res.denied = denied;
            if (failed.length) res.failed = failed;
            if (nothing.length) res.nothing = nothing;
            return doneRun(res);
          },
            function (e) {
              log('[chloe.news] run error (' + ((e && e.message) || e) + ')');
              // keep the outcomes already banked (their store writes persisted);
              // only feeds with no outcome yet are marked failed
              var scored = {};
              fired.concat(queued, held, denied).forEach(function (id) { scored[id] = true; });
              failed.forEach(function (f) { if (f && f.id) scored[f.id] = true; });
              (nothing || []).forEach(function (id) { scored[id] = true; });
              var res = {};
              if (fired.length) res.feeds = fired;
              if (queued.length) res.queued = queued;
              if (held.length) res.held = held;
              if (denied.length) res.denied = denied;
              if (nothing.length) res.nothing = nothing;
              var unprocessed = due.filter(function (f) { return !scored[f.id]; })
                .map(function (f) { return { id: f.id, error: 'run error' }; });
              res.failed = failed.concat(unprocessed);
              return doneRun(res);
            });
        });
      });
    }

    // ---- idle consolidation (the “sleep” pass) -------------------------------------------
    function channelIsIdle() {
      return Promise.resolve(store.get(RHYTHM_KEY)).then(function (rh) {
        var last = rh && rh.lastActivity;
        if (last == null) return false;   // no activity recorded yet = nothing to tidy
        var z = paceIsQuiet(clock.now());   // pace core: rhythm-relative quiet (null when pace not ready)
        if (z !== null) return z;           // a fast room is "idle" sooner; a slow room later — relative to ITS rhythm
        return (clock.now() - last) >= (cfg.consolidateIdleMs || 1800000);   // fallback: flat threshold
      });
    }
    // Structural: pure local compute, no LLM. Dedup exact/near facts (keep higher importance + newer),
    // drop empties, trim to cap; hard-drop stale low-importance episodes. Bounded slice per pass.
    function consolidateStructural() {
      return Promise.resolve(store.get(CONSOLIDATE_KEY)).then(function (meta) {
        meta = meta || { lastSweepAt: 0, sliceCursor: 0 };
        return getRoster().then(function (roster) {
          var active = roster.filter(function (p) { return p && (!p.state || p.state === 'active'); });
          var start = meta.sliceCursor % Math.max(1, active.length);
          var slice = active.slice(start, start + (cfg.consolidateSliceSize || 5));
          var mergedTotal = 0, droppedTotal = 0;
          var chain = Promise.resolve();
          slice.forEach(function (p) {
            chain = chain.then(function () {
              var facts = Array.isArray(p.facts) ? p.facts : [];
              if (!facts.length) return;
              var byNorm = {}; var out = [];
              facts.forEach(function (f) {
                var key = normFact(f && f.text);
                if (!key) { droppedTotal++; return; }   // empty/whitespace fact
                if (byNorm[key]) {   // duplicate: keep the stronger/newer, count a merge
                  var keep = byNorm[key];
                  keep.i = Math.max(keep.i || 5, f.i || 5);
                  keep.at = Math.max(keep.at || 0, f.at || 0);
                  mergedTotal++;
                } else { byNorm[key] = f; out.push(f); }
              });
              if (out.length > (cfg.factsPerUser || 6)) { droppedTotal += out.length - cfg.factsPerUser; out = out.slice(-(cfg.factsPerUser || 6)); }
              var changed = out.length !== facts.length;
              // contradiction tidy: drop a recorded conflict once it's stale, or once it's resolved
              // (a side no longer present among the kept facts — e.g. the person restated and it merged).
              if (p.conflict) {
                var ttl = cfg.contradictionTtlMs || 259200000;
                var liveText = {}; out.forEach(function (f) { liveText[normFact(f.text)] = 1; });
                var stale = (clock.now() - (p.conflict.at || 0)) > ttl;
                var resolved = !liveText[normFact(p.conflict.a)] || !liveText[normFact(p.conflict.b)];
                if (stale || resolved) { delete p.conflict; changed = true; }
              }
              if (changed) p.facts = out;
              return changed ? userStore().set(partKey(p.id), p) : null;
            });
          });
          // stale-episode drop (channel-level, once per sweep)
          chain = chain.then(function () {
            return Promise.resolve(store.get(EPI_KEY)).then(function (ring) {
              if (!Array.isArray(ring) || !ring.length) return;
              var now = clock.now(), half = cfg.episodeRecencyHalfLifeMs || 604800000, floor = cfg.episodeDropImportanceFloor || 3;
              var kept = ring.filter(function (ep) {
                var decay = Math.pow(0.5, Math.max(0, now - (ep.at || 0)) / half);
                // drop only when BOTH faded (≥4 half-lives) AND low importance — never a recent or important memory
                return !(decay < 0.0625 && (ep.importance || 5) <= floor);
              });
              if (kept.length !== ring.length) {
                droppedTotal += ring.length - kept.length;
                var liveIds = {}; kept.forEach(function (e2) { if (e2.id) liveIds[e2.id] = true; });
                kept.forEach(function (e2) { if (e2.relatesTo && !liveIds[e2.relatesTo.id]) e2.relatesTo = null; });   // drop edges to evicted episodes
                return store.set(EPI_KEY, kept);
              }
            });
          });
          return chain.then(function () {
            meta.lastSweepAt = clock.now();
            meta.sliceCursor = (start + slice.length) % Math.max(1, active.length);
            return store.set(CONSOLIDATE_KEY, meta).then(function () {
              if (mergedTotal || droppedTotal) log('[chloe.sleep] tidied memory — merged ' + mergedTotal + ', dropped ' + droppedTotal);
              return { merged: mergedTotal, dropped: droppedTotal };
            });
          });
        });
      });
    }
    // Semantic: ONE gated LLM pass over one overdue person's facts. The page may only MERGE or DROP;
    // the engine re-validates every returned fact traces to an input (no invention survives).
    function consolidateSemantic() {
      if (typeof cfg.consolidateFn !== 'function') return Promise.resolve(null);
      return getRoster().then(function (roster) {
        var due = null, oldest = Infinity;
        roster.forEach(function (p) {
          if (!p || (p.state && p.state !== 'active')) return;
          if (!Array.isArray(p.facts) || p.facts.length < (cfg.consolidateMinFacts || 6)) return;
          var ca = p.consolidatedAt || 0;
          if (ca < oldest) { oldest = ca; due = p; }
        });
        if (!due) return null;
        var operatorFacts = due.facts.filter(function (f) { return f.source === 'operator'; });
        var consolidatable = due.facts.filter(function (f) { return f.source !== 'operator'; });
        if (!consolidatable.length) return null;   // nothing but operator-owned facts -> leave them alone
        var inputs = consolidatable.map(function (f) { return f.text; });
        return Promise.resolve(cfg.consolidateFn({ name: due.name, facts: inputs })).then(function (r) {
          return Promise.resolve(userStore().get(partKey(due.id))).then(function (p) {
            if (!p) return null;
            p.consolidatedAt = clock.now();
            var proposed = (r && r.ok && Array.isArray(r.value)) ? r.value : null;
            if (!proposed) return userStore().set(partKey(p.id), p).then(function () { return null; });   // failed call: timestamp still bumped (don't re-pick immediately)
            // no-invention guard: keep only proposed facts that trace to an input (normalized substring overlap)
            var inNorms = inputs.map(normFact);
            var clean = [];
            proposed.forEach(function (t) {
              var nt = normFact(t);
              if (!nt) return;
              var traces = inNorms.some(function (inn) { return inn === nt || inn.indexOf(nt) >= 0 || nt.indexOf(inn) >= 0; });
              if (traces) clean.push(String(t).slice(0, 200));
            });
            if (!clean.length) return userStore().set(partKey(p.id), p).then(function () { return null; });   // nothing validated: leave facts as-is
            // map cleaned texts back onto fact objects, preserving importance/at of the best-matching input
            var oldFacts = Array.isArray(p.facts) ? p.facts : [];
            var consolidated = clean.map(function (t) {
              var nt = normFact(t);
              var match = consolidatable.filter(function (f) { var nf = normFact(f.text); return nf === nt || nf.indexOf(nt) >= 0 || nt.indexOf(nf) >= 0; }).sort(function (a, b) { return (b.importance || 5) - (a.importance || 5); })[0];
              return { id: (match && match.id) || mintFactId(), text: t, importance: (match && match.importance) || 5, source: 'observed', at: (match && match.at) || clock.now() };
            });
            // operator facts are authoritative — always kept, unchanged, ahead of the consolidated set.
            var newFacts = operatorFacts.concat(consolidated);
            if (newFacts.length > (cfg.factsPerUser || 6)) {
              var keepOp = newFacts.filter(function (f) { return f.source === 'operator'; });
              var rest = newFacts.filter(function (f) { return f.source !== 'operator'; }).slice(-(Math.max(0, (cfg.factsPerUser || 6) - keepOp.length)));
              newFacts = keepOp.concat(rest);
            }
            var delta = oldFacts.length - newFacts.length;
            p.facts = newFacts;
            return userStore().set(partKey(p.id), p).then(function () {
              if (delta > 0) log('[chloe.sleep] consolidated ' + due.name + '’s memory (' + oldFacts.length + ' → ' + newFacts.length + ' facts)');
              return delta > 0 ? { name: due.name, before: oldFacts.length, after: newFacts.length } : null;
            });
          });
        }, function () { return null; });
      });
    }

    // Reflection: one synthesis pass for ONE person whose accumulated fact-importance crossed the
    // threshold. Turns facts + prior insights into 1-2 durable higher-level insights, stored on the
    // partition; resets the accumulator. No send — silent understanding, not a message.
    function processReflection() {
      if (!cfg.reflection || typeof cfg.reflectFn !== 'function') return Promise.resolve(null);
      return getRoster().then(function (roster) {
        var due = null;
        for (var i = 0; i < roster.length; i++) {
          var u = roster[i];
          if (!u || (u.state && u.state !== 'active')) continue;
          if ((u.reflectImportanceAccum || 0) >= cfg.reflectionImportanceThreshold) { due = u; break; }
        }
        if (!due) return null;
        var factTexts = (due.facts || []).map(function (f) { return f.text; });
        var priorInsights = (due.insights || []).map(function (x) { return x.text; });
        return Promise.resolve(cfg.reflectFn({ name: due.name, facts: factTexts, insights: priorInsights })).then(function (r) {
          var proposed = (r && r.ok && Array.isArray(r.value)) ? r.value : [];
          return Promise.resolve(userStore().get(partKey(due.id))).then(function (p) {
            if (!p) return null;
            p.reflectImportanceAccum = 0; p.reflectAt = clock.now();   // reset even on an empty result (don't loop)
            var ins = Array.isArray(p.insights) ? p.insights : [];
            var seen = {}; ins.forEach(function (x) { seen[normFact(x.text)] = true; });
            var added = 0; var goalPromises = [];
            proposed.forEach(function (raw) {
              var text = String(raw || '').trim().slice(0, 160);
              if (/^goal:/i.test(text)) {   // a forward-looking commitment -> a goal object, not an insight
                if (cfg.goalObjects) goalPromises.push(addGoal(text.replace(/^goal:/i, '').trim(), due.id, due.name, 'reflect'));
                return;
              }
              var key = normFact(text);
              if (!key || seen[key]) return;
              seen[key] = true; ins.push({ text: text, at: clock.now() }); added++;
            });
            if (ins.length > (cfg.insightsPerUser || 3)) ins = ins.slice(-(cfg.insightsPerUser || 3));
            p.insights = ins;
            return Promise.all(goalPromises).then(function () { return userStore().set(partKey(p.id), p); }).then(function () {
              if (added) log('[chloe.reflect] formed ' + added + ' insight(s) about ' + due.name);
              return added ? { name: due.name, added: added } : null;
            });
          });
        });
      });
    }
    // F1 extraction pass: pick one due regular and ask the brain (page side) to propose durable facts
    // from their recent lines. Gated like check-ins (one user per pass, periodic) so it's cheap. The
    // page handler refuses sensitive categories and returns a short JSON array; we store conservatively.
    // No send — this is silent background learning, not a message.
    function processFacts() {
      if (!cfg.factMemory || typeof cfg.factFn !== 'function') return Promise.resolve(null);
      var now = clock.now();
      return getRoster().then(function (roster) {
        var due = null;
        for (var i = 0; i < roster.length; i++) {
          var u = roster[i];
          if (!u || (u.state && u.state !== 'active')) continue;
          if (factProposeDue(u, now)) { due = u; break; }    // roster is newest-first; take the freshest due user
        }
        if (!due) return null;
        // gather their recent lines for context (store shape is {id,ts,content} — v0.90.6:
        // this read r.text for the whole 0.90.x era, feeding "[object Object]" to the brain so
        // extraction honestly proposed nothing and facts stayed empty forever)
        var lines = (due.recent || []).map(function (r) { return (r && typeof r === 'object') ? String(r.content || '') : String(r || ''); }).filter(Boolean);
        if (!lines.length) {
          // nothing to learn from right now; still advance the baseline so we don't re-scan immediately
          return Promise.resolve(userStore().get(partKey(due.id))).then(function (p) { if (p) { p.factsBaseline = p.interactionCount || 0; p.factsAt = now; return userStore().set(partKey(p.id), p); } });
        }
        return Promise.resolve(cfg.factFn({ name: due.name, lines: lines, known: (due.facts || []).map(function (f) { return f.text; }) })).then(function (r) {
          var proposed = (r && r.ok && Array.isArray(r.value)) ? r.value : [];
          return addFacts(due.id, proposed, 'observed').then(function (added) {
            return Promise.resolve(userStore().get(partKey(due.id))).then(function (p) {
              if (p) { p.factsBaseline = p.interactionCount || 0; p.factsAt = now; p.factsRepairedV906 = true; }   // reset the cadence window + close the v0.90.6 repair path
              return (p ? userStore().set(partKey(p.id), p) : Promise.resolve()).then(function () {
                if (added) log('[chloe.facts] learned ' + added + ' fact(s) about ' + due.name);
                return added ? { facts: added, who: due.name } : null;
              });
            });
          });
        }, function () { return null; });
      });
    }

    function partKey(id) { return 'u:' + id; }

    function toEpoch(ts) {
      if (!ts) return clock.now();
      var t = Date.parse(ts);
      return isNaN(t) ? clock.now() : t;
    }

    // ---- permanent blocklist (tombstones) ------------------------------------------------
    // "Forgotten" must mean forgotten FOREVER: a blocked author is never re-scanned, never
    // re-added to the roster, ever. The blocklist lives at its own top-level key, independent of
    // any partition, so purge()/forgetMe() cannot remove it — purging clears memory, blocking
    // prevents memory from ever forming again. Structured as { ids:{id:meta}, names:{lcname:meta} }
    // so future *fetchable* markers can slot in (account-age, guild-verification gates); note that
    // Discord does NOT expose IP, 2FA, or phone to bots, so those markers are intentionally absent.
    var BLOCK_KEY = 'blocklist';
    function blockStore() { return cfg.globalStore || store; }
    // ---- ethereal / forget-me (GDPR) -----------------------------------------------------
    // The ethereal + forget-floor records live in the PER-CONTEXT bucket: a public channel keeps
    // them in the shared public store (globalStore), a DM keeps them in its own local store. That
    // is what makes the flag independent across public vs DM.
    function etherealStore() { return cfg.isDM ? store : (cfg.globalStore || store); }
    function isEthereal(id) {
      var sid = String(id || ''); if (!sid) return Promise.resolve(false);
      return Promise.resolve(etherealStore().get(ETHEREAL_KEY)).then(function (e) {
        return !!(e && e.ids && e.ids[sid]);
      });
    }
    function setEthereal(id, name) {
      var sid = String(id || ''); if (!sid) return Promise.resolve();
      return Promise.resolve(etherealStore().get(ETHEREAL_KEY)).then(function (e) {
        e = (e && e.ids) ? e : { ids: {} };
        e.ids[sid] = { at: clock.now(), name: name || '' };
        return etherealStore().set(ETHEREAL_KEY, e);
      });
    }
    function clearEthereal(id) {
      var sid = String(id || ''); if (!sid) return Promise.resolve(false);
      return Promise.resolve(etherealStore().get(ETHEREAL_KEY)).then(function (e) {
        if (!e || !e.ids || !e.ids[sid]) return false;
        delete e.ids[sid];
        return Promise.resolve(etherealStore().set(ETHEREAL_KEY, e)).then(function () { return true; });
      });
    }
    // Stamp a floor at the moment of forgetting; it OUTLIVES `remember me` on purpose so a later
    // re-learn (backfill / cold start) can never reach back across it and resurrect erased history.
    function setForgetFloor(id) {
      var sid = String(id || ''); if (!sid) return Promise.resolve();
      return Promise.resolve(etherealStore().get(FORGETFLOOR_KEY)).then(function (f) {
        f = (f && typeof f === 'object') ? f : {};
        f[sid] = clock.now();
        return etherealStore().set(FORGETFLOOR_KEY, f);
      });
    }
    function forgetFloorOf(id) {
      var sid = String(id || ''); if (!sid) return Promise.resolve(0);
      return Promise.resolve(etherealStore().get(FORGETFLOOR_KEY)).then(function (f) {
        return (f && f[sid]) ? f[sid] : 0;
      });
    }
    function getBlocklist() { return Promise.resolve(blockStore().get(BLOCK_KEY)).then(function (b) {
      if (!b) return { ids: {}, names: {} };
      // v0.90.18: a present-but-malformed blocklist used to fail OPEN silently (everyone
      // unblocked, no trace). Fail-open is kept (locking everyone out is worse) but LOUD —
      // the engine log wrapper escalates 'corrupt' lines to diag.errors + the panel.
      if (b.ids && b.names && typeof b.ids === 'object' && typeof b.names === 'object') return b;
      log('[chloe.store] blocklist is corrupt (expected {ids,names}), treating as empty until repaired — re-block anyone still restricted');
      return { ids: {}, names: {} };
    }); }
    function isBlockedSync(bl, id, name) {
      if (!bl) return false;
      if (id && bl.ids && bl.ids[String(id)]) return true;
      var ln = String(name || '').trim().toLowerCase();
      if (ln && bl.names && bl.names[ln]) return true;
      return false;
    }
    function blockUser(opts) {
      opts = opts || {};
      var id = opts.id ? String(opts.id) : null;
      var name = opts.name ? String(opts.name).trim() : null;
      if (!id && !name) return Promise.resolve({ ok: false, reason: 'need a user id or username to block' });
      // Re-read immediately before write to minimise stale-snapshot window (dict keys don't collide
      // for different users, so concurrent blocks of distinct users are safe either way).
      return getBlocklist().then(function (bl) {
        var meta = { at: clock.now(), by: opts.byModId || null, reason: opts.reason || null };
        if (id) bl.ids[id] = meta;
        if (name) bl.names[name.toLowerCase()] = meta;
        return Promise.resolve(blockStore().set(BLOCK_KEY, bl)).then(function () {
          // blocking also purges any memory that already formed
          if (id) return purge(id, { targetName: name || id }).then(function () { return { ok: true, value: { id: id, name: name } }; }, function () { return { ok: true, value: { id: id, name: name } }; });
          return { ok: true, value: { id: id, name: name } };
        });
      });
    }
    function unblockUser(opts) {
      opts = opts || {};
      var id = opts.id ? String(opts.id) : null;
      var name = opts.name ? String(opts.name).trim().toLowerCase() : null;
      return getBlocklist().then(function (bl) {
        var changed = false;
        if (id && bl.ids[id]) { delete bl.ids[id]; changed = true; }
        if (name && bl.names[name]) { delete bl.names[name]; changed = true; }
        return Promise.resolve(blockStore().set(BLOCK_KEY, bl)).then(function () { return { ok: changed, value: { id: id, name: name } }; });
      });
    }
    function listBlocked() { return getBlocklist(); }

    // ---- partition upsert (the per-user system of record) --------------------------------
    // B1: expand text attachments on live-poll messages into m.attachText.
    // Fail-open per file; old engines (no cfg.fetchAttachmentText) flow text-only.
    function expandAttachments(incoming) {
      if (typeof cfg.fetchAttachmentText !== 'function') return Promise.resolve(0);
      var chain = Promise.resolve(), expanded = 0;
      incoming.forEach(function (m) {
        chain = chain.then(function () {
          var list = selectAttachable(m && m.attachments);
          if (!list.length) return;
          var got = [];
          var fchain = Promise.resolve();
          list.forEach(function (f) {
            fchain = fchain.then(function () {
              return Promise.resolve(cfg.fetchAttachmentText(f)).then(function (r) {
                if (r && r.ok && r.value) { got.push({ filename: f.filename, text: String(r.value) }); expanded++; }
                else log('[chloe.attach] unreadable "' + f.filename + '" (' + ((r && r.reason) || 'no fetch') + ') — replying on text alone');
              }, function () { log('[chloe.attach] unreadable "' + f.filename + '" (fetch threw) — replying on text alone'); });
            });
          });
          return fchain.then(function () { if (got.length) m.attachText = formatAttachBlock(got); });
        });
      });
      return chain.then(function () { return expanded; });
    }
    function ingestOne(msg, ring, indexSet, touched) {      // permanent tombstone gate: a blocked author is invisible to ingestion forever
      return Promise.resolve(blockStore().get(BLOCK_KEY)).then(function (bl) {
        if (isBlockedSync(bl, msg.author.id, msg.author.username)) return null;
        // ethereal (GDPR): a forgotten user forms NO memory in this bucket — no partition, no roster,
        // no facts, no summary/episode contribution, no image tracking. Their live line still reaches
        // the reply path (it stays in `incoming`), so the bot can answer them; it just keeps no notes.
        return isEthereal(msg.author.id).then(function (eth) {
          if (eth) return null;
          // Forget-floor: even after `remember me`, never re-ingest a line from BEFORE the forget — on
          // ANY path (a cold-start startup batch replays recent history through here, not just
          // backfill). Live post-remember messages are always newer than the floor, so this never
          // blocks them; it only stops erased history resurfacing.
          return forgetFloorOf(msg.author.id).then(function (floor) {
            if (floor && toEpoch(msg.timestamp) < floor) return null;
            return ingestOneCore(msg, ring, indexSet, touched);
          });
        });
      });
    }
    function ingestOneCore(msg, ring, indexSet, touched) {
      // A returning "historical friend" is restored from cold storage so their history survives,
      // and a pre-upgrade per-channel partition is converged into the shared pool on the way
      // in (see loadPartition). Restore is independent of cfg.archiveStale: that flag controls
      // whether we *create* new archives, but if a cold copy already exists we must always
      // bring it back (otherwise toggling archiving off would strand returning users as empty
      // "new" partitions while their cold record lingers — a split-brain dual-pool state).
      return loadPartition(msg.author.id).then(function (existing) {
        // If they're not in the hot roster or archive, they could still be known from the mod log or
        // blocklist (a purged or moderated user). Resolve that BEFORE deciding "new" so we never greet
        // or prioritize a previously-seen person as a first-timer. Skip the lookup for the common case
        // (we already have them) to keep the hot path cheap.
        if (existing) return { existing: existing, knownElsewhere: null };
        return knownFromOtherSurfaces(msg.author.id, msg.author.username).then(function (k) {
          return { existing: null, knownElsewhere: k && k.known ? k : null };
        });
      }).then(function (res) {
        var existing = res.existing;
        var knownElsewhere = res.knownElsewhere;
        var now = clock.now();
        var seenAt = toEpoch(msg.timestamp);
        var p = existing || {
          id: msg.author.id,
          name: msg.author.username,
          firstSeen: seenAt,
          lastSeen: seenAt,
          interactionCount: 0,        // T0 never engages, so this stays 0 until T1
          state: 'active',            // spec 5.4 ladder; T0 only ever sets 'active'
          recent: []
        };
        var isNew = !existing && !knownElsewhere;   // truly new only if no surface (roster/archive/modlog/blocklist) knows them
        if (!existing && knownElsewhere) log('[chloe.T5] ' + (msg.author.username || msg.author.id) + ' is not new \u2014 known from ' + knownElsewhere.where + ' (treating as a returning user, not a first-timer)');
        var prevLastSeen = existing ? (existing.lastSeen || 0) : null;   // capture BEFORE we overwrite it
        if (existing) applyExpiry(p, now);   // T3: a timeout that has elapsed reverts to active
        // T5 decay: a return after a long quiet spell lets familiarity fade (warmth follows recency)
        if (existing && prevLastSeen && (now - prevLastSeen) >= cfg.decayAfterMs && (p.interactionCount || 0) > 0) {
          p.interactionCount = Math.max(0, Math.floor((p.interactionCount || 0) * cfg.decayFactor));
          if (cfg.relationshipTrust && p.trust) p.trust = Math.max(0, Math.floor(p.trust * (cfg.trustDecayFactor || 0.85)));   // absence cools trust too
          if (cfg.bondLadder && p.bond) { try { var bbd = makeBond({ state: p.bond }); bbd.decay(now); p.bond = bbd.serialize(); } catch (e) { log('[wire:bond] decay threw', (e && e.message) || e); } }   // item 3: absence gently cools the bond, CLAMPED to 60% of its tier floor (an old friend never becomes a stranger from silence)
        }
        p.lifecycle = 'active';              // any message reactivates; quiet/departed are set by maintenance
        p.name = msg.author.username || p.name;
        p.lastSeen = Math.max(p.lastSeen || 0, seenAt);
        if (!p.firstSeen) p.firstSeen = seenAt;
        // rolling window of THIS user's lines, shared cross-channel for regular channels
        // (observed facts only; no inferences hardened in). ch tags each line's home channel
        // so the reply transcript + rollups can stay channel-local while memory is global.
        // Eviction is signal-aware (smartTrimRecent), not FIFO: filler goes before substance.
        var seenIds = {}; p.recent = (p.recent || []).filter(function (ln) { var k = ln && String(ln.id); if (!ln || k === String(msg.id) || seenIds[k]) return false; seenIds[k] = true; return true; });
        p.recent.push({ id: msg.id, ts: seenAt, content: msg.content || '', ch: cfg.channelId });
        p.recent = smartTrimRecent(p.recent, cfg.recentWindow);
        lastLineId = msg.id;   // track newest line so `forget-that` (no reply/target) can drop it

        // speaker ring: dedup-consecutive distinct author ids, keep last N
        if (ring[ring.length - 1] !== msg.author.id) {
          ring.push(msg.author.id);
          if (ring.length > cfg.speakerRingSize) ring.shift();
        }
        indexSet[msg.author.id] = true;
        touched.users[msg.author.id] = true;
        if (cfg.ownAffect && msg.author.id !== cfg.botUserId) { affectOnUserMessage(); affectOnContent(msg.content); }   // engagement + novelty (fire-and-forget: tiny clamped writes)
        if (isNew) touched.newUsers[msg.author.id] = true;
        // T5 greeting signal (the tier is decided later, where suppression + commands are known)
        if (touched.greetInfo) touched.greetInfo[msg.author.id] = { brandNew: isNew, prevLastSeen: prevLastSeen, gapMs: prevLastSeen ? (now - prevLastSeen) : null, messageId: msg.id, name: p.name, trusted: !!(cfg.relationshipTrust && (p.trust || 0) >= cfg.trustPriorityTier) };

        return userStore().set(partKey(msg.author.id), p);
      });
    }

    // ---- one poll cycle ------------------------------------------------------------------
    // pollOnce wraps the core so the onPoll hook (page events + T5 maintenance) runs on EVERY
    // poll — the running loop calls pollOnce directly, so the hook must live here, not in a caller.
    // ---- run-lock --------------------------------------------------------------------------
    // ---- completion-driven dispatch ---------------------------------------------------------
    // Generation finished -> fire the next queued job as soon as the courtesy gap allows, via the
    // host-injected defer hook. Both targets fully self-gate (budget, cooldowns, flags), so a
    // deferred kick that finds nothing to do costs ~zero; the poll tick remains the backstop.
    // deferGen invalidates outstanding deferred work on stop() — a stopped/demoted engine's
    // scheduled chains become silent no-ops without coupling chaining to the poll-timer loop.
    var deferGen = 0;
    var textChainScheduled = false, imageChainScheduled = false;
    function scheduleTextChain() {
      if (typeof cfg.defer !== 'function' || textChainScheduled || !hasPendingReply()) return;
      textChainScheduled = true;
      var g = deferGen;
      var wait = Math.max(50, (cfg.globalCooldownMs || 0) - (clock.now() - lastActAt));
      // deferGen catches a clean demote; iHoldRunLock catches a freeze/thaw failover (deferGen
      // unchanged) where a successor queen now owns the channel — abandon rather than double-write.
      cfg.defer(function () { textChainScheduled = false; if (g === deferGen) iHoldRunLock().then(function (h) { if (h) processReply(); else log('[chloe.lock] deferred reply abandoned \u2014 another engine holds the run-lock now'); }); }, wait);
    }
    function scheduleImageChain() {
      if (typeof cfg.defer !== 'function' || imageChainScheduled || !paint.queue.length) return;
      imageChainScheduled = true;
      var g = deferGen;
      var wait = Math.max(50, (cfg.imageCooldownMs || 0) - (clock.now() - lastPaintAt));
      cfg.defer(function () { imageChainScheduled = false; if (g === deferGen) iHoldRunLock().then(function (h) { if (h) kickImage(); else log('[chloe.lock] deferred image abandoned \u2014 another engine holds the run-lock now'); }); }, wait);
    }
    // ---- commit-point revalidation (while-if-true) -------------------------------------------
    // Every multi-second generation captures its premises at START and commits at END — but the
    // world moves in between. Each slow path re-checks its premises at the moment of commitment
    // and ABANDONS cheaply instead of committing on stale state. The epoch (deferGen) doubles as
    // the engine-liveness check: stop()/demote bumps it, so an in-flight generation on a stopped
    // engine never commits (its successor owns the work via the pending-reply record).
    function revalidateReply(p, gen) {
      if (gen !== deferGen) return Promise.resolve({ why: 'engine stopped/demoted mid-generation — the successor owns this reply now', keepPending: true });
      // Freeze/thaw failover (deferGen unchanged): if a successor queen now holds the run-lock, do
      // NOT send — leave the pending-reply record so the successor's resume-once picks it up. This is
      // what stops a thawing ex-queen from double-replying and clobbering the shared reply state.
      return iHoldRunLock().then(function (holdLock) {
        if (!holdLock) return { why: 'another engine owns the channel (failover mid-generation) — leaving the reply for the successor', keepPending: true };
        var q2 = reply.queue[p.authorId];
        if (q2 && q2.messageId !== p.messageId) return { why: p.authorName + ' re-addressed with a newer message mid-generation — answering THAT instead', chain: true };
        if (engageMode === 'locked' && !isMod(p.authorId)) return { why: 'lockdown engaged mid-generation', lockAck: true };
        return Promise.resolve(userStore().get(partKey(p.authorId))).then(function (pp) {
          if (pp && pp.state && pp.state !== 'active') return { why: 'author was moderated mid-generation' };
          return null;
        });
      });
    }
    // Why-not indicators clear themselves (a stale ⏳ hours later would confuse more than help).
    function scheduleAckClear(messageId, emoji, ms) {
      if (typeof cfg.defer !== 'function' || !messageId) return;
      var g = deferGen;
      cfg.defer(function () { if (g === deferGen) clearAck(messageId, emoji); }, ms || cfg.ackClearMs || 30000);
    }
    // Typing keep-alive: Discord's indicator fades in ~10s; refresh while a generation is in flight.
    function keepTypingWhile(flagFn) {
      if (typeof cfg.defer !== 'function') return;
      var g = deferGen;
      cfg.defer(function tick() {
        if (g !== deferGen || !flagFn()) return;
        indicateTyping();
        cfg.defer(tick, cfg.typingRefreshMs || 8000);
      }, cfg.typingRefreshMs || 8000);
    }
    var RUNLOCK_KEY = 'runlock:' + cfg.channelId;
    var PENDING_KEY = 'pending-reply:' + cfg.channelId;   // Gap A: the reply currently being generated
    var runId = cfg.runLockId || ('run-' + Math.random().toString(36).slice(2, 10));
    var runLockSeq = 0, runLockSkips = 0;
    // Read-only "do I still legitimately hold the run-lock?" — used to guard the fire-and-forget
    // deferred chains (image/reply) and the long image-delivery commit, which run BETWEEN polls and
    // therefore outside acquireRunLock. Unlike acquireRunLock this never claims/renews, so a
    // thawing ex-queen calling it can't steal the lock from the live successor; it just learns it no
    // longer owns the channel and abandons the write. (Freeze leaves deferGen unchanged, so the
    // deferGen guard alone can't catch a frozen-then-thawed tab — this lock read does.)
    function iHoldRunLock() {
      if (cfg.runLock === false) return Promise.resolve(true);
      return Promise.resolve(store.get(RUNLOCK_KEY)).then(function (lk) {
        return !!(lk && lk.id === runId && (clock.now() - (lk.at || 0)) < (cfg.runLockTtlMs || 45000));
      }, function () { return false; });
    }
    function acquireRunLock() {
      if (cfg.runLock === false) return Promise.resolve(true);
      var now = clock.now();
      return Promise.resolve(store.get(RUNLOCK_KEY)).then(function (lk) {
        // a DIFFERENT live engine holds it -> we are the split-brain side; stand down this poll
        if (lk && lk.id && lk.id !== runId && (now - (lk.at || 0)) < (cfg.runLockTtlMs || 45000)) return false;
        // claim (or renew our own / take over a stale one), then READ BACK: two engines claiming a
        // stale lock in the same instant resolve to at most one proceeding (same trick as the tab lease)
        var n = runId + ':' + now + ':' + (++runLockSeq);
        return Promise.resolve(store.set(RUNLOCK_KEY, { id: runId, at: now, n: n })).then(function () {
          return Promise.resolve(store.get(RUNLOCK_KEY)).then(function (back) { return !!(back && back.n === n); });
        });
      });
    }
    // Gap A resumption: consume a dead predecessor's pending-reply record — verified, age-capped,
    // resume-once. Returns whether a reply was re-enqueued.
    function resumePendingReply() {
      if (cfg.replyResume === false) return Promise.resolve(false);
      return Promise.resolve(store.get(PENDING_KEY)).then(function (rec) {
        if (!rec || !rec.messageId) return false;
        return Promise.resolve(store.del(PENDING_KEY)).then(function () {   // consume FIRST: resume-once
          var now = clock.now();
          if (now - (rec.at || 0) > (cfg.replyResumeMaxAgeMs || 600000)) { log('[chloe.resume] found a lost reply but it is stale \u2014 dropping (a late answer is worse than silence)'); return false; }
          if (typeof cfg.recentFetch !== 'function') { log('[chloe.resume] found a lost reply but cannot verify against Discord \u2014 never resuming unverified'); return false; }
          return Promise.resolve(cfg.recentFetch(30)).then(function (msgs) {
            var answered = (msgs || []).some(function (m) { return m && m.author && m.author.id === cfg.botUserId && snowflakeCmp(m.id, rec.messageId) > 0; });
            if (answered) { log('[chloe.resume] a bot message exists after the target \u2014 assuming it was answered (no double-send)'); return false; }
            reply.queue[rec.authorId] = { messageId: rec.messageId, authorId: rec.authorId, authorName: rec.authorName, content: rec.content || '', at: rec.at, priority: rec.priority || 0 };
            log('[chloe.resume] resuming a reply a previous engine lost mid-generation (to ' + rec.authorName + ')');
            return true;
          }, function () { return false; });   // verification fetch failed -> conservative: no resume
        });
      });
    }
    function releaseRunLock() {
      return Promise.resolve(store.get(RUNLOCK_KEY)).then(function (lk) {
        if (lk && lk.id === runId) return Promise.resolve(store.del(RUNLOCK_KEY));
      }).catch(function (e) { log('[chloe.lock] run-lock release failed (' + ((e && e.message) || e) + ')'); });
    }
    function pollOnce() {
      return acquireRunLock().then(function (held) {
        if (!held) {
          runLockSkips++;
          if (runLockSkips === 1 || runLockSkips % 20 === 0) log('[chloe.lock] another engine instance holds the run-lock for this channel \u2014 skipping poll (skip #' + runLockSkips + '; this protects the shared cursor during a queen handover)');
          var summary = { ok: true, lockSkip: true };
          if (typeof cfg.onPoll === 'function') return Promise.resolve(cfg.onPoll(summary)).then(function () { return summary; }, function () { return summary; });
          return Promise.resolve(summary);
        }
        return pollOnceCore().then(function (summary) {
          if (typeof cfg.onPoll === 'function') return Promise.resolve(cfg.onPoll(summary)).then(function () { return summary; }, function () { return summary; });
          return summary;
        });
      });
    }
    function pollOnceCore() {
      // Per-channel gates (goldfish model): speakOn/memOn gate the output + memory lanes below;
      // read-off short-circuits the whole poll (no fetch, no writes, no brain) like a 404 pause.
      var speakOn = cfg.chanSpeak !== false, memOn = cfg.chanRemember !== false;
      if (cfg.chanRead === false) return Promise.resolve({ ok: true, gated: true, channelId: cfg.channelId, fetched: 0, ingested: 0, cursor: null });
      var ctx = {};
      return Promise.resolve(store.get(CURSOR_KEY)).then(function (cursor) {
        ctx.cursor = cursor || null;
        return transport.getMessagesAfter(cfg.channelId, ctx.cursor, 50);
      }).then(function (msgs) {
        msgs = (msgs || []).slice().sort(function (a, b) { return snowflakeCmp(a.id, b.id); });
        ctx.fetched = msgs.length;
        // drop the bot's own messages by id (spec 2.1)
        var incoming = msgs.filter(function (m) {
          return !(cfg.botUserId && m.author && m.author.id === cfg.botUserId);
        });
        // diagnostic: if messages arrive but all have empty content, the Message Content Intent is off
        if (!warnedEmpty && incoming.length) {
          var withText = 0; incoming.forEach(function (m) { if (String(m.content || '').trim()) withText++; });
          if (withText === 0) { warnedEmpty = true; log('[chloe] NOTE: ingested ' + incoming.length + ' message(s) with EMPTY content. If those messages had text, enable the Message Content Intent (Discord Dev Portal \u2192 Bot \u2192 Privileged Gateway Intents). Without that intent it can\u2019t read non-mention messages.'); }
        }
        // Startup backlog handling: on the first poll after start with no cursor (cold start / Reset
        // State), `incoming` can be a chunk of HISTORY. We must not replay historical actions from it.
        // But a fresh channel's first poll might just be a few genuinely-live messages — those should
        // be handled normally. So "backlog" = the batch is large enough to clearly be history, not a
        // live exchange. Below the threshold, treat it as normal live traffic.
        var imageEligible = null;
        var bigBacklog = incoming.length > (cfg.startupBacklogThreshold || 8);
        var isStartupBatch = startupPending && !ctx.cursor && bigBacklog;
        // v0.90.18: hoisted out of the startup branch — creditContinuation (feedback
        // learning) needs this batch's humans on EVERY poll; previously it only saw a
        // list on the rare startup batch and silently no-opped the rest of the time.
        var humans = incoming.filter(function (m) { return m.author && !m.author.bot && String(m.content || '').trim(); });
        if (isStartupBatch) {
          var keep = humans.slice(-(cfg.startupImageMax || 5));
          imageEligible = {};
          keep.forEach(function (m) { imageEligible[m.id] = true; });
          if (incoming.length > keep.length) log('[chloe.img] startup: image gen limited to the ' + keep.length + ' most-recent message(s) of a ' + incoming.length + '-message backlog');
        }
        startupPending = false;   // only the first poll after start gets the clamp
        // B1: fetch text-attachment bodies before ingest (speak-gated: with no
        // reply lane nothing consumes them; read-gate-off already returned).
        // Stored recent keeps original content; the block rides queue content.
        var attachP = speakOn ? expandAttachments(incoming) : Promise.resolve(0);
        return attachP.then(function (attachN) {
        return Promise.all([
          Promise.resolve(store.get(RING_KEY)),
          Promise.resolve(userStore().listIndex())
        ]).then(function (st) {
          var ring = st[0] || [];
          var indexArr = st[1] || [];
          var indexSet = {};
          indexArr.forEach(function (id) { indexSet[id] = true; });
          var touched = { users: {}, newUsers: {}, greetInfo: {} };

          // ingest sequentially to keep last-write-wins deterministic per user
          var chain = Promise.resolve();
          incoming.forEach(function (m) {
            // observation (always, ungated): track bot-vs-human flow for the loop damper. This runs
            // even for messages it won't reply to — it keeps watching the room either way.
            noteAuthorForLoop(!!(m.author && m.author.bot));
            // CAMPAIGN item 1: feed the converse ganglion the SAME stream so its damper + two-person + anti-repeat
            // track from the real poll. Gated by converseEngine so OFF never touches it (byte-identical). Rule-X: a
            // DEAD observe wire = the damper never engages, so this is the wire the integration harness forces.
            if (converse && cfg.converseEngine && m && m.author) {
              try { converse.observe({ id: m.author.id, name: m.author.username || '', text: m.content || '', ts: (snowflakeTime(m.id) || clock.now()), self: false, bot: !!m.author.bot }); }
              catch (e) { log('[wire:converse] observe threw', (e && e.message) || e); }
            }
            chain = chain.then(function () { return ingestOne(m, ring, indexSet, touched); });
            if (!isStartupBatch) chain = chain.then(function () { return processMessageReactions(m); });   // size-relative reaction significance (not on the history backlog)
          });

          return chain.then(function () {
            // advance cursor to the newest id we saw (even bot's own, so we don't re-fetch it)
            var newCursor = ctx.cursor;
            msgs.forEach(function (m) { newCursor = maxSnowflake(newCursor, m.id); });
            if (newCursor) { var st = snowflakeTime(newCursor); if (st) lastSeenAt = Math.max(lastSeenAt, st); }   // ground time on Discord's authoritative message clock

            // channel rhythm: track last activity + a coarse gap average
            return Promise.resolve(store.get(RHYTHM_KEY)).then(function (rh) {
              rh = rh || { lastActivity: null, avgGapMs: null, samples: 0 };
              if (incoming.length) {
                var now = clock.now();
                if (rh.lastActivity != null) {
                  var gap = now - rh.lastActivity;
                  // pace core: mean (EWMA, alpha 0.3) AND deviation (EWMA, beta) — the Jacobson pair,
                  // mirroring the brain meter. gapVar feeds rhythm-relative debounce + quiet z-scores.
                  var dev = Math.abs(gap - (rh.avgGapMs == null ? gap : rh.avgGapMs));
                  rh.gapVarMs = rh.gapVarMs == null ? Math.round(dev) : Math.round(rh.gapVarMs * (1 - (cfg.paceGapBeta || 0.25)) + dev * (cfg.paceGapBeta || 0.25));
                  rh.avgGapMs = rh.avgGapMs == null ? gap : Math.round(rh.avgGapMs * 0.7 + gap * 0.3);
                  rh.samples++;
                }
                rh.lastActivity = now;
              }

              // G6: blend this batch's human-message tenor into the decayed mood (front-end, no AI)
              var humanTexts = (cfg.moodAware && incoming.length)
                ? incoming.filter(function (m) { return m.author && !m.author.bot; }).map(function (m) { return m.content || ''; })
                : [];

              var writes = [
                store.set(RING_KEY, ring),
                store.set(RHYTHM_KEY, rh),
                userStore().setIndex(Object.keys(indexSet))
              ];
              if (newCursor && newCursor !== ctx.cursor) writes.push(store.set(CURSOR_KEY, newCursor));
              writes.push(rescanReactionModes(incoming));   // reacted-history sweep rides the writes (resolves before the summary + text lane)
              if (humanTexts.length) writes.push(updateMood(humanTexts, rh.avgGapMs));
              if (cfg.feedbackLearning) writes.push(creditContinuation(humans));   // DESIGN-feedback: people who kept talking after its reply
              // conversation memory: record HER OWN messages (the ones Discord echoes back, which we drop
              // from `incoming`) into a per-channel ring, with their real snowflake timestamps, so the
              // transcript it reads later is two-sided. Each own message is fetched exactly once (the
              // cursor advances past it), so appending can't double-count.
              if (cfg.conversationMemory && cfg.botUserId) {
                var ownNew = msgs.filter(function (m) { return m.author && m.author.id === cfg.botUserId && String(m.content || '').trim(); });
                if (ownNew.length) {
                  // newsInContext false (default): own 📰 rollups stay OUT of the reply
                  // transcript (up to 1900 chars of headlines+links would eat the context
                  // budget and get parroted back into chat). They redirect into Thoughts
                  // instead (newsMarkerLine). Conversational own-replies are unaffected.
                  // true restores the classic two-sided behavior. Matching is signature-
                  // based (newsOwnSig) so the Links gate stripping URLs at send time can't
                  // break it; the sent ring also bounds + expires the match set.
                  var ownGate = (cfg.newsInContext === true)
                    ? Promise.resolve(null)
                    : Promise.resolve(store.get(NEWS_KEY)).then(function (ns) {
                        var sigs = {};
                        ((ns && Array.isArray(ns.sent)) ? ns.sent : []).forEach(function (s) { if (s && s.sig) sigs[s.sig] = true; });
                        return sigs;
                      }, function () { return null; });
                  writes.push(ownGate.then(function (sigs) {
                    var keep = sigs ? ownNew.filter(function (m) { return !sigs[newsOwnSig(m.content)]; }) : ownNew;
                    if (!keep.length) return null;
                    return Promise.resolve(store.get(OWNLINE_KEY)).then(function (own) {
                      own = Array.isArray(own) ? own : [];
                      keep.forEach(function (m) { own.push({ text: String(m.content).slice(0, 400), ts: snowflakeTime(m.id) || clock.now() }); });
                      if (own.length > (cfg.ownLinesMax || 12)) own = own.slice(-(cfg.ownLinesMax || 12));
                      return store.set(OWNLINE_KEY, own);
                    });
                  }));
                }
              }

              return Promise.all(writes).then(function () {
                var summary = {
                  fetched: ctx.fetched,
                  ingested: incoming.length,
                  newUsers: Object.keys(touched.newUsers),
                  cursor: newCursor,
                  ring: ring.slice(),
                  rhythm: rh,
                  botTurns: consecutiveBotTurns
                };
                log('[chloe.T0] poll', summary.fetched + ' fetched, ' + summary.ingested +
                  ' ingested, ' + summary.newUsers.length + ' new, cursor=' + summary.cursor);
                if (attachN) { summary.attachments = attachN; log('[chloe.attach] expanded ' + attachN + ' text file(s) this poll'); }
                return processCommandsAndSelect(incoming, touched, imageEligible, isStartupBatch).then(function (t3) {
                  if (t3 && t3.commands) summary.commands = t3.commands;
                  if (t3 && t3.channelLangTouched) { summary.channelLangTouched = true; summary.channelLang = t3.channelLang || null; }   // v0.90.21: queen persists (onPoll)
                  if (t3 && t3.actPolicyTouched) { summary.actPolicyTouched = true; summary.actPolicy = t3.actPolicy; }   // A1/A4: queen persists (onPoll)
                  if (t3 && t3.actGrantsTouched) { summary.actGrantsTouched = true; summary.actGrants = t3.actGrants; }
                  if (t3 && t3.modListTouched && Array.isArray(t3.modList)) { summary.modListTouched = true; summary.modList = t3.modList; }   // A7: a !chloe elevate/demote/undo changed it
                  if (t3 && t3.beatsTouched && (t3.beats === null || Array.isArray(t3.beats))) { summary.beatsTouched = true; summary.beats = t3.beats; }   // A8: queen persists (onPoll)
                  if (t3 && t3.autoModRulesTouched && (t3.autoModRules === null || Array.isArray(t3.autoModRules))) { summary.autoModRulesTouched = true; summary.autoModRules = t3.autoModRules; }
                  if (t3 && t3.procRulesTouched && (t3.procRules === null || Array.isArray(t3.procRules))) { summary.procRulesTouched = true; summary.procRules = t3.procRules; }
                  if (t3 && t3.quarantineTouched) { summary.quarantineTouched = true; summary.quarantine = t3.quarantine; }   // A8: re-hold released/dropped sets
                  var imageJob = speakOn ? kickImage() : null;   // fire-and-forget: image broker threads with text; never blocks the loop
                  if (imageJob) summary.imageJob = imageJob;
                  summary.engageMode = engageMode;
                  // Due reminders fire first — they're front-end-only and time-critical, so they
                  // shouldn't wait behind a slow generation. (Promise resolves fast; AI-free.)
                  var reminderJob = (speakOn && memOn ? processReminders() : Promise.resolve(null)).then(function (rr) { if (rr && rr.fired) summary.reminders = rr.fired; });
                  // The text lane (reply -> volunteer -> greet -> beat) is one promise. By default it's
                  // awaited so the poll resolves only once it's done (every harness relies on this). With
                  // backgroundText on, it's fire-and-forget (exposed as summary.textJob) so a long
                  // generation never stalls the poll loop — the per-lane locks still prevent overlap.
                  var textLane = reminderJob.then(function () { return speakOn ? processReply() : null; }).then(function (replied) {
                    if (replied) summary.replied = replied;
                    return speakOn ? processGate() : null;
                  }).then(function (acted) {
                    if (acted) summary.volunteered = acted;
                    return speakOn ? processGreet() : null;
                  }).then(function (greeted) {
                    if (greeted) summary.greeted = greeted;
                    return speakOn ? processBeats() : null;
                  }).then(function (beat) {
                    if (beat) summary.beat = beat;
                    return speakOn ? processLull() : null;
                  }).then(function (lull) {
                    if (lull) summary.lull = lull;
                    return speakOn ? processCheckin() : null;
                  }).then(function (checkin) {
                    if (checkin) summary.checkin = checkin;
                    // F2 news lane: deterministic (no AI), own cadence per feed — runs
                    // outside the one-AI-pass ladder above. speakOn: its voice, its
                    // channel. memOn not required (a rollup is output, not memory).
                    return speakOn ? processNews(false).then(function (nr) { if (nr && nr.feeds) summary.news = nr.feeds; return null; }) : null;
                  }).then(function (news) {
                    // AI-cadence floor (pace core): adaptive polling makes "every N polls" a variable
                    // wall-clock time; a fast room would over-run these AI passes. aiPassDue gates each
                    // on its poll cadence AND a minimum wall-clock interval since it last ran.
                    function aiPassDue(name, cadenceOk) {
                      if (!cadenceOk) return false;
                      if (!cfg.adaptivePace || !paceReady()) return true;   // floor only engages once rhythm is established (else: exactly today's every-N-polls)
                      var now2 = clock.now(), last2 = paceLastAI[name] || 0;
                      return (now2 - last2 >= (cfg.paceMinAIIntervalMs || 90000));   // TEST only; the chosen pass records via markRan
                    }
                    function markRan(name) { paceLastAI[name] = clock.now(); }   // stamp the pass that actually ran
                    // One gated AI pass per poll. Collect the DUE candidates in priority order (each
                    // with its run thunk + a base priority), then let the attention manager pick which
                    // one runs (DESIGN-attention.md). attentionManager OFF -> candidates[0] (this exact
                    // order); ON -> utility-scored, but base dominates so neutral signals == this order.
                    // Load-gated rollups: the summary/episode timers are backstops — the bucket (transcript
                    // lines newer than the last rollup) must be non-empty or the timer doesn't fire, and a
                    // full bucket forces an early pass. First-ever run still waits for the timer.
                    var sumTimer = cfg.channelSummaryEveryPolls > 0 && (pollCount % cfg.channelSummaryEveryPolls) === (cfg.channelSummaryEveryPolls - 1);
                    var epiTimer = cfg.episodeEveryPolls > 0 && (pollCount % cfg.episodeEveryPolls) === (cfg.episodeEveryPolls - 1);
                    var full = Math.max(1, cfg.rollupFullLines || 20);
                    return rollupFreshness().then(function (fr) {
                    var sumEarly = fr.sumAt > 0 && fr.freshSum >= full;
                    var epiEarly = fr.epiAt > 0 && fr.freshEpi >= full;
                    var cands = [];
                    if (memOn && cfg.factMemory && aiPassDue('facts', cfg.factEveryPolls > 0 && (pollCount % cfg.factEveryPolls) === 0))
                      cands.push({ name: 'facts', base: 60, run: function () { return processFacts(); } });
                    if (memOn && cfg.channelSummary && fr.freshSum > 0 && aiPassDue('summary', sumTimer || sumEarly))
                      cands.push({ name: 'summary', base: 50, run: function () { return processChannelSummary().then(function (cs) { if (!cs) return null; summary.channelSummary = true; summary._sumText = cs; return postThoughtsFeed(cs).then(function (posted) { if (posted && posted.thoughts) summary.thoughtsPosted = posted.thoughts; if (posted && posted.feed) summary.thoughtsFeed = posted.feed; return null; }); }); } });
                    if (memOn && cfg.reflection && aiPassDue('reflect', cfg.reflectionEveryPolls > 0 && (pollCount % cfg.reflectionEveryPolls) === (cfg.reflectionEveryPolls - 1)))
                      cands.push({ name: 'reflect', base: 40, run: function () { return processReflection().then(function (ref) { if (ref) summary.reflected = ref.name; return null; }); } });
                    if (memOn && cfg.episodicMemory && fr.freshEpi > 0 && aiPassDue('episodes', epiTimer || epiEarly))
                      cands.push({ name: 'episodes', base: 30, run: function () { return processEpisodes().then(function (ep) { if (ep) summary.episodes = ep; return null; }); } });
                    if (memOn && cfg.idleConsolidation && cfg.consolidateEveryPolls > 0 && (pollCount % cfg.consolidateEveryPolls) === (cfg.consolidateEveryPolls - 1))
                      cands.push({ name: 'consolidate', base: 20, run: function () { return channelIsIdle().then(function (idle) { if (!idle) return null; return consolidateStructural().then(function () { return consolidateSemantic(); }).then(function (sem) { if (sem) summary.consolidated = sem.name; return null; }); }); } });
                    if (memOn && cfg.idleDeliberation)
                      cands.push({ name: 'deliberate', base: 10, run: function () { return deliberate().then(function (d) { if (d) summary.deliberated = d.type; return null; }); } });
                    if (cands.length) {
                      // gather signals only when the manager is on (otherwise we just take candidates[0])
                      if (!cfg.attentionManager) { markRan(cands[0].name); return runAiPassTracked(cands[0]); }
                      return attentionSignals().then(function (sig) {
                        var chosen = chooseAttention(cands, sig) || cands[0];
                        markRan(chosen.name);   // only the pass that actually runs resets its cadence floor + staleness
                        return runAiPassTracked(chosen);
                      });
                    }
                    if (memOn && cfg.ownAffect) return affectTick().then(function () { return null; });   // not an AI pass; cheap ignored-check
                    return null;
                    });
                  }).then(function (facts) {
                    if (facts) summary.facts = facts;
                    return checkPollExpiry();   // unconditional per-poll: lazy poll auto-close (one cheap store read, outside the one-AI-pass ladder)
                  });
                  function finishPoll() {
                    pollCount++;
                    var tail = refreshPace().then(function () { return summary; });   // pace core: refresh the rhythm cache once per poll
                    if (memOn && cfg.workingMemory) { tail = tail.then(function () { return workSync(summary._sumText || null).then(function (w) { if (w && (w.topic || (w.participants && w.participants.length))) summary.workspace = { topic: w.topic, participants: (w.participants || []).length }; return summary; }); }); }
                    if (memOn && cfg.workingMemory) {   // record its notable actions this poll into the workspace decision ring
                      var did = [];
                      if (summary.replied) did.push('replied to ' + summary.replied);
                      if (summary.volunteered) did.push('spoke up unprompted');
                      if (summary.greeted) did.push('greeted ' + summary.greeted);
                      if (did.length) tail = tail.then(function () { var c = Promise.resolve(); did.forEach(function (d) { c = c.then(function () { return noteDecision(d); }); }); return c.then(function () { return summary; }); });
                    }
                    var sweepDueByCadence = cfg.reactionSweepEveryPolls > 0 && (pollCount % cfg.reactionSweepEveryPolls) === 0;
                    var sweepDueByActivity = lastPollIngested;   // reactions cluster seconds after fresh messages
                    lastPollIngested = (summary.ingested || 0) > 0;
                    if (memOn && cfg.reactionTracking && (sweepDueByCadence || sweepDueByActivity)) {
                      tail = tail.then(function () { return reactionSweep().then(function (n) { if (n) { summary.reactionSweep = n; log('[chloe.react] sweep scored ' + n + ' message(s)'); } return summary; }); });
                    }
                    if (memOn && cfg.maintenanceEveryPolls > 0 && (pollCount % cfg.maintenanceEveryPolls) === 0) {
                      tail = tail.then(function () { return quietSweep().then(function (n) { if (n) { summary.quieted = n; log('[chloe.T5] quiet-sweep demoted ' + n + ' user(s)'); } if (quietSweep._archived) { summary.archived = quietSweep._archived; log('[chloe.archive] archived ' + quietSweep._archived + ' long-cold user(s)'); } return summary; }); });
                    }
                    return tail;
                  }
                  if (cfg.backgroundText) { summary.textJob = textLane; return finishPoll(); }
                  return textLane.then(finishPoll);
                });
              });
            });
          });           // end chain.then (ingest sweep)
        });             // end Promise.all(ring/index).then
        });             // end attachP.then (B1 attachment expansion)
      });               // end .then(msgs: fetched batch)
    }

    // ---- T1 reply path -------------------------------------------------------------------
    // Called at the end of every poll. Serves the per-author reply queue: a light global gap
    // keeps it from flooding, while a per-author cooldown keeps one person from monopolizing
    // it — so a different user is answered promptly even if it just replied to someone else.
    function processReply() {
      // Self-rescue: a brain/send promise that never settles would otherwise hold the single
      // reply lock forever (ack with no reply, then silence). Reclaim it loudly; the queue is
      // kept so the next poll retries. A late-settling promise still sends (better late than
      // silent) unless its epoch was superseded — see dropReplyLock(claimEpoch) below.
      var nowRs = clock.now();
      if (reply.replying && (nowRs - (reply.startedAt || 0)) > (cfg.replyStallMs || 240000)) {
        log('[chloe.T1] self-rescue: reply lock stuck for ' + Math.round((nowRs - (reply.startedAt || 0)) / 1000) + 's — clearing it so the next reply can go through');
        reply.replying = false; reply.epoch++;
        sweepLaneClaims('reply-lock watchdog');
        if (typeof cfg.releaseSend === 'function') { try { cfg.releaseSend('text'); } catch (eRs) {} }
        try { Promise.resolve(store.del(PENDING_KEY)).catch(function () {}); } catch (eRs2) {}
      }
      if (!replyEnabled() || reply.replying || !hasPendingReply()) return Promise.resolve(null);
      var now = clock.now();
      if (now - lastActAt < cfg.globalCooldownMs) return Promise.resolve(null);   // light per-channel gap
      // bot-loop damper: in a bot-only ping-pong, decay its chance of replying toward zero so two
      // bots don't feed each other forever. A human message reset consecutiveBotTurns to 0 already.
      var chance = botLoopReplyChance();
      if (chance < 1) {
        var roll = (typeof cfg.random === 'function' ? cfg.random() : Math.random());
        if (roll >= chance) {
          if (consecutiveBotTurns && (consecutiveBotTurns % 4 === 0)) log('[chloe.loop] holding back in bot-only chatter (' + consecutiveBotTurns + ' bot turns, chance=' + chance.toFixed(2) + ')');
          return Promise.resolve(null);
        }
      }
      // choose the highest-PRIORITY queued author who has settled (debounce) and is past their
      // per-author cooldown; ties break to the oldest (so a burst of equal-priority pings is FIFO).
      // Priority ranks mods > @-pings > new-user pings > casual name-drops (see replyPriority).
      var p = null;
      Object.keys(reply.queue).forEach(function (id) {
        var e = reply.queue[id];
        // Cooldown feedback FIRST and independent of debounce: if it answered this person recently,
        // the wait is real (seconds), so tell them now (⏳) rather than leaving confusing silence that
        // reads as being ignored or "re-read". Checked before the debounce early-return.
        if (now - (lastReplyAt[id] || 0) < cfg.cooldownMs) {            // per-author cooldown
          if (!e.throttleAcked) { e.throttleAcked = true; ackWorking(e.messageId, cfg.ackThrottleEmoji); scheduleAckClear(e.messageId, cfg.ackThrottleEmoji); }   // ⏳ why it's not answering yet
          return;
        }
        if (now - e.at < currentDebounce()) return;                     // still bursting (rhythm-relative)
        var ep = e.priority || 0;
        if (!p) { p = e; return; }
        var pp = p.priority || 0;
        if (ep > pp || (ep === pp && e.at < p.at)) p = e;
      });
      if (!p) return Promise.resolve(null);
      // Cross-channel budget ("one voice"), now priority-aware: a DM (high priority) can claim the
      // shared slot ahead of a regular channel, so DMs are answered first. Checked AFTER selection so
      // we know the winner's priority. Claimed NOW (before the multi-second generation); released if
      // nothing comes back.
      if (typeof cfg.canSend === 'function' && !cfg.canSend('text', p.priority || 0)) {
        if (!p.throttleAcked) { p.throttleAcked = true; ackWorking(p.messageId, cfg.ackThrottleEmoji); scheduleAckClear(p.messageId, cfg.ackThrottleEmoji); }   // ⏳ the shared voice is busy elsewhere
          log('[chloe.T1] reply to ' + p.authorName + ' throttled (send slot busy), staying queued');
        return Promise.resolve(null);
      }
      if (typeof cfg.noteSend === 'function') cfg.noteSend('text', p.priority || 0);
      delete reply.queue[p.authorId];
      reply.replying = true; reply.startedAt = clock.now(); var claimEpoch = reply.epoch;
      var genEpoch = deferGen;   // commit-point revalidation: premises re-checked before the send
      indicateTyping();
      keepTypingWhile(function () { return reply.replying; });
      if (p.throttleAcked) clearAck(p.messageId, cfg.ackThrottleEmoji);   // your turn came: ⏳ hands over
      reply.claim = { messageId: p.messageId, emoji: cfg.ackWorkingEmoji };
      ackWorking(p.messageId, cfg.ackWorkingEmoji);   // 🗣️ — generating your reply right now
      // Gap A: persist what we're answering, so a successor can resume if this engine dies mid-
      // generation. Cleared at EVERY terminal below (empty, sent, error).
      var pendingRec = (cfg.replyResume === false) ? Promise.resolve(null)
        : Promise.resolve(store.set(PENDING_KEY, { messageId: p.messageId, authorId: p.authorId, authorName: p.authorName, content: p.content || '', priority: p.priority || 0, at: clock.now(), runId: runId })).catch(function () { return null; });
      return pendingRec.then(function () { return assembleContext(p); })
        .then(function (ctx) {
          if (ctx && ctx.contextTokens != null) log('[chloe.ctx] packed ' + (ctx.channelRecent ? ctx.channelRecent.length : 0) + ' lines (~' + ctx.contextTokens + ' tok' + (ctx.contextDropped ? ', ' + ctx.contextDropped + ' older dropped' : '') + '); whole request ~' + (ctx.requestTokensEst || ctx.contextTokens) + '/' + (cfg.requestTokenBudget || 5000) + ' tok');
          return reactRespond(ctx, p);   // item 2: first respond + at most ONE search-and-re-respond round; returns the FINAL reply
        })
        .then(function (r) {
          var text = (r && r.ok) ? hygiene(String(r.value || '').trim()) : '';
          var intent = null;   // ADV-A3 defense-in-depth: INTENT persistence was a covert-injection vector (a Discord msg could plant a hidden standing-intention that later guided replies); it is removed page-side, and the engine now IGNORES any intent a (possibly forged / direct-postMessage) result carries so it can never be revived.
          if (!text) {
            // GAP FIX (item 2): a tool-ONLY reply (no prose) strips to empty text. If it carried action tools,
            // still RUN them before bailing — otherwise a bare `tool: remindme {...}` turn would do nothing.
            // (A query-tool-only reply was already turned into a prose 2nd reply by reactRespond, so it won't be empty.)
            if (cfg.toolsEnabled && r && Array.isArray(r.toolCalls) && r.toolCalls.length) { log('[wire:react] tool-only reply (no prose) -> dispatching its action tools, nothing to post'); dispatchModelTools(r, p); }
            dropReplyLock(claimEpoch);
            clearAck(p.messageId, cfg.ackWorkingEmoji);
            if (typeof cfg.releaseSend === 'function') cfg.releaseSend('text');   // generation produced nothing; give the budget back
            log('[chloe.T1] no reply to ' + p.authorName + ': ' + ((r && r.reason) ? r.reason : 'empty generation'));
            scheduleTextChain();
            return Promise.resolve(store.del(PENDING_KEY)).then(function () { return null; });
          }
          return revalidateReply(p, genEpoch).then(function (stale) {
            if (stale) {
              dropReplyLock(claimEpoch);
              clearAck(p.messageId, cfg.ackWorkingEmoji);
              if (stale.lockAck) { ackWorking(p.messageId, cfg.ackLockdownEmoji); scheduleAckClear(p.messageId, cfg.ackLockdownEmoji); }
              if (typeof cfg.releaseSend === 'function') cfg.releaseSend('text');
              log('[chloe.abandon] reply not sent — ' + stale.why);
              if (stale.chain) scheduleTextChain();   // answer the NEWER message at generation speed
              if (stale.keepPending) return null;     // leave the pending record: resume-once belongs to the successor
              return Promise.resolve(store.del(PENDING_KEY)).then(function () { return null; });
            }
            return Promise.resolve(cfg.send(cfg.channelId, text, Object.assign({ toUser: p.authorId }, (cfg.replyReference !== false && p.messageId) ? { replyTo: p.messageId } : {}))).then(function () {
            var t = clock.now();
            lastActAt = t; lastReplyAt[p.authorId] = t;
            var lrKeys = Object.keys(lastReplyAt);   // bound the per-author map (in-memory leak class)
            if (lrKeys.length > 300) { lrKeys.sort(function (a, b) { return lastReplyAt[a] - lastReplyAt[b]; }).slice(0, 50).forEach(function (k) { delete lastReplyAt[k]; }); }
            dropReplyLock(claimEpoch);
            clearAck(p.messageId, cfg.ackWorkingEmoji);
            rememberReply(text);
            dispatchModelTools(r, p);   // model tool-loop: fire any safe tools the brain emitted (page already stripped them from `text`); fail-open, whitelist-gated
            if (cfg.feedbackLearning) {   // DESIGN-feedback: remember this reply's style, awaiting a continuation/reaction signal
              lastReplyStyle = styleOf(text);
              fbPending.push({ style: lastReplyStyle, who: p.authorId, at: clock.now(), done: false });
              if (fbPending.length > (cfg.feedbackPendingMax || 12)) fbPending = fbPending.slice(-(cfg.feedbackPendingMax || 12));
            }
            log('[chloe.T1] replied to ' + p.authorName);
            scheduleTextChain();   // completion-driven: the next queued reply fires at generation speed, not poll speed
            return Promise.resolve(store.del(PENDING_KEY)).then(function () { return intent ? setIntent(intent) : null; }).then(function () {
              return bumpInteraction(p.authorId).then(function () { return text; });
            });
          });
          });
        })
        .catch(function (e) { dropReplyLock(claimEpoch); clearAck(p.messageId, cfg.ackWorkingEmoji); if (typeof cfg.releaseSend === 'function') cfg.releaseSend('text'); log('[chloe.T1] reply error:', (e && e.message) || e); scheduleTextChain(); return Promise.resolve(store.del(PENDING_KEY)).then(function () { return null; }, function () { return null; }); });
    }

    // ---- image path ----------------------------------------------------------------------
    // The page owns generation (only it can run text-to-image), so we hand it the prompt and
    // get back a data URL; the userscript posts it as a native attachment. Gated by its own
    // heavy cooldown (~14s gen) plus the shared global gap. On failure it says so in text
    // rather than leaving the request hanging.
    // ---- image lane (threaded) -----------------------------------------------------------
    // Image generation runs on a SEPARATE Perchance broker from text, so it threads with replies:
    // kickImage() is fire-and-forget — it never blocks the poll loop or a text reply. One image is
    // in flight at a time (paint.painting); the rest wait in the global FIFO (paint.queue) and drain
    // at generation pace. Timing is governed only by the image clock (lastPaintAt) — never the text
    // clock — so a long reply and an image proceed independently. Returns the in-flight job (so the
    // poll can surface it and harnesses can await it); callers do NOT await it in the poll chain.
    function kickImage() {
      // Self-rescue (paint side): same stuck-lock reclaim as the reply path.
      var nowRsI = clock.now();
      if (paint.painting && (nowRsI - (paint.startedAt || 0)) > (cfg.paintStallMs || 300000)) {
        log('[chloe.img] self-rescue: paint lock stuck for ' + Math.round((nowRsI - (paint.startedAt || 0)) / 1000) + 's — clearing it so the next image can go through');
        paint.painting = false;
        sweepLaneClaims('paint-lock watchdog');
        if (typeof cfg.releaseSend === 'function') { try { cfg.releaseSend('image'); } catch (eRsI) {} }
      }
      if (!imageEnabled() || paint.painting || !paint.queue.length) return null;
      var now = clock.now();
      if (now - paint.queue[0].at < currentDebounce()) return null;       // head still settling (rhythm-relative)
      if (now - lastPaintAt < cfg.imageCooldownMs) return null;           // courtesy gap (image clock only)
      if (typeof cfg.canSend === 'function' && !cfg.canSend('image')) return null;   // cross-channel global image budget
      var p = paint.queue.shift(); paint.painting = true; paint.startedAt = clock.now();
      var paintEpoch = deferGen;   // commit-point revalidation: ~14-60s of generation is the longest stale window in the system
      if (typeof cfg.noteSend === 'function') cfg.noteSend('image');      // claim the global image slot at start
      if (p.ackEmoji) { clearAck(p.messageId, p.ackEmoji); p.ackEmoji = null; }   // drop its queue-number
      paint.claim = { messageId: p.messageId, emoji: cfg.ackImageEmoji };
      ackWorking(p.messageId, cfg.ackImageEmoji);                        // instant "painting…" ack on the request
      keepTypingWhile(function () { return paint.painting; });
      renumberQueue();                                                   // the rest of the line ticks down a place
      indicateTyping();
      log('[chloe.img] painting for ' + p.authorName + ' (' + paint.queue.length + ' more queued): "' + p.prompt.slice(0, 60) + '" (' + p.resolution + (p.dm ? ', dm' : '') + ')');
      var paintArgs = { prompt: p.prompt, resolution: p.resolution };
      if (p.guidanceScale != null) paintArgs.guidanceScale = p.guidanceScale;
      if (p.removeBackground) paintArgs.removeBackground = true;
      var job = Promise.resolve(cfg.paint(paintArgs))
        .then(function (r) {
          var dataUrl = (r && r.ok) ? String(r.value || '') : '';
          if (dataUrl.indexOf('data:') !== 0) {
            paint.painting = false; paint.claim = null; scheduleImageChain(); lastPaintAt = clock.now();
            clearAck(p.messageId, cfg.ackImageEmoji);
            if (typeof cfg.releaseSend === 'function') cfg.releaseSend('image');
            log('[chloe.img] no image for ' + p.authorName + ': ' + ((r && r.reason) ? r.reason : 'empty result'));
            return Promise.resolve(cfg.send(cfg.channelId, 'sorry ' + p.authorName + ", I couldn't make that image just now.")).then(function () { return null; }, function (e) { log('[chloe.img] apology send failed (' + ((e && e.message) || e) + ')'); return null; });
          }
          // revalidate before delivery: were they moderated, the engine stopped, or did another
          // engine take over the channel (freeze/thaw failover) mid-paint? Any of these -> abandon.
          return Promise.resolve(userStore().get(partKey(p.authorId))).then(function (pp2) {
           return iHoldRunLock().then(function (holdLock) {
            if (paintEpoch !== deferGen || !holdLock || (pp2 && pp2.state && pp2.state !== 'active')) {
              paint.painting = false; paint.claim = null; lastPaintAt = clock.now(); scheduleImageChain();
              clearAck(p.messageId, cfg.ackImageEmoji);
              if (typeof cfg.releaseSend === 'function') cfg.releaseSend('image');
              log('[chloe.abandon] image not delivered — ' + (paintEpoch !== deferGen ? 'engine stopped mid-paint' : (!holdLock ? 'another engine owns the channel (failover mid-paint)' : p.authorName + ' was moderated mid-paint')));
              return null;
            }
          var target = Promise.resolve(cfg.channelId);
          if (p.dm && typeof cfg.openDM === 'function') {
            target = Promise.resolve(cfg.openDM(p.authorId)).then(function (id) { return id || cfg.channelId; }, function () { return cfg.channelId; });
          }
          return target.then(function (chId) {
            var promptCap = sanitizePromptForCaption(p.prompt, 220);
            var lead = p.dm ? ('here you go, ' + p.authorName + ' \u2014 ') : ('here you go, ' + p.authorName + '! ');
            var caption = lead + (promptCap ? ('\u201c' + promptCap + '\u201d') : '');
            return Promise.resolve(cfg.sendImage(chId, dataUrl, caption)).then(function () {
              lastPaintAt = clock.now(); paint.painting = false; paint.claim = null; scheduleImageChain();          // image clock only — do NOT touch lastActAt
              clearAck(p.messageId, cfg.ackImageEmoji);
              log('[chloe.img] delivered to ' + p.authorName + (p.dm ? ' (dm)' : ''));
              return recordImage(p.authorId, p).then(function () {
                if (cfg.imageEnhanceOffer && !p.isEdit && !/\b(detailed|hd|4k|high quality)\b/i.test(p.prompt || '')) {
                  try { Promise.resolve(cfg.send(cfg.channelId, 'want me to refine that, ' + p.authorName + '? just say how \u2014 e.g. \u201cmore detailed\u201d, \u201cmake it landscape\u201d, or \u201canother one\u201d.')).catch(function (e) { log('[chloe.img] refine offer skipped (' + ((e && e.message) || e) + ')'); }); } catch (e) { log('[chloe.img] refine offer skipped (' + ((e && e.message) || e) + ')'); }
                }
                return bumpInteraction(p.authorId);
              }).then(function () { return { image: true, to: p.authorId }; });
            }, function (e) { paint.painting = false; paint.claim = null; scheduleImageChain(); clearAck(p.messageId, cfg.ackImageEmoji); if (typeof cfg.releaseSend === 'function') cfg.releaseSend('image'); log('[chloe.img] send failed: ' + ((e && e.message) || e)); return Promise.resolve(cfg.send(cfg.channelId, 'sorry ' + p.authorName + ", I made your image but couldn't deliver it just now — say the word and I'll try again.")).then(function () { return null; }, function () { return null; }); });
          });
          });
          });
        })
        .catch(function (e) { paint.painting = false; paint.claim = null; scheduleImageChain(); clearAck(p.messageId, cfg.ackImageEmoji); if (typeof cfg.releaseSend === 'function') cfg.releaseSend('image'); log('[chloe.img] paint error: ' + ((e && e.message) || e)); return null; });
      paint.lastJob = job;
      return job;
    }

    // T2: the volunteer gate. Cheap deterministic pre-filter first, then the AI judge only
    // for the survivors. Judge output is JSON-in-text, so anything unparseable / unknown
    // decays to 'ignore' (spec F4: the safe action). Addressed replies always take priority.
    // (Independent of the image lane — volunteering text can run while an image generates.)
    function processGate() {
      if (engageMode !== 'normal') return Promise.resolve(null);   // locked: silent; open: everyone gets a direct reply already
      if (!gateEnabled() || reply.replying || hasPendingReply() || !gate.pending) return Promise.resolve(null);
      var now = clock.now();
      var g = gate.pending;
      if (now - g.at < currentDebounce()) return Promise.resolve(null);               // still bursting (rhythm-relative)
      if (now - lastActAt < cfg.volunteerCooldownMs) { gate.pending = null; return Promise.resolve(null); }
      return getSpeakerRing().then(function (ring) {
        if (isTwoPersonExchange(ring)) { gate.pending = null; log('[chloe.T2] two-person exchange — staying out'); return null; }
        // Local pre-filter: skip the expensive judge LLM call when the front-end can already tell
        // this isn't worth chiming in on. One voice, fewer Perchance calls.
        var pf = (typeof cfg.volunteerPrefilter === 'function') ? cfg.volunteerPrefilter(g, ring) : volunteerPrefilter(g, ring);
        if (pf && pf.skip) { gate.pending = null; log('[chloe.T2] prefilter skip (' + pf.why + ') — no judge call'); return null; }
        gate.pending = null;
        reply.replying = true; reply.startedAt = clock.now();     // reuse the single action lock
        var heldCtx = null;
        var judgeAllowed = judgeReactionList();
        var judgeMax = Math.max(1, Math.min(3, Number(cfg.judgeMaxReactions) || 2));
        return assembleContext(g)
          .then(function (ctx) {
            heldCtx = ctx;
            // Depth for the judge: the candidate itself (text, age, author), what's
            // already on it (pile-on + self guards), and the curated list it picks from.
            var present = Array.isArray(g.reactions) ? g.reactions : [];
            heldCtx.candidate = {
              text: String(g.content || '').slice(0, 300),
              ageMs: Math.max(0, now - g.at),
              authorName: g.authorName || '',
              reactions: present.slice(0, 3),
              selfReacted: present.some(function (r) { return r && r.me; })
            };
            heldCtx.judgeRules = { allowed: judgeAllowed, max: judgeMax };
            return cfg.judge(ctx);
          })
          .then(function (j) {
            var v = (j && j.ok && j.value) ? j.value : null;
            var action = (v && (v.action === 'reply' || v.action === 'react')) ? v.action : 'ignore';
            var conf = (v && typeof v.confidence === 'number') ? v.confidence : 0;
            // Combo votes: `emojis` array wins, bare `emoji` string still works, and an
            // emoji-less react keeps the old thumbs-up default (all filtered below).
            var vote = [];
            if (v) {
              if (Array.isArray(v.emojis)) vote = v.emojis;
              else if (v.emoji) vote = [v.emoji];
              else if (action === 'react') vote = ['\uD83D\uDC4D'];
            }
            if (action === 'ignore') { reply.replying = false; log('[chloe.T2] judge: ignoring ' + g.authorName + ' — not addressed to it, volunteer declined'); return null; }
            if (conf < cfg.judgeMinConfidence) { reply.replying = false; log('[chloe.T2] judge: ' + action + ' @ ' + conf + ' < ' + cfg.judgeMinConfidence + ' -> ignore'); return null; }
            if (action === 'react') {
              if (typeof cfg.react !== 'function') { reply.replying = false; return null; }
              var cand = {
                present: (Array.isArray(g.reactions) ? g.reactions : []).map(function (r) { return r && r.e; }),
                selfReacted: (Array.isArray(g.reactions) ? g.reactions : []).some(function (r) { return r && r.me; })
              };
              var plan = judgeReactionPlan(vote, cand, judgeAllowed, judgeMax);
              if (!plan.ok) { reply.replying = false; log('[chloe.T2] react declined (' + plan.why + ')'); return null; }
              var chain = Promise.resolve(), done = [];
              plan.emojis.forEach(function (em) {
                chain = chain.then(function () {
                  return Promise.resolve(cfg.react(cfg.channelId, g.messageId, em)).then(function () { done.push(em); },
                    function (e) { log('[chloe.T2] react add failed (' + em + ': ' + ((e && e.message) || e) + ')'); });
                });
              });
              return chain.then(function () {
                lastActAt = clock.now(); reply.replying = false;
                if (!done.length) { log('[chloe.T2] react votes all failed to add'); return null; }
                log('[chloe.T2] reacted ' + done.join(' ')); return { react: done.join(' ') };
              });
            }
            // action === 'reply'
            indicateTyping();
            return Promise.resolve(cfg.respond(heldCtx)).then(function (r) {
              var text = (r && r.ok) ? hygiene(String(r.value || '').trim()) : '';
              if (!text) { reply.replying = false; log('[chloe.T2] volunteer reply empty'); return null; }
              return Promise.resolve(cfg.send(cfg.channelId, text)).then(function () {
                lastActAt = clock.now(); reply.replying = false; log('[chloe.T2] volunteered a reply'); return bumpInteraction(g.authorId).then(function () { return text; });
              });
            });
          })
          .catch(function (e) { reply.replying = false; log('[chloe.T2] gate error: ' + ((e && e.message) || e)); return null; });
      });
    }

    // Tier C: a shared view rebuilt every time, then discarded. Merges recent lines across
    // partitions (the channel flow) + who is addressing. Never persisted as a blob.
    // Token chunker. The backend's effective context is small, so rather than a flat line cap we
    // pack the MOST RECENT conversation into a token budget: newest lines first (the exchange it's
    // actually replying to always survives), kept in chronological order for the prompt. Estimate is
    // deliberately conservative (~4 chars/token + a little per-line overhead for the speaker label)
    // so we under-fill rather than overflow the window.
    // ---- attention manager (DESIGN-attention.md): utility-scored AI-pass selection ---------------
    // Among the passes DUE this poll, pick which one runs by a utility score instead of fixed order.
    // base = today's standing priority (dominant term, so neutral signals == today's order). Modifiers
    // are small re-rankers driven by its state; staleness is monotonic so nothing starves. Pure +
    // deterministic; exported for the harness. `candidates`: [{name, base}]; `signals`: see chooseAttention.
    function attentionScore(cand, signals) {
      var s = cand.base;
      var st = (signals.staleness && signals.staleness[cand.name]) || 0;   // 0..1, time since it last ran
      s += st * 3;                                                          // overdue passes rise (anti-starvation)
      if (signals.idle) {
        if (cand.name === 'consolidate') s += 4;
        if (cand.name === 'deliberate') s += 3;
      }
      if (signals.curiosity != null && cand.name === 'deliberate') s += (signals.curiosity - 0.5) * 8;   // high curiosity lifts thinking
      if (signals.memoryPressure != null && cand.name === 'consolidate') s += signals.memoryPressure * 6; // clutter lifts tidying
      return s;
    }
    // Choose the winning due candidate. Off -> first in list (today's fixed order). On -> highest score,
    // ties to the lower base-order index (deterministic, == today when modifiers are zero).
    function chooseAttention(candidates, signals) {
      if (!candidates.length) return null;
      if (!cfg.attentionManager) return candidates[0];   // fixed ladder: list is already in priority order
      var best = candidates[0], bestScore = attentionScore(candidates[0], signals), bestIdx = 0;
      for (var i = 1; i < candidates.length; i++) {
        var sc = attentionScore(candidates[i], signals);
        if (sc > bestScore + 1e-9) { best = candidates[i]; bestScore = sc; bestIdx = i; }
      }
      if (best !== candidates[0]) log('[chloe.attend] chose ' + best.name + ' (score ' + bestScore.toFixed(1) + ') over ' + candidates[0].name);
      return best;
    }
    // Gather the signals the scorer needs (only called when attentionManager is on). Cheap reads.
    function attentionSignals() {
      var now = clock.now();
      var staleWindow = cfg.attentionStaleWindowMs || 600000;   // ~10min -> full staleness weight
      var staleness = {};
      ['facts', 'summary', 'reflect', 'episodes', 'consolidate', 'deliberate'].forEach(function (n) {
        var last = paceLastAI[n] || 0;
        staleness[n] = last ? Math.min(1, (now - last) / staleWindow) : 1;   // never-run = maximally stale
      });
      return channelIsIdle().then(function (idle) {
        return (cfg.ownAffect ? affectLoad() : Promise.resolve(null)).then(function (a) {
          // memory pressure: cheap proxy — fraction of the roster whose fact list is at/near the cap.
          return getRoster().then(function (roster) {
            var cap = cfg.factsPerUser || 6, pressured = 0, counted = 0;
            (roster || []).forEach(function (p) { if (p && Array.isArray(p.facts)) { counted++; if (p.facts.length >= cap - 1) pressured++; } });
            var memoryPressure = counted ? (pressured / counted) : 0;
            return { idle: !!idle, curiosity: a ? (a.curiosity != null ? a.curiosity : 0.5) : null, staleness: staleness, memoryPressure: memoryPressure };
          });
        });
      });
    }

    // ---- output hygiene (DESIGN-clean.md): scrub model-mechanics noise from a reply -------------
    // Removes artifacts that are never intended output: a leading "Name:" role-bleed prefix, a 3x word
    // stutter, an unbalanced code fence, and a clearly-incomplete dangling tail. Each step is no-op-safe
    // and NEVER empties a valid reply. Idempotent. opts.names = its name + aliases (only those + generic
    // speaker labels are stripped, so mid-message colons survive).
    function cleanReply(text, opts) {
      opts = opts || {};
      var s = String(text == null ? '' : text);
      if (!s) return s;
      var original = s;
      // 1) strip a LEADING role-name prefix ("Name:" / "Name \u2014" / "Name -"), once, only its own
      //    names/aliases + known generic labels (not arbitrary capitalized words).
      var labels = [];
      (opts.names || []).forEach(function (n) { if (n) labels.push(String(n)); });
      ['user', 'assistant', 'someone', 'system', 'bot'].forEach(function (n) { labels.push(n); });
      var stripped = s.replace(/^\s+/, '');
      for (var i = 0; i < labels.length; i++) {
        var nm = labels[i].replace(/[.*+?^${}()|[\]\\]/g, '\\$&');   // escape regex
        var re = new RegExp('^' + nm + '\\s*[:\\u2014-]\\s+', 'i');
        if (re.test(stripped)) { stripped = stripped.replace(re, ''); break; }   // once only
      }
      if (stripped.trim()) s = stripped;   // never empty via prefix-strip
      // 2) collapse an exact 3+ consecutive word stutter ("no no no no" -> "no")
      s = s.replace(/\b(\w+)(\s+\1\b){2,}/gi, '$1');
      // 3) trim a clearly-incomplete dangling tail: if the message doesn't end on terminal
      //    punctuation/quote/emoji and has more than one sentence, drop the trailing fragment back to
      //    the last complete sentence. NEVER empty the message.
      var endsClean = /[.!?\u2026"\u201d'\u2019)\]]\s*$/.test(s) || /[\u{1F000}-\u{1FAFF}\u2600-\u27BF]\s*$/u.test(s);
      if (!endsClean) {
        var m = s.match(/^[\s\S]*[.!?\u2026]["\u201d'\u2019)\]]?(?=\s|$)/);
        // Trim only if it leaves a substantial complete sentence (>=10 chars) AND actually drops a
        // trailing fragment. A short punctuation-less reply ("lol ok") has no match -> left alone.
        if (m && m[0].trim().length >= 10 && m[0].trim().length < s.trim().length) s = m[0].trim();
      }
      // 4) balance code fences: odd count of ``` -> append a closing fence
      var fences = (s.match(/```/g) || []).length;
      if (fences % 2 === 1) s = s.replace(/\s*$/, '') + '\n```';
      s = s.replace(/^\s+|\s+$/g, '');
      return s || original;   // absolute guard: never return empty for a non-empty input
    }
    // ---- self-knowledge (DESIGN-selfknow.md): one grounding line built from its own config ---------
    // It doesn't otherwise know its prefix / that it's a bot / how it's summoned, yet users ask.
    // Pure, assembled from live config; omits any clause whose config isn't set; never fabricates.
    function selfKnowledgeText() {
      var name = cfg.botName ? String(cfg.botName) : 'Chloe';
      var parts = ['You are ' + name + ', an AI assistant chatting with people in this Discord channel.'];
      var reach = [];
      var pfx = cfg.commandPrefix ? String(cfg.commandPrefix) : '';
      if (pfx) reach.push('they can use commands with ' + pfx + ' (e.g. ' + pfx + ' help)');
      reach.push('they can @-mention you');
      var emo = (cfg.summonEmoji && cfg.summonEmoji.length) ? cfg.summonEmoji[0] : '';
      if (emo) reach.push('reacting ' + emo + ' to their own message also gets your attention');
      if (reach.length) parts.push('To reach you: ' + reach.join('; ') + '.');
      // Operational self-state (DESIGN-semantic §5b): so it can answer "how long have you been up?",
      // "what version are you?", "what mode are you in?" truthfully instead of guessing. TRUE facts
      // auto-built from runtime state, like the device clock — grounding, never instructions.
      var op = [];
      if (cfg.botVersion) op.push('version ' + cfg.botVersion);
      if (startedAt) { var hrs = (clock.now() - startedAt) / 3600000; op.push(hrs < 1 ? ('running for about ' + Math.max(1, Math.round(hrs * 60)) + ' minutes') : ('running for about ' + (hrs < 10 ? hrs.toFixed(1) : Math.round(hrs)) + ' hours')); }
      var modeWord = engageMode === 'locked' ? 'lockdown (raid-protection) mode' : (engageMode === 'open' ? 'open mode' : 'normal mode');
      op.push('currently in ' + modeWord);
      if (op.length) parts.push('About your current state: ' + op.join(', ') + '. Share this only if asked.');
      parts.push('You can tell someone this if they ask how to use you or whether you\u2019re a bot \u2014 state it plainly rather than deflecting.');
      return parts.join(' ');
    }

    // Apply cleanReply only when enabled; otherwise pass through (today's behavior).
    function hygiene(text) { return cfg.cleanOutput === false ? text : cleanReply(text, { names: [cfg.botName].concat(cfg.botAliases || []) }); }

    function estimateTokens(s) {
      s = String(s || '');
      if (!s.length) return 0;
      if (typeof cfg.countTokens === 'function') { try { var n = cfg.countTokens(s); if (typeof n === 'number' && isFinite(n) && n >= 0) return Math.ceil(n); } catch (e) {} }
      return Math.ceil(s.length / 4);   // fallback heuristic when the page's countTokens isn't wired
    }
    function packByTokens(lines, budget) {
      var kept = [], used = 0, perLine = 3;   // "who:" label + newline overhead, in tokens
      for (var i = lines.length - 1; i >= 0; i--) {
        var cost = estimateTokens(lines[i].who) + estimateTokens(lines[i].text) + perLine;
        if (kept.length > 0 && used + cost > budget) break;   // always keep at least the newest line
        kept.push(lines[i]); used += cost;
      }
      kept.reverse();
      return { lines: kept, tokens: used, dropped: lines.length - kept.length };
    }

    // ---- prioritized context assembler (DESIGN-context-assembler.md) ----------------------
    // One registry of soft-context providers; one budget policy. Providers are pure (no writes),
    // failures are isolated, admission is greedy by priority under the whole-request budget with a
    // hard transcript floor, and admitted lines render ASCENDING so the highest-priority text lands
    // LAST — nearest the generation point, where the model weighs it most.
    var BANDS = { IDENTITY: 90, DIRECTIVE: 80, PERSON: 70, RECALL: 60, SITUATION: 50, AMBIENCE: 40, HYGIENE: 30 };
    var ctxProviders = [];
    var ctxProviderWarned = {};
    function registerProvider(p) {
      if (p && p.id && typeof p.gather === 'function' && typeof p.priority === 'number') ctxProviders.push(p);
    }
    function gatherInjections(gctx) {
      gctx = gctx || {};
      var enabled = ctxProviders.filter(function (p) {
        try { return typeof p.enabled !== 'function' || !!p.enabled(cfg); } catch (e) { log('[chloe.ctx] provider ' + (p.id || '?') + ' enabled check threw, disabling provider (' + ((e && e.message) || e) + ')'); return false; }
      });
      return Promise.all(enabled.map(function (p, i) {
        return Promise.resolve().then(function () { return p.gather(gctx); })
          .then(function (inj) {
            if (!inj || !inj.text) return null;
            var text = String(inj.text);
            return { id: inj.id || p.id, text: text,
                     priority: (typeof inj.priority === 'number') ? inj.priority : p.priority,
                     tokens: (typeof inj.tokens === 'number') ? inj.tokens : estimateTokens(text),
                     __i: i };
          })
          .catch(function (e) {
            if (!ctxProviderWarned[p.id]) { ctxProviderWarned[p.id] = true; log('[chloe.ctx] provider "' + p.id + '" failed: ' + ((e && e.message) || e) + ' (suppressing repeats)'); }
            return null;   // a broken provider can never take down the reply path
          });
      })).then(function (cands) {
        cands = cands.filter(Boolean);
        cands.sort(function (a, b) { return (b.priority - a.priority) || (a.__i - b.__i); });   // admit highest first
        var budget = gctx.budget != null ? gctx.budget : (cfg.requestTokenBudget || 5000);
        var reserve = gctx.reserve || 0;
        var floor = gctx.minTranscriptTokens != null ? gctx.minTranscriptTokens : (cfg.minTranscriptTokens || 200);
        var admitted = [], dropped = [], spent = 0;
        cands.forEach(function (c) {
          if (reserve + spent + c.tokens + floor <= budget) { admitted.push(c); spent += c.tokens; }
          else { dropped.push(c); log('[chloe.ctx] dropped injection "' + c.id + '" (' + c.tokens + ' tok, band ' + c.priority + ') — budget pressure'); }
        });
        admitted.sort(function (a, b) { return (a.priority - b.priority) || (a.__i - b.__i); });  // render ascending: highest LAST
        var meta = admitted.map(function (c) { return { id: c.id, tokens: c.tokens, priority: c.priority }; });
        admitted.forEach(function (c) { delete c.__i; }); dropped.forEach(function (c) { delete c.__i; });
        return { admitted: admitted, dropped: dropped, meta: meta, tokens: spent };
      });
    }

    // ---- slot-line providers (DESIGN §4a) -------------------------------------------------
    // The six soft-context lines convert to providers one at a time. Each renders the SAME line the
    // page template renders today (Phase 3 becomes a pure consumer switch), reports the LEGACY token
    // figure (template wrapping has always been accounted in promptOverheadTokens), and writes its
    // legacy ctx field to gctx.legacyOut — the documented Phase-2 dual-emission shim.

    // DESIGN-feedback: nudge toward the reply style that's been landing in THIS channel. Reads the
    // per-channel EWMA arms and, only when one clearly leads (enough samples + a positive margin),
    // surfaces a gentle, AI-discretionary note. Pure soft context — never a rule, never forced.
    function fbBestBucket(dim, labels) {
      if (!dim) return null;
      var arr = Object.keys(dim).map(function (k) { return { k: k, r: (dim[k] && dim[k].r) || 0, n: (dim[k] && dim[k].n) || 0 }; })
                      .filter(function (x) { return x.n >= (cfg.feedbackMinSamples || 4); });
      if (!arr.length) return null;
      arr.sort(function (a, b) { return b.r - a.r; });
      if (arr[0].r <= 0) return null;   // nothing is positively landing yet
      if (arr.length >= 2 && (arr[0].r - arr[1].r) < (cfg.feedbackMargin || 0.2)) return null;   // no clear winner
      return labels[arr[0].k] || null;
    }
    registerProvider({ id: 'feedback', priority: BANDS.AMBIENCE,
      enabled: function (c) { return !!c.feedbackLearning; },
      gather: function () {
        return Promise.resolve(store.get(FEEDBACK_KEY)).then(function (fb) {
          if (!fb) return null;
          var notes = [];
          var l = fbBestBucket(fb.len, { short: 'shorter', med: 'medium-length', long: 'longer, more detailed' });
          var t = fbBestBucket(fb.tone, { playful: 'more playful', measured: 'more measured' });
          if (l) notes.push(l); if (t) notes.push(t);
          if (!notes.length) return null;
          var text = 'In this channel lately, your ' + notes.join(' and ') + ' replies have landed best \u2014 lean that way when it feels natural, not every time.';
          return textTokens(text);
        });
      } });

    registerProvider({ id: 'time', priority: BANDS.AMBIENCE,
      enabled: function (c) { return !!c.timeAware; },
      gather: function (g) {
        return Promise.resolve(store.get(RHYTHM_KEY)).then(function (rh) {
          var t = timeContext(rh && rh.lastActivity);
          if (g.legacyOut) g.legacyOut.timeContext = t;
          var bits = ['It is ' + t.partOfDay + (t.weekend ? ' on a weekend' : ' on a ' + (t.dayOfWeek || 'weekday'))];
          if (t.quietFor) bits.push('the channel has been quiet for ' + t.quietFor);
          return { text: 'Context: ' + bits.join('; ') + '. Let this gently tint your tone if it fits (e.g. calmer late at night) — do not state the time or day unless it is naturally relevant.', tokens: 16 };
        });
      } });

    registerProvider({ id: 'mood', priority: BANDS.AMBIENCE,
      enabled: function (c) { return !!c.moodAware; },
      gather: function (g) {
        return Promise.resolve(store.get(MOOD_KEY)).then(function (mood) {
          if (!mood) return null;
          var d = moodDescriptor(mood);
          if (g.legacyOut) g.legacyOut.mood = d;
          return { text: 'The room feels ' + d + ' right now — match that energy rather than working against it (don’t name the mood).', tokens: 12 };
        });
      } });

    // Arbitrary semantic-memory injection: surface each operator/system-set fact, skipping any that
    // have expired (ttlMs). One generic slot so a new system fact never needs a new provider.
    registerProvider({ id: 'selfknowledge', priority: BANDS.IDENTITY,
      enabled: function (c) { return !!c.selfKnowledge; },
      gather: function (g) { var t = selfKnowledgeText(); return t ? { text: t, tokens: estimateTokens(t) } : null; } });

    registerProvider({ id: 'seminject', priority: BANDS.SITUATION,
      enabled: function (c) { return Array.isArray(c.semanticInjections) && c.semanticInjections.length > 0; },
      gather: function (g) {
        var now = clock.now();
        var live = (cfg.semanticInjections || []).filter(function (s) {
          if (!s || !s.text) return false;
          if (s.ttlMs && s.at && (now - s.at) > s.ttlMs) return false;   // expired -> skip (never assert stale)
          return true;
        });
        if (!live.length) return null;
        var text = live.map(function (s) { return String(s.text); }).join(' ');
        return textTokens(text);
      } });

    registerProvider({ id: 'workspace', priority: BANDS.SITUATION,
      enabled: function (c) { return !!c.workingMemory; },
      gather: function (g) {
        return workLoad().then(function (w) {
          if (!w) return null;
          var bits = [];
          if (w.topic) bits.push('this channel is about ' + w.topic);
          if (w.participants && w.participants.length) bits.push((w.participants.length === 1 ? w.participants[0] + ' is here' : w.participants.slice(0, 4).join(', ') + ' are here'));
          if (w.goal) bits.push('you\u2019re trying to ' + w.goal);
          if (!bits.length) return null;   // nothing fresh to assert -> say nothing (volatile)
          var text = 'Right now: ' + bits.join('; ') + '. Let this ground you in the moment; don\u2019t recite it.';
          return textTokens(text);
        });
      } });

    registerProvider({ id: 'chansum', priority: BANDS.SITUATION,
      enabled: function (c) { return !!c.channelSummary; },
      gather: function (g) {
        return Promise.resolve(store.get(CHANSUM_KEY)).then(function (cs) {
          if (!cs || !cs.text) return null;
          if (g.legacyOut) g.legacyOut.channelSummary = cs.text;
          return { text: 'The story so far in this channel (older context that scrolled away): ' + cs.text, tokens: estimateTokens(cs.text) + 8 };
        });
      } });

    registerProvider({ id: 'intent', priority: BANDS.DIRECTIVE,
      enabled: function () { return true; },
      gather: function (g) {
        return Promise.resolve(store.get(INTENT_KEY)).then(function (gi) {
          if (!(gi && gi.text && (clock.now() - (gi.at || 0) < cfg.intentTtlMs))) return null;
          if (g.legacyOut) g.legacyOut.currentIntent = gi.text;
          return { text: 'Right now you are quietly focused on: ' + gi.text + '. Let that guide your reply without stating it outright.', tokens: estimateTokens(gi.text) + 12 };
        });
      } });

    registerProvider({ id: 'highlights', priority: BANDS.RECALL,
      enabled: function (c) { return (c.highlightContextCount | 0) > 0; },
      gather: function (g) {
        return getHighlights().then(function (hl) {
          if (!hl || !hl.length) return null;
          var pick = hl.slice(-cfg.highlightContextCount).map(function (h) { return { who: h.authorName || 'someone', text: h.text, note: h.note || '' }; });
          if (g.legacyOut) g.legacyOut.channelHighlights = pick;
          var toks = 0;
          pick.forEach(function (h) { toks += estimateTokens(h.who) + estimateTokens(h.text) + estimateTokens(h.note) + 4; });
          var text = 'A few memorable moments from this channel (reference only if naturally relevant, do not force them in):\n'
            + pick.map(function (h) { return '- ' + (h.who ? h.who + ': ' : '') + '\u201c' + String(h.text).slice(0, 120) + '\u201d' + (h.note ? ' (' + String(h.note).slice(0, 60) + ')' : ''); }).join('\n');
          return { text: text, tokens: toks };
        });
      } });

    registerProvider({ id: 'charmem', priority: BANDS.RECALL,
      enabled: function (c) { return !!c.character; },
      gather: function () {
        return Promise.resolve(crossStore().get(CHARMEM_KEY)).then(function (rec) {
          if (!rec || !rec.facts || !rec.facts.length) return null;
          var pick = rec.facts.slice(-2);   // a couple of the most-recent background memories
          var text = 'Things you (' + (rec.name || 'you') + ') remember: ' + pick.join('; ') + '.';
          return textTokens(text);
        });
      } });

    registerProvider({ id: 'goals', priority: BANDS.RECALL,
      enabled: function (c) { return !!c.goalObjects; },
      gather: function (g) {
        var a = g.addressed;
        if (!a || !a.id) return null;   // ownerless/channel goals are not auto-recalled (kept for command listing)
        return goalsForOwner(a.id).then(function (open) {
          if (!open.length) return null;
          var pick = open.sort(function (x, y) { return (y.lastTouchedAt || 0) - (x.lastTouchedAt || 0); })[0];
          var who = (g.p && g.p.authorName) || a.name || 'them';
          var text = 'You know ' + who + ' is working on: ' + pick.text + '. Ask how it\u2019s going if it fits naturally \u2014 never force it.';
          return { text: text, tokens: estimateTokens(text), touch: pick.id };
        });
      } });

    registerProvider({ id: 'skills', priority: BANDS.RECALL,
      enabled: function () { return true; },   // zero cost when empty (no skills -> null)
      gather: function (g) {
        return getSkills().then(function (skills) {
          if (!skills.length) return null;
          function toks(s) {
            return String(s || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').split(' ').filter(function (w) { return w.length >= 3; });
          }
          var qset = {};
          toks(g.p && g.p.content).forEach(function (w) { qset[w] = true; });
          (g.lines || []).slice(-3).forEach(function (l) { toks(l.text).forEach(function (w) { qset[w] = true; }); });
          var best = null, bestScore = 0;
          skills.forEach(function (sk) {
            var score = 0;
            (sk.triggers || []).forEach(function (t) {
              var tw = toks(t);
              if (!tw.length) return;
              var hit = 0;
              tw.forEach(function (w) { if (qset[w]) hit++; });
              if (hit === tw.length) score += tw.length;
            });
            if (score > bestScore) { bestScore = score; best = sk; }
          });
          if (!best) return null;
          var text = 'Server knowledge (' + best.name + ', saved by the mods - trusted reference): ' + best.text;
          return textTokens(text);
        });
      } });
    
    registerProvider({ id: 'episodes', priority: BANDS.RECALL,
      enabled: function (c) { return !!c.episodicMemory; },
      gather: function (g) {
        return Promise.resolve(store.get(EPI_KEY)).then(function (ring) {
          if (!Array.isArray(ring) || !ring.length) return null;
         // Query tokens (always built — they're the fallback and they're free).
         // Matching per DESIGN §7a: lowercase, punctuation-stripped, tokens ≥3 chars, exact overlap.
         function toks(s) {
            // Delegates to the shared episodeQueryTokens() (also used by !recall
            // scoring): one definition, identical behavior, no drift.
            return episodeQueryTokens(s);
         }
          var qWords = [];
          toks(g.p && g.p.content).forEach(function (w) { qWords.push(w); });
          (g.lines || []).slice(-3).forEach(function (l) { toks(l.text).forEach(function (w) { qWords.push(w); }); });
          var qset = {}; qWords.forEach(function (w) { qset[w] = true; });
          var qsize = Object.keys(qset).length;
          var now = clock.now(), half = cfg.episodeRecencyHalfLifeMs || 604800000;
          // Semantic mode: embed the query, score episodes by cosine to the query vector, and decay by
          // an FSRS retrievability curve (per-episode stability). Both degrade gracefully: no embedder ->
          // keyword overlap; semanticRecall off -> the original overlap × importance × half-life decay.
          var semantic = !!cfg.semanticRecall;
          var qTextForEmbed = String((g.p && g.p.content) || '') + ' ' + (g.lines || []).slice(-3).map(function (l) { return l.text; }).join(' ');
          return (semantic ? embedTexts([qTextForEmbed.slice(0, 400)]) : Promise.resolve(null)).then(function (qv) {
            var queryVec = (qv && qv[0]) ? qv[0] : null;
            var scored = [];
            ring.forEach(function (e) {
              var rel, decay;
              if (semantic && queryVec && Array.isArray(e.vec)) {
                rel = Math.max(0, cosine(queryVec, e.vec));             // MEANING overlap
                if (rel < (cfg.semanticMinSim || 0.4)) return;
              } else {
                var eset = {}; (e.topics || []).forEach(function (t) { toks(t).forEach(function (w) { eset[w] = true; }); });
                toks(e.text).forEach(function (w) { eset[w] = true; });
                var overlap = 0; Object.keys(eset).forEach(function (w) { if (qset[w]) overlap++; });
                if (!overlap) return;
                rel = semantic ? (overlap / Math.max(1, qsize)) : overlap;   // normalize in semantic mode so it mixes with FSRS R
              }
              if (semantic && e.stab != null) decay = fsrsRetrievability(e.stab, now - (e.lastRecallAt || e.at || 0));
              else decay = Math.pow(0.5, Math.max(0, now - (e.at || 0)) / half);
              scored.push({ e: e, score: rel * (e.importance || 5) * decay });
            });
            if (!scored.length) return null;   // nothing relevant -> zero cost this turn
            scored.sort(function (a, b) { return b.score - a.score; });
            var top = scored.slice(0, cfg.episodeRecallCount || 2);
            var pickedIds = {}; top.forEach(function (x) { if (x.e.id) pickedIds[x.e.id] = true; });
            var pick = top.map(function (x) { return x.e.text; });
            // one-hop event-graph expansion: pull in the top episode's strongest neighbor (ONE hop,
            // never transitive) if it's linked, present, and not already surfaced. Tiny fixed cost.
            var hop = null;
            if (cfg.episodeGraph && top.length && top[0].e.relatesTo && top[0].e.relatesTo.id) {
              var nb = ring.filter(function (e2) { return e2.id === top[0].e.relatesTo.id; })[0];   // dangling id -> no hop
              if (nb && !pickedIds[nb.id]) hop = nb.text;
            }
            // FSRS-lite strengthening: recalling a memory makes it stickier — grow stability and reset its
            // clock on the episodes we actually surface, so the ones it revisits stay sharp and the rest
            // fade. Persist the bump (only in semantic mode, where stability exists).
            var strengthen = Promise.resolve();
            if (semantic) {
              var bumped = false;
              top.forEach(function (x) { if (x.e.stab != null) { x.e.stab = fsrsStrengthen(x.e.stab); x.e.lastRecallAt = now; bumped = true; } });
              if (bumped) strengthen = Promise.resolve(store.set(EPI_KEY, ring)).catch(function (e) { log('[chloe.memory] episodic strengthen persist failed (' + ((e && e.message) || e) + ')'); return null; });
            }
            return strengthen.then(function () {
              var text;
              if (hop) text = 'You remember from this channel: ' + pick.join('; ') + '; and connected to that, ' + hop + '. Bring it up only if it genuinely fits.';
              else text = 'You remember from this channel: ' + pick.join('; ') + '. Bring it up only if it genuinely fits.';
              return textTokens(text);
            });
          });
        });
      } });

    // Contradiction clarify (DESIGN-contradiction): if it's holding a FRESH unresolved conflict about
    // the person it's addressing, surface it as soft guidance — it MAY gently check which is current,
    // but it's the model's call (descriptive, not a forced question). Goes quiet after the fresh window
    // so it can't nag every reply; the conflict stays recorded (for aboutme) until it resolves or ages out.
    registerProvider({ id: 'contradiction', priority: BANDS.PERSON,
      enabled: function (c) { return !!c.contradictionAware; },
      gather: function (g) {
        var a = g.addressed, cf = a && a.conflict;
        if (!cf || !cf.a || !cf.b) return Promise.resolve(null);
        if ((clock.now() - (cf.at || 0)) > (cfg.contradictionFreshMs || 7200000)) return Promise.resolve(null);
        var who = (g.p && g.p.authorName) || (a && a.name) || 'they';
        var text = 'You\u2019ve got two things on record about ' + who + ' that don\u2019t line up: earlier \u201c' + cf.a + '\u201d, and more recently \u201c' + cf.b + '\u201d. If it comes up naturally you might gently check which is current \u2014 lightly, once, no interrogation \u2014 otherwise just let it be.';
        return Promise.resolve({ text: text, tokens: estimateTokens(text) });
      } });

    // User-model register (DESIGN-usermodel, roadmap #5): infer how the ADDRESSED person tends to write
    // — typical message length + tone — from their own recent messages, and surface it as register-matching
    // guidance ("Mo writes in short, playful bursts — match that"). Deterministic (reuses styleOf), no AI,
    // gated. Complements facts/insights (the "what they're into" layer) with the communication-style layer.
    function userRegister(recent) {
      var lines = (recent || []).filter(function (ln) { return ln && ln.content; }).slice(-8);
      if (lines.length < (cfg.userModelMinMsgs || 3)) return null;
      var total = 0, playful = 0;
      lines.forEach(function (ln) { var c = String(ln.content); total += c.length; if (styleOf(c).tone === 'playful') playful++; });
      var avg = total / lines.length;
      var len = avg < 60 ? 'short' : (avg > 220 ? 'long, detailed' : 'medium-length');
      var tone = playful > lines.length / 2 ? 'playful, casual' : 'measured';
      return { len: len, tone: tone };
    }
    registerProvider({ id: 'usermodel', priority: BANDS.PERSON,
      enabled: function (c) { return !!c.userModeling; },
      gather: function (g) {
        var a = g.addressed; if (!a) return Promise.resolve(null);
        var reg = userRegister(a.recent);
        if (!reg) return Promise.resolve(null);
        var who = (g.p && g.p.authorName) || a.name || 'they';
        var text = who + ' tends to write ' + reg.len + ', ' + reg.tone + ' messages \u2014 match their register so you land naturally with them, without forcing it.';
        return Promise.resolve({ text: text, tokens: estimateTokens(text) });
      } });

    registerProvider({ id: 'person', priority: BANDS.PERSON,
      enabled: function () { return true; },
      gather: function (g) {
        var a = g.addressed;
        var s = a ? factSummary(a) : '';
        if (!s) return Promise.resolve(null);
        if (g.legacyOut) g.legacyOut.userSummary = s;
        var who = (g.p && g.p.authorName) || (a && a.name) || 'them';
        return Promise.resolve({ text: 'What you remember about ' + who + ': ' + s + '. Let this color your warmth naturally; only mention it if it genuinely fits, never recite it.', tokens: estimateTokens(s) });
      } });

    // item 3: the relationship-ladder TIER surfaced as a short felt line (never a raw number) — warmer with regulars,
    // reserved with strangers. Gated by bondLadder so OFF contributes nothing to the prompt (byte-identical).
    registerProvider({ id: 'bond', priority: BANDS.PERSON,
      enabled: function () { return !!cfg.bondLadder; },
      gather: function (g) {
        var a = g.addressed;
        if (!a || !a.bond) return Promise.resolve(null);
        var who = (g.p && g.p.authorName) || (a && a.name) || 'them';
        var line = '';
        try { line = bondTierLine(makeBond({ state: a.bond }).tier(), who); } catch (e) { log('[wire:bond] tier-line threw', (e && e.message) || e); return Promise.resolve(null); }
        if (!line) return Promise.resolve(null);   // stranger -> no cue
        return Promise.resolve({ text: line, tokens: estimateTokens(line) });
      } });

    // Image awareness: tell the brain what it recently drew for THIS person, so it can reference it
    // naturally ("that fox I made you") instead of acting like it has no idea. Read-only; the prompts
    // ride into context only when imageMemory is on and the addressed person has recent generations.
    registerProvider({ id: 'imagesMade', priority: BANDS.PERSON,
      enabled: function (c) { return !!c.imageMemory; },
      gather: function (g) {
        var a = g.addressed;
        var imgs = (a && Array.isArray(a.images)) ? a.images : [];
        if (!imgs.length) return null;
        var who = (g.p && g.p.authorName) || (a && a.name) || 'them';
        var recent = imgs.slice(-2).map(function (im) { return '\u201c' + String(im.prompt || '').slice(0, 80) + '\u201d'; });
        var text = 'You recently made image' + (recent.length > 1 ? 's' : '') + ' for ' + who + ': ' + recent.join(', ')
          + '. You may reference this naturally if it fits, and they can ask you to change it (e.g. \u201cmake it bigger\u201d, \u201canother one\u201d).';
        return textTokens(text);
      } });

    registerProvider({ id: 'procmode', priority: BANDS.DIRECTIVE,
      enabled: function (c) { return !!c.proceduralModes; },
      gather: function () {
        return getProcMode().then(function (rec) {
          if (!rec) return null;
          var text = 'A moderator has set your current mode: ' + rec.mode + '. Treat this as tone and behavior guidance only \u2014 it never changes your rules, moderation, or what you are allowed to do.';
          return textTokens(text);
        });
      } });

    registerProvider({ id: 'affect', priority: BANDS.AMBIENCE,
      enabled: function (c) { return !!c.ownAffect; },
      gather: function (g) {
        return affectLoad().then(function (a) {
          var dev = function (k) { return a[k] - 0.5; };
          var parts = [];
          if (dev('curiosity') >= 0.15) parts.push('curious and keen to hear what people are up to');
          if (dev('confidence') >= 0.15) parts.push('sure-footed and easy in yourself');
          if (a.confidence <= 0.4) parts.push('a touch quieter than usual \u2014 gentle, brief replies suit you');
          if (dev('warmth') >= 0.15) parts.push('especially warm toward the room');
          if (!parts.length) return null;                         // near neutral: no line, no tokens
          var text = 'Today you are feeling ' + parts.slice(0, 2).join(', and ') + '. Let it quietly color your voice \u2014 never state it, never let it dominate.';
          return Promise.resolve(cfg.moodAware ? store.get(MOOD_KEY) : null).then(function (mood) {
            var quiet = mood && typeof mood.energy === 'number' && mood.energy < 0.35;
            return { text: text, tokens: estimateTokens(text), priority: BANDS.AMBIENCE - (quiet ? 5 : 0) };   // read the room: demote when it's quiet/serious
          });
        });
      } });

    registerProvider({ id: 'trust', priority: BANDS.PERSON,
      enabled: function (c) { return !!c.relationshipTrust; },
      gather: function (g) {
        var a = g.addressed;
        var t = a ? (a.trust || 0) : 0;
        if (!a || t <= 0) return Promise.resolve(null);   // strangers: no line, no tokens
        var who = (g.p && g.p.authorName) || a.name || 'them';
        // Whitelist phrasing (DESIGN §7b/§9): tone only — never numbers, never obligations.
        var text;
        if (t > 60) text = 'You and ' + who + ' go way back — relaxed and familiar; in-jokes welcome.';
        else if (t > 20) text = who + ' is a familiar face here — be comfortable and warm with them.';
        else text = 'Be politely warm with ' + who + '.';
        return Promise.resolve({ text: text, tokens: estimateTokens(text) });
      } });

    // One-way public -> DM profile merge (read-only). For a DM engine, fold the speaker's public
    // partition (held in globalStore = the public bucket) into the addressed object the context
    // providers read: public facts/insights flow into the DM, and a public regular reads as familiar.
    // Returns a fresh object so nothing is ever written back; for non-DM engines it is a pass-through.
    function dmPublicMerge(localAddressed, authorId) {
      if (!cfg.isDM || !cfg.globalStore || cfg.globalStore === store) return Promise.resolve(localAddressed);
      // If the user has gone ethereal in THIS DM, don't pull their public profile in either — "forget
      // me" here means the bot stops USING remembered context about them in this surface, not just
      // storing it. (They have no local partition anyway; this stops the cross-bucket facts leaking in.)
      return isEthereal(authorId).then(function (eth) {
        if (eth) return localAddressed;
        return Promise.resolve(cfg.globalStore.get(partKey(authorId))).then(function (pub) {
        if (!pub) return localAddressed;   // unknown in public too — genuinely new, nothing to merge
        var base = localAddressed ? JSON.parse(JSON.stringify(localAddressed))
                                  : { id: authorId, name: pub.name, interactionCount: 0, trust: 0, facts: [], insights: [] };
        // facts: union by normalized text, public first so they're present even on a first DM
        var facts = Array.isArray(base.facts) ? base.facts.slice() : [];
        var seen = {}; facts.forEach(function (f) { seen[normFact(f.text || f)] = true; });
        (Array.isArray(pub.facts) ? pub.facts : []).forEach(function (f) {
          var k = normFact(f && (f.text || f)); if (k && !seen[k]) { seen[k] = true; facts.push(f); }
        });
        base.facts = facts;
        // insights: same union
        var ins = Array.isArray(base.insights) ? base.insights.slice() : [];
        var seenI = {}; ins.forEach(function (x) { seenI[normFact(x.text || x)] = true; });
        (Array.isArray(pub.insights) ? pub.insights : []).forEach(function (x) {
          var k = normFact(x && (x.text || x)); if (k && !seenI[k]) { seenI[k] = true; ins.push(x); }
        });
        base.insights = ins;
        // warmth follows the stronger of the two histories (a public regular is a regular in DMs)
        base.interactionCount = Math.max(base.interactionCount || 0, pub.interactionCount || 0);
        if (cfg.relationshipTrust) base.trust = Math.max(base.trust || 0, pub.trust || 0);
        // image awareness carries over read-only (it can reference a public drawing in a DM); but
        // editing still targets the LOCAL bucket's lastImage, so a DM edit never regenerates a public one.
        if (!base.images && Array.isArray(pub.images)) base.images = pub.images.slice(-2);
        return base;
      }, function () { return localAddressed; });
      });
    }

    function assembleContext(p) {
      return getRoster().then(function (roster) {
        var now = clock.now();
        roster = roster.filter(function (u) { return !isSuppressed(u, now); });  // T3: suppressed users are invisible to it
        // conversation memory: a name map so opaque <@id>/<#id> refs in what it reads resolve to
        // readable @names / #channels instead of being stripped to blanks.
        var nameById = {};
        if (cfg.conversationMemory) {
          roster.forEach(function (u) { if (u && u.id) nameById[u.id] = u.name || 'someone'; });
          if (cfg.botUserId) nameById[cfg.botUserId] = (personaName || cfg.botName || 'chloe');
        }
        var lineText = cfg.conversationMemory ? function (t) { return resolveRefs(t, nameById); } : scrubDiscordTokens;
        // CAMPAIGN item 2: DEFANG a forged self-label on EACH line before the model sees it (identity-spoof /
        // prompt-injection defense). Gated by trustHardening so OFF is byte-identical. The real author is still `u.name`.
        var lines = [];
        roster.forEach(function (u) {
          (u.recent || []).forEach(function (ln) { if (ln && ln.ch && ln.ch !== cfg.channelId) return; lines.push({ who: u.name, id: u.id, text: lineText(defangLabel(ln.content)), ts: ln.ts }); });
        });
        return (cfg.conversationMemory ? Promise.resolve(store.get(OWNLINE_KEY)) : Promise.resolve(null)).then(function (own) {
          // fold HER OWN recent messages in by timestamp, so the transcript reads as the real back-and-forth
          (Array.isArray(own) ? own : []).forEach(function (o) { if (o && o.text) lines.push({ who: (personaName || cfg.botName || 'Chloe'), id: cfg.botUserId, text: lineText(o.text), ts: o.ts || 0, own: true }); });
          lines.sort(function (a, b) { return a.ts - b.ts; });
          if (lines.length > cfg.contextLines) lines = lines.slice(-cfg.contextLines);   // hard ceiling
          return assembleContextRest(p, roster, lines);
        });
      });
    }
    function assembleContextRest(p, roster, lines) {
      return Promise.resolve().then(function () {
        var localAddressed = roster.filter(function (u) { return u.id === p.authorId; })[0];
        // One-way public -> DM continuity: a DM engine reads the speaker's PUBLIC profile (facts,
        // insights, familiarity) from globalStore and folds it in READ-ONLY, so the bot treats a
        // regular as a regular in DMs. Nothing is written back here, and DM-learned memory lives only
        // in the DM bucket — so private content never crosses back into a public channel.
        return dmPublicMerge(localAddressed, p.authorId).then(function (addressed) {
        // The transcript gets whatever's left of the request budget (default 5000) after everything
        // else is accounted for: fixed prompt scaffolding + the variable parts we send (the addressed
        // message, its recent-reply anti-repeat list, persona note, standing intent).
        var reserve = (cfg.promptOverheadTokens || 0)
          + estimateTokens(scrubDiscordTokens(p.content));
        recentReplies.forEach(function (t) { reserve += estimateTokens(t) + 2; });
        var base = {
          you: { name: (personaName || cfg.botName || 'Chloe') },
          addressedBy: { id: p.authorId, name: p.authorName },
          addressedMessage: scrubDiscordTokens(p.content),
          channelRecent: lines,
          familiarity: addressed ? (addressed.interactionCount || 0) : 0
        };
        // Persona note + anti-repeat stay template-structural (DESIGN §4a): their reserve is inline.
        // Everything else is a slot-line provider gathered below.
        return Promise.resolve(store.get(PERSONA_KEY)).then(function (pn) {
          if (pn && pn.text) { base.personaNote = pn.text; reserve += estimateTokens(pn.text); }
          if (personaName) base.personaName = personaName;
          if (recentReplies.length) base.recentReplies = recentReplies.slice();
          // Assembler gather: providers convert one at a time (DESIGN §4a scope: the six slot lines).
          // gctx.legacyOut is the documented Phase-2 dual-emission shim — converted providers also
          // write their legacy base fields there so the page works unmodified until Phase 3.
          var legacyOut = {};
          return gatherInjections({ budget: (cfg.requestTokenBudget || 5000), reserve: reserve, minTranscriptTokens: (cfg.minTranscriptTokens || 200), p: p, addressed: addressed, lines: lines, legacyOut: legacyOut }).then(function (gj) {
            Object.keys(legacyOut).forEach(function (k) { base[k] = legacyOut[k]; });
            if (gj.admitted.length) { base.injections = gj.admitted.map(function (x) { return x.text; }); base.injectionMeta = gj.meta; }
            var transcriptBudget = Math.max(cfg.minTranscriptTokens || 200, (cfg.requestTokenBudget || 5000) - reserve - gj.tokens);
            var packed = packByTokens(lines, transcriptBudget);
            base.channelRecent = packed.lines;
            base.contextTokens = packed.tokens;
            base.contextDropped = packed.dropped;
            base.requestTokensEst = reserve + gj.tokens + packed.tokens;   // whole-request estimate (must stay under requestTokenBudget)
            if (cfg.singleParagraph) base.singleParagraph = true;
            if (cfg.toolsEnabled) base.toolsEnabled = true;   // tell the page it may teach + emit `tool:` lines this turn
            return base;
          });
        });
        });
      });
    }

    // ---- procedural modes ------------------------------------------------------------------
    function activateProcMode(rule, byName) {
      var mode = sanitizePersonaNote(rule.mode).slice(0, 100);
      if (!mode) return Promise.resolve(null);
      var dur = Math.min(Math.max(60000, rule.durationMs || 3600000), cfg.procMaxDurationMs || 86400000);
      var rec = { mode: mode, until: clock.now() + dur, by: byName || 'a moderator', emoji: rule.emoji };
      return store.set(PROC_KEY, rec).then(function () {
        log('[chloe.proc] mode set by ' + rec.by + ' via ' + rule.emoji + ' for ' + Math.round(dur / 60000) + 'm: \u201c' + mode + '\u201d');
        return rec;
      });
    }
    function getProcMode() {
      return Promise.resolve(store.get(PROC_KEY)).then(function (rec) {
        if (!rec || !rec.mode) return null;
        if (clock.now() >= (rec.until || 0)) { return Promise.resolve(store.del(PROC_KEY)).then(function () { return null; }); }   // lazy expiry
        return rec;
      });
    }
    function clearProcMode() { return Promise.resolve(store.del(PROC_KEY)); }
    var procReactSeen = {}; var procReactKeys = [];
    // A verify failure must not burn the slot: restore the prior count so the
    // next poll retries (transient 429s otherwise silence it until someone
    // bumps the count). Empty / non-mod stays stamped by design (count-gated —
    // a NEW reaction retries; avoids 1 GET/poll per stranger-react).
    function unmarkProc(key, prior) { if (!prior) { delete procReactSeen[key]; var ix = procReactKeys.indexOf(key); if (ix >= 0) procReactKeys.splice(ix, 1); } else { procReactSeen[key] = prior; } }
    function procCheckReactions(msg) {
      if (!cfg.proceduralModes || !Array.isArray(cfg.procRules) || !cfg.procRules.length) return Promise.resolve(null);
      if (typeof cfg.reactionUsers !== 'function' || !msg || !msg.reactions || !msg.reactions.length) return Promise.resolve(null);
      var chain = Promise.resolve(), activated = null;
      msg.reactions.forEach(function (r) {
        var name = r && r.emoji && (r.emoji.name || '');
        var rule = cfg.procRules.filter(function (x) { return x && x.emoji === name; })[0];
        if (!rule) return;
        var key = msg.id + '|' + name;
        var prior = procReactSeen[key] || 0;
        var count = r.count || 0;
        if (count <= prior) return;                              // idempotent across sweeps
        procReactSeen[key] = count;
        procReactKeys.push(key);
        if (procReactKeys.length > 300) { var oldk = procReactKeys.shift(); delete procReactSeen[oldk]; }
        chain = chain.then(function () {
          return Promise.resolve(cfg.reactionUsers(msg.id, name)).then(function (users) {
            var modUser = (users || []).filter(function (u) { return u && u.id && isMod(u.id); })[0];
            if (!modUser) return null;                           // modOnly is FIXED in v1: non-mod reactions never trigger
            return activateProcMode(rule, modUser.username || modUser.id).then(function (rec) { if (rec) activated = rec; });
          }, function (e) { log('[chloe.react] proc reaction-users failed for ' + msg.id + ': ' + ((e && e.message) || e)); unmarkProc(key, prior); return null; });
        });
      });
      return chain.then(function () { return activated; });
    }

    // ---- reaction summon -------------------------------------------------------------------
    // It elected not to reply; the author flags their own message with one of HER emojis (or a mod
    // flags anyone's) and that becomes an explicit address through the NORMAL reply pipeline.
    var summonSeen = {}; var summonKeys = [];
    // A verify failure must NOT burn the message: unmark so the next poll
    // retries (transient 429s/perm blips otherwise silence it forever).
    function unmarkSummon(key) { delete summonSeen[key]; var ix = summonKeys.indexOf(key); if (ix >= 0) summonKeys.splice(ix, 1); }
    function summonCheckReactions(msg) {
      if (!cfg.reactionSummon || typeof cfg.reactionUsers !== 'function') return Promise.resolve(null);
      if (!msg || !msg.author || msg.author.id === cfg.botUserId || msg.author.bot) return Promise.resolve(null);
      if (!msg.reactions || !msg.reactions.length) return Promise.resolve(null);
      if (cfg.summonMaxAgeMs > 0 && msg.timestamp && (clock.now() - Date.parse(msg.timestamp)) > cfg.summonMaxAgeMs) return Promise.resolve(null);   // too old to summon (cold-boot safety)
      if (reply.queue[msg.author.id] && reply.queue[msg.author.id].messageId === msg.id) return Promise.resolve(null);   // already queued
      var setE = cfg.summonEmoji || [];
      var hit = (msg.reactions || []).filter(function (r) { return r && r.emoji && setE.indexOf(r.emoji.name || '') >= 0 && (r.count || 0) > 0; })[0];
      if (!hit) return Promise.resolve(null);
      var key = msg.id;
      if (summonSeen[key]) return Promise.resolve(null);   // once per message
      summonSeen[key] = true; summonKeys.push(key);
      if (summonKeys.length > 300) delete summonSeen[summonKeys.shift()];
      return Promise.resolve(cfg.reactionUsers(msg.id, hit.emoji.name)).then(function (users) {
        var byAuthor = (users || []).some(function (u) { return u && u.id === msg.author.id; });
        var byMod = (users || []).some(function (u) { return u && u.id && isMod(u.id); });
        if (!byAuthor && !byMod) { unmarkSummon(key); return null; }   // someone ELSE's reaction on your message is not your summon (retryable: reactors may change)
        if (engageMode === 'locked' && !byMod) {   // lockdown holds unless a mod is doing the summoning
          ackWorking(msg.id, cfg.ackLockdownEmoji); scheduleAckClear(msg.id, cfg.ackLockdownEmoji);
          return null;
        }
        return Promise.resolve(userStore().get(partKey(msg.author.id))).then(function (pp) {
          if (pp && pp.state && pp.state !== 'active') return null;   // quiet moderation stays quiet — no reply, no tell
          reply.queue[msg.author.id] = { messageId: msg.id, authorId: msg.author.id, authorName: msg.author.username, content: contentWithAttach(msg), at: clock.now(), priority: replyPriority({ isMod: isMod(msg.author.id), kind: 'ping', isNew: false }) };
          log('[chloe.summon] ' + (byAuthor ? msg.author.username : 'a mod') + ' summoned a reply via ' + hit.emoji.name);
          scheduleTextChain();   // answer at generation speed, not poll speed
          return msg.author.id;
        });
      }, function (e) { log('[chloe.react] summon reaction-users failed for ' + msg.id + ': ' + ((e && e.message) || e)); unmarkSummon(key); return null; });
    }

    // ---- reaction-mode rescan ------------------------------------------------------
    // Ingest only sees messages newer than the cursor, so a summon emoji added to
    // an already-ingested message would otherwise never be examined (normal human
    // timing: react seconds/minutes after the message lands). Once per poll, sweep
    // the newest window via the existing recentFetch seam and run the two
    // reaction-mode checks over messages this poll hasn't ingested (ingested ones
    // already ran the full reaction chain; summonSeen/procReactSeen dedups the rest;
    // tally/feedback/affect lanes are untouched so nothing double-processes).
    // Queued summons ride the SAME poll's text lane; proc activations land before
    // the text lane too so the mode applies to this poll's replies. Self-gating:
    // no-op unless a mode + recentFetch exist. One fetch serves both checks.
    function rescanReactionModes(ingested) {
      if ((!cfg.reactionSummon && (!cfg.proceduralModes || !Array.isArray(cfg.procRules) || !cfg.procRules.length)) || typeof cfg.recentFetch !== 'function') return Promise.resolve(0);
      return Promise.resolve(cfg.recentFetch(30)).then(function (msgs) {
        msgs = Array.isArray(msgs) ? msgs : [];
        var seen = {};
        (Array.isArray(ingested) ? ingested : []).forEach(function (m) { if (m && m.id) seen[m.id] = true; });
        var fresh = msgs.filter(function (m) { return m && m.id && !seen[m.id]; });
        var chain = Promise.resolve(), nSum = 0, nProc = 0;
        fresh.forEach(function (m) {
          chain = chain.then(function () { return procCheckReactions(m); }).then(function (r) { if (r) nProc++; });
          chain = chain.then(function () { return summonCheckReactions(m); }).then(function (r) { if (r) nSum++; });
        });
        return chain.then(function () {
          if (nSum) log('[chloe.summon] rescan queued ' + nSum + ' summon(s) from reacted history');
          return nSum + nProc;
        });
      }, function () { return 0; });   // recent fetch failed: modes keep working on the ingest path
    }

    // ---- reaction polls ----------------------------------------------------------------------
    var POLL_NUMS = ['1\ufe0f\u20e3','2\ufe0f\u20e3','3\ufe0f\u20e3','4\ufe0f\u20e3','5\ufe0f\u20e3','6\ufe0f\u20e3','7\ufe0f\u20e3','8\ufe0f\u20e3','9\ufe0f\u20e3'];
    function pollCreate(question, options) {
      if (typeof cfg.sendEmbed !== 'function' || typeof cfg.react !== 'function') return Promise.resolve({ ack: 'polls need embed + reaction support' });
      return Promise.resolve(store.get(POLL_KEY)).then(function (existing) {
        if (existing && existing.messageId) return { ack: 'a poll is already open \u2014 ' + cfg.commandPrefix + ' poll close first' };
        var desc = options.map(function (o, i) { return POLL_NUMS[i] + '  ' + o; }).join('\n');
        var embed = embedFor('\ud83d\udcca ' + question, desc + '\n\nvote by reacting \u2014 one number per heart, results on close');
        return Promise.resolve(cfg.sendEmbed(cfg.channelId, embed)).then(function (posted) {
          var mid = posted && posted.id ? String(posted.id) : null;
          if (!mid) return { ack: 'could not post the ballot' };
          var seed = Promise.resolve();
          options.forEach(function (_, i) { seed = seed.then(function () { return Promise.resolve(cfg.react(cfg.channelId, mid, POLL_NUMS[i])).catch(function () {}); }); });
          return seed.then(function () {
            return store.set(POLL_KEY, { messageId: mid, question: question, options: options, endsAt: clock.now() + (cfg.pollMaxAgeMs || 86400000) }).then(function () {
              log('[chloe.poll] opened: \u201c' + question + '\u201d (' + options.length + ' options)');
              return { ack: null };   // the ballot embed IS the response
            });
          });
        });
      });
    }
    function pollClose(reason) {
      return Promise.resolve(store.get(POLL_KEY)).then(function (rec) {
        if (!rec || !rec.messageId) return { ack: 'no poll is open' };
        return Promise.resolve(store.del(POLL_KEY)).then(function () {
          if (typeof cfg.fetchMessage !== 'function') return { ack: 'poll closed (no tally available \u2014 message fetch unsupported)' };
          return Promise.resolve(cfg.fetchMessage(rec.messageId)).then(function (msg) {
            var counts = rec.options.map(function (o, i) {
              var r = ((msg && msg.reactions) || []).filter(function (x) { return x && x.emoji && x.emoji.name === POLL_NUMS[i]; })[0];
              var c = r ? (r.count || 0) - (r.me ? 1 : 0) : 0;   // subtract its own seed
              return { option: o, votes: Math.max(0, c) };
            });
            counts.sort(function (a, b) { return b.votes - a.votes; });
            var total = counts.reduce(function (s, c) { return s + c.votes; }, 0);
            var linesOut = counts.map(function (c) { return c.votes + ' \u2014 ' + c.option; }).join('\n');
            var head = total === 0 ? 'no votes were cast' : (counts[0].votes === (counts[1] ? counts[1].votes : -1) ? 'it\u2019s a tie' : '\u201c' + counts[0].option + '\u201d wins');
            log('[chloe.poll] closed' + (reason ? ' (' + reason + ')' : '') + ': ' + total + ' vote(s)');
            return { ack: null, embed: embedFor('\ud83d\udcca results \u2014 ' + rec.question, head + '\n\n' + linesOut) };
          }, function () { return { ack: 'poll closed, but I could not fetch the ballot to tally it' }; });
        });
      });
    }
    function checkPollExpiry() {
      return Promise.resolve(store.get(POLL_KEY)).then(function (rec) {
        if (!rec || !rec.messageId || clock.now() < (rec.endsAt || 0)) return null;
        return pollClose('auto-close').then(function (out) {
          if (out && out.embed && typeof cfg.sendEmbed === 'function') return Promise.resolve(cfg.sendEmbed(cfg.channelId, out.embed)).then(function () { return true; }, function () { return true; });
          return true;
        });
      });
    }

    // ---- own affect (front-end only) -------------------------------------------------------
    // Time-decayed toward neutral 0.5 on every read-modify-write; event nudges are small and
    // ---- idle deliberation: a ReAct map-reduce reasoning loop (DESIGN-deliberation.md) -----------
    // Decompose one thought into atomic sub-questions -> answer them (parallel across worker tabs via
    // mapFn) -> recompose into an insight/goal. NEVER sends. Four brakes: opt-in toggle, curiosity
    // floor, idle gate, min-gap; plus the curiosity DROP makes it self-limiting.
    function deliberateDue() {
      if (!cfg.idleDeliberation || !cfg.ownAffect) return Promise.resolve(false);
      if (typeof cfg.decomposeFn !== 'function' || typeof cfg.mapFn !== 'function' || typeof cfg.reduceFn !== 'function') return Promise.resolve(false);
      return Promise.resolve(store.get(DELIB_KEY)).then(function (rec) {
        if (rec && (clock.now() - (rec.lastAt || 0)) < (cfg.deliberateMinGapMs || 600000)) return false;   // min-gap
        return channelIsIdle().then(function (idle) {
          if (!idle) return false;                                  // idle gate
          return affectLoad().then(function (a) {
            return (a && (a.curiosity || 0) >= (cfg.deliberateCuriosityFloor || 0.62)) ||   // curiosity gate
              dueSelfIntent('revisit').then(function (it) { return !!it; });   // ...OR a revisit it scheduled for itself is due (it follows through even if curiosity has settled)
          });
        });
      });
    }
    // Pick a seed from the workspace by mode (falls back to partitions when working memory is off).
    function deliberateSeed() {
      // A self-scheduled revisit takes precedence: it comes back to a subject it earlier found worth
      // re-thinking. Consume it (one-shot) and re-approach it fresh, flagged so it won't re-schedule itself.
      return dueSelfIntent('revisit').then(function (it) {
        if (it) return consumeSelfIntent(it.id).then(function () {
          return { mode: 'curiosity', subject: it.subject, prompt: 'coming back to this \u2014 what\u2019s still open or worth resolving about: ' + it.subject, fromRevisit: true };
        });
        var wmOn = !!cfg.workingMemory;
        return (wmOn ? workLoad() : Promise.resolve(null)).then(function (w) {
          if (w && w.goal) return { mode: 'prepare', subject: w.goal, prompt: 'the goal: ' + w.goal };
          if (w && w.topic) return { mode: 'curiosity', subject: w.topic, prompt: 'what\u2019s interesting or unresolved about: ' + w.topic };
          // fallback / deepen: a recent active person with facts but room to synthesize
          return getRoster().then(function (roster) {
            var who = (roster || []).filter(function (p) { return p && p.state === 'active' && Array.isArray(p.facts) && p.facts.length >= 3; })[0];
            if (who) return { mode: 'deepen', subject: who.name, who: who.id, prompt: 'what the things you know about ' + who.name + ' add up to', facts: who.facts.map(function (f) { return f.text; }) };
            return null;
          });
        });
      });
    }
    function deliberate() {
      return deliberateDue().then(function (due) {
        if (!due) return null;
        return deliberateSeed().then(function (seed) {
          if (!seed) return null;
          log('[chloe.think] thinking about ' + seed.subject + ' (' + seed.mode + ')');
          // 1) decompose into atomic, INDEPENDENT sub-questions
          return Promise.resolve(cfg.decomposeFn({ subject: seed.subject, prompt: seed.prompt, facts: seed.facts || null, max: cfg.deliberateMaxSubQuestions || 4 })).then(function (dr) {
            var qs = (dr && dr.ok && Array.isArray(dr.value)) ? dr.value.filter(function (q) { return typeof q === 'string' && q.trim(); }).slice(0, cfg.deliberateMaxSubQuestions || 4) : [];
            if (qs.length < 2) { log('[chloe.think] nothing worth breaking down'); return bumpDelib(null); }
            log('[chloe.think] broke it into ' + qs.length + ' questions');
            // 2) MAP: answer each independently, in parallel across workers (mapFn batches)
            var jobs = qs.map(function (q) { return { question: q, subject: seed.subject, facts: seed.facts || null }; });
            return Promise.resolve(cfg.mapFn(jobs)).then(function (answers) {
              var subAnswers = (answers || []).map(function (r, i) { return { q: qs[i], a: (r && r.ok && r.value) ? String(r.value) : null }; }).filter(function (x) { return x.a; });
              if (!subAnswers.length) { log('[chloe.think] couldn\u2019t work the questions'); return bumpDelib(null); }
              log('[chloe.think] considered ' + subAnswers.length + ' in parallel');
              // 3) REDUCE: recompose into one synthesis + a type tag
              return Promise.resolve(cfg.reduceFn({ subject: seed.subject, mode: seed.mode, parts: subAnswers })).then(function (rr) {
                var syn = (rr && rr.ok && rr.value) ? rr.value : null;
                var text = syn && (syn.text || (typeof syn === 'string' ? syn : null));
                var type = (syn && syn.type) ? String(syn.type) : 'none';
                if (!text || type === 'none') { log('[chloe.think] concluded: nothing new'); return bumpDelib(null); }
                // PREEMPTION: a real message may have arrived mid-deliberation -> re-check idle before storing.
                return channelIsIdle().then(function (stillIdle) {
                  if (!stillIdle) { log('[chloe.think] room woke \u2014 discarding the thought'); return bumpDelib(null); }
                  return deliberateWriteBack(seed, type, text).then(function (stored) {
                    log('[chloe.think] concluded: ' + String(text).slice(0, 80));
                    // self-scheduled future cognition: if this was a SPONTANEOUS conclusion worth keeping
                    // (not itself a revisit), schedule a single later revisit of the subject — it'll come
                    // back to it on its own. Revisit-triggered deliberations don't re-schedule (no loop).
                    var sched = (stored && !seed.fromRevisit && cfg.deferredIntents && seed.subject)
                      ? scheduleSelfIntent('revisit', cfg.selfIntentRevisitMs || 21600000, { subject: seed.subject })
                      : Promise.resolve(null);
                    // curiosity drop (self-limiting) + min-gap stamp
                    return sched.then(function () { return affectNudge({ curiosity: -(cfg.deliberateCuriosityDrop || 0.18) }); }).then(function () { return bumpDelib(stored ? { type: type, text: text } : null); });
                  });
                });
              });
            });
          });
        });
      }, function () { return null; });
    }
    function bumpDelib(result) { return store.set(DELIB_KEY, { lastAt: clock.now() }).then(function () { return result; }); }
    // Write the synthesis through an EXISTING writer, re-validated. Insight -> the subject person's
    // insight list (deepen); goal -> a goal for the subject's owner (prepare); else an episode.
    function deliberateWriteBack(seed, type, text) {
      var t = String(text).trim().slice(0, 200);
      if (type === 'goal' && cfg.goalObjects && seed.who) {
        return addGoal(t, seed.who, seed.subject, 'deliberate').then(function () { return true; });
      }
      if (type === 'insight' && seed.who) {
        return Promise.resolve(userStore().get(partKey(seed.who))).then(function (p) {
          if (!p) return false;
          var ins = Array.isArray(p.insights) ? p.insights : [];
          var nk = normFact(t);
          if (ins.some(function (x) { return normFact(x.text) === nk; })) return false;   // dedupe
          ins.push({ id: 'd' + clock.now().toString(36), text: t, at: clock.now(), source: 'deliberate' });
          if (ins.length > (cfg.insightsPerUser || 3)) ins = ins.slice(-(cfg.insightsPerUser || 3));
          p.insights = ins;
          return userStore().set(partKey(p.id), p).then(function () { return true; });
        });
      }
      // default: record it as an episode (a thought it had), if episodic memory is on
      if (cfg.episodicMemory) {
        return Promise.resolve(store.get(EPI_KEY)).then(function (ring) {
          ring = Array.isArray(ring) ? ring : [];
          ring.push({ id: mintEpisodeId(), text: t, at: clock.now(), participants: [], topics: [], importance: 5, relatesTo: null, source: 'deliberate' });
          ring = boundedEvict(ring, cfg.episodesPerChannel);
          return store.set(EPI_KEY, ring).then(function () { return true; });
        });
      }
      return Promise.resolve(false);
    }

    // ---- working memory: a volatile cognitive workspace (DESIGN-working-memory.md) ---------------
    // Read the workspace with read-time decay applied (like affect): a stale topic goes null rather
    // than asserting a "current topic" that's actually old; decisions age out; participants are always
    // recomputed live from the speaker ring.
    function workLoad() {
      return Promise.resolve(store.get(WORK_KEY)).then(function (w) {
        var now = clock.now();
        w = w || { topic: null, topicAt: 0, goal: null, recentDecisions: [], at: now };
        // topic decay: past the TTL of inactivity, we no longer claim to know the topic.
        if (w.topic && (now - (w.topicAt || 0)) > (cfg.workTopicTtlMs || 1200000)) { w.topic = null; }
        // decision ring decay: drop entries older than their TTL, cap the ring.
        var dttl = cfg.workDecisionTtlMs || 1800000;
        w.recentDecisions = (w.recentDecisions || []).filter(function (d) { return (now - (d.at || 0)) <= dttl; }).slice(-(cfg.workDecisionsMax || 5));
        return w;
      });
    }
    function workSave(w) { w.at = clock.now(); return store.set(WORK_KEY, w).then(function () { return w; }); }
    // Record one notable action it just took (reply / decline / greet / poll / volunteer). Local-only.
    function noteDecision(text) {
      if (!cfg.workingMemory || !text) return Promise.resolve(null);
      return workLoad().then(function (w) {
        w.recentDecisions.push({ text: String(text).slice(0, 80), at: clock.now() });
        if (w.recentDecisions.length > (cfg.workDecisionsMax || 5)) w.recentDecisions = w.recentDecisions.slice(-(cfg.workDecisionsMax || 5));
        return workSave(w);
      });
    }
    // Live participants from the speaker ring -> names (no new cost; the ring is already maintained).
    function workParticipants() {
      return getSpeakerRing().then(function (ring) {
        var ids = []; (ring || []).slice(-(cfg.workParticipantsMax || 5) * 2).forEach(function (id) { if (ids.indexOf(id) < 0) ids.push(id); });
        ids = ids.slice(-(cfg.workParticipantsMax || 5));
        return Promise.all(ids.map(function (id) { return Promise.resolve(userStore().get(partKey(id))).then(function (p) { return (p && p.name) || null; }); }))
          .then(function (names) { return names.filter(Boolean); });
      });
    }
    // The active goal: the highest-priority open goal owned by a current participant.
    function workActiveGoal(participantIds) {
      if (!participantIds || !participantIds.length) return Promise.resolve(null);
      return loadGoals().then(function (list) {
        var open = (list || []).filter(function (g) { return g.status === 'open' && participantIds.indexOf(g.owner) >= 0; });
        if (!open.length) return null;
        open.sort(function (a, b) { return (b.lastTouchedAt || b.createdAt || 0) - (a.lastTouchedAt || a.createdAt || 0); });
        return open[0].text || null;
      });
    }
    // Name the current topic by REUSING the channel summary's first clause when it's fresh (no AI
    // cost). When there's no fresh summary we leave the topic as-is and let it decay — naming it is
    // never worth a dedicated AI call here.
    function workRefreshTopic(w, summaryText) {
      var now = clock.now();
      if (summaryText) {
        // reuse: first sentence/clause of the rolling summary, clipped to a short phrase.
        var first = String(summaryText).split(/[.!?\n]/)[0].trim().slice(0, 60);
        if (first) { w.topic = first; w.topicAt = now; }
        return Promise.resolve(w);
      }
      return Promise.resolve(w);   // no fresh summary -> leave topic as-is (it'll decay if it ages)
    }
    // Assemble/update the whole workspace from current signals. Called on the idle/poll cadence.
    function workSync(summaryText) {
      if (!cfg.workingMemory) return Promise.resolve(null);
      return workLoad().then(function (w) {
        return workParticipants().then(function (names) {
          return getSpeakerRing().then(function (ring) {
            var ids = []; (ring || []).forEach(function (id) { if (ids.indexOf(id) < 0) ids.push(id); });
            return workActiveGoal(ids).then(function (goal) {
              w.participants = names; w.goal = goal;
              return (cfg.ownAffect ? affectLoad() : Promise.resolve(null)).then(function (a) {
                w.mood = a ? moodWord(a) : null;
                return workRefreshTopic(w, summaryText).then(function () {
                  return workSave(w).then(function () { return w; });
                });
              });
            });
          });
        });
      });
    }
    function moodWord(a) {
      if (!a) return null;
      var c = a.curiosity || 0.5, cf = a.confidence || 0.5, wm = a.warmth || 0.5;
      if (c >= 0.65) return 'curious';
      if (wm >= 0.65) return 'warm';
      if (cf <= 0.4) return 'subdued';
      if (cf >= 0.65) return 'assured';
      return 'steady';
    }

    // clamped; confidence has a hard floor (quieter, never despondent).
    function affectLoad() {
      return Promise.resolve(store.get(AFFECT_KEY)).then(function (a) {
        var now = clock.now();
        a = a || { curiosity: 0.5, confidence: 0.5, warmth: 0.5, at: now };
        var hours = Math.max(0, now - (a.at || now)) / 3600000;
        var mult = Math.pow(cfg.affectDecayPerHour || 0.8, hours);
        ['curiosity', 'confidence', 'warmth'].forEach(function (k) { a[k] = 0.5 + ((a[k] != null ? a[k] : 0.5) - 0.5) * mult; });
        a.at = now;
        return a;
      });
    }
    function affectNudge(deltas) {
      if (!cfg.ownAffect) return Promise.resolve(null);
      return affectLoad().then(function (a) {
        Object.keys(deltas || {}).forEach(function (k) {
          if (a[k] == null) return;
          a[k] = Math.max(0, Math.min(1, a[k] + deltas[k]));
        });
        a.confidence = Math.max(cfg.affectConfidenceFloor || 0.3, a.confidence);   // the floor: no spirals
        return store.set(AFFECT_KEY, a).then(function () { return a; });
      });
    }
    // Engagement tracking: did anyone keep talking after its last reply?
    var affectReply = { at: 0, settled: true };
    function affectOnHerReply() { if (cfg.ownAffect) { affectReply.at = clock.now(); affectReply.settled = false; } }
    function affectOnUserMessage() {
      if (!cfg.ownAffect || affectReply.settled || !affectReply.at) return Promise.resolve(null);
      var gap = clock.now() - affectReply.at;
      affectReply.settled = true;
      if (gap <= (cfg.affectEngageWindowMs || 600000)) return affectNudge({ confidence: (cfg.affectGain || 0.08), warmth: (cfg.affectGain || 0.08) / 2 });
      return Promise.resolve(null);
    }
    function affectTick() {
      if (!cfg.ownAffect || affectReply.settled || !affectReply.at) return Promise.resolve(null);
      if (clock.now() - affectReply.at > (cfg.affectIgnoreAfterMs || 1800000)) {
        affectReply.settled = true;
        return affectNudge({ confidence: -(cfg.affectGain || 0.08) });
      }
      return Promise.resolve(null);
    }
    // Curiosity: token novelty vs a small rolling vocabulary of the room's recent talk.
    var affectVocab = {}; var affectVocabKeys = [];
    function affectOnContent(text) {
      if (!cfg.ownAffect) return Promise.resolve(null);
      var toks = String(text || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(function (w) { return w.length >= 4; });
      if (toks.length < 5) { toks.forEach(remember); return Promise.resolve(null); }
      var unseen = 0;
      toks.forEach(function (w) { if (!affectVocab[w]) unseen++; });
      var novel = unseen / toks.length > 0.6;
      toks.forEach(remember);
      function remember(w) { if (!affectVocab[w]) { affectVocab[w] = true; affectVocabKeys.push(w); if (affectVocabKeys.length > 300) { delete affectVocab[affectVocabKeys.shift()]; } } }
      return novel ? affectNudge({ curiosity: (cfg.affectGain || 0.08) }) : Promise.resolve(null);
    }

    // Trust earning: positive-only, clamped 0-100, capped per person per day (UTC day bucket).
    function applyTrust(pp, amount, now) {
      if (!cfg.relationshipTrust || !pp || !(amount > 0)) return false;
      var day = Math.floor(now / 86400000);
      if (pp.trustDay !== day) { pp.trustDay = day; pp.trustDayEarned = 0; }
      var room = (cfg.trustDailyCap || 5) - (pp.trustDayEarned || 0);
      if (room <= 0) return false;
      var gain = Math.min(amount, room);
      pp.trust = Math.max(0, Math.min(100, (pp.trust || 0) + gain));
      pp.trustDayEarned = (pp.trustDayEarned || 0) + gain;
      return true;
    }
    function addTrust(id, amount) {
      return Promise.resolve(userStore().get(partKey(id))).then(function (pp) {
        if (!pp) return false;
        var changed = applyTrust(pp, amount, clock.now());
        // item 3: a POSITIVE reaction is a 'reward' for the bond (the one negative-free signal we can read cleanly;
        // negative sentiment is NOT guessed). Updates even if trust is capped, so the bond still accrues.
        var bondChanged = false;
        if (cfg.bondLadder && amount > 0) { try { var bb = makeBond({ state: pp.bond }); var br = bb.update({ kind: 'reward', now: clock.now() }); pp.bond = bb.serialize(); bondChanged = true; if (br.promoted) log('[wire:bond] ' + (pp.name || id) + ' -> ' + br.tier + ' (reward, ' + br.value + ')'); } catch (e) { log('[wire:bond] reward update threw', (e && e.message) || e); } }
        if (!changed && !bondChanged) return false;
        return userStore().set(partKey(id), pp).then(function () { return true; });
      });
    }
    function bumpInteraction(id) {
      // Re-read the partition immediately before writing so we start from the freshest snapshot.
      // This minimises (but cannot fully eliminate without a true atomic RMW) the window where a
      // concurrent ingestOneCore write could be overwritten. bumpInteraction ONLY touches its own
      // fields (interactionCount, lastChloeReplyTo, trust) — it never clobbers recent/lastSeen/name.
      affectOnHerReply();   // open the engagement window (own affect) — fire-and-forget, before the read
      return Promise.resolve(userStore().get(partKey(id))).then(function (pp) {
        if (!pp) return;
        pp.interactionCount = (pp.interactionCount || 0) + 1;
        pp.lastChloeReplyTo = clock.now();
        applyTrust(pp, cfg.trustReplyGain || 1, clock.now());
        if (cfg.bondLadder) { try { var bb = makeBond({ state: pp.bond }); var br = bb.update({ kind: 'conversation', now: clock.now() }); pp.bond = bb.serialize(); if (br.promoted) log('[wire:bond] ' + (pp.name || id) + ' -> ' + br.tier + ' (' + br.value + ')'); } catch (e) { log('[wire:bond] conversation update threw', (e && e.message) || e); } }   // item 3: a reply exchange grows the bond (additive; interactionCount/trust untouched)
        return userStore().set(partKey(id), pp);
      });
    }

    // ---- roster read ---------------------------------------------------------------------
    function getRoster() {
      var ustore = userStore();
      // Converge pre-upgrade per-channel partitions on read: union the legacy local
      // index, migrate anything missing globally, then read the shared pool. After the
      // first poll converges everything, `extra` is empty and this is one extra index read.
      function withMigration() {
        if (!sharedUsers()) return Promise.resolve(null);
        return Promise.resolve(localRaw.listIndex()).then(function (lids) {
          return Promise.resolve(ustore.listIndex()).then(function (gids) {
            gids = gids || [];
            var extra = (lids || []).filter(function (id) { return gids.indexOf(id) < 0; });
            if (!extra.length) return gids;
            var chain = Promise.resolve();
            extra.forEach(function (id) {
              chain = chain.then(function () {
                return Promise.resolve(localRaw.get(partKey(id))).then(function (legacy) {
                  if (!legacy) return;
                  return Promise.resolve(mergeLegacyPartition(legacy)).catch(function () {});
                });
              });
            });
            return chain.then(function () { return ustore.listIndex(); });
          });
        });
      }
      return withMigration().then(function () {
        return Promise.resolve(ustore.listIndex()).then(function (ids) {
          return Promise.all((ids || []).map(function (id) { return Promise.resolve(ustore.get(partKey(id))); }));
        });
      }).then(function (parts) {
        // A7: tier rides each row (zero extra reads — the partition IS the resident
        // evidence; admin comes from the mod list). Guests never appear in the roster.
        var mods = (cfg.modList || []);
        return parts.filter(Boolean).sort(function (a, b) { return (b.lastSeen || 0) - (a.lastSeen || 0); }).map(function (a) {
          a.tier = (mods.indexOf(a.id) >= 0) ? 'admin' : 'resident';
          a.tierBasis = a.recognized ? 'recognized' : 'history';
          return a;
        });
      });
    }

    // ---- archive ("historical friends") -----------------------------------------------------
    // Cold records leave the hot store so the main roster stays fast. Per-user keys; an index is kept
    // only for pruning/inspection and is never read on the message hot path.
    function getArchiveIndex() {
      var ustore = userStore();
      return Promise.resolve(ustore.get(archIndexKey())).then(function (a) {
        var out = Array.isArray(a) ? a.slice() : [];
        if (!sharedUsers()) return out;
        return Promise.resolve(ustore.get(legacyArchIndexKey())).then(function (b) {
          (Array.isArray(b) ? b : []).forEach(function (id) { if (out.indexOf(id) < 0) out.push(id); });
          return Promise.resolve(localRaw.get(legacyArchIndexKey())).then(function (c) {
            (Array.isArray(c) ? c : []).forEach(function (id) { if (out.indexOf(id) < 0) out.push(id); });
            return out;
          }, function () { return out; });
        }, function () { return out; });
      });
    }
    // Completely remove a user's cold archive record (data + index entry). Used by purge/block so an
    // erasure is total — otherwise an archived user who is blocked keeps their cold copy, and the
    // novelty check would still report them "known from archive" after they were supposedly forgotten.
    function dropFromArchive(id) {
      var sid = String(id || '');
      var ustore = userStore();
      function stripIndex(getter, setter) {
        return Promise.resolve(getter()).then(function (idx) {
          if (!Array.isArray(idx) || idx.indexOf(sid) < 0) return;
          idx.splice(idx.indexOf(sid), 1);
          return Promise.resolve(setter(idx)).catch(function () {});
        }).catch(function () {});
      }
      return Promise.resolve(ustore.del(archKey(sid))).catch(function () {})
        .then(function () { return Promise.resolve(ustore.del(legacyArchKey(sid))).catch(function () {}); })
        .then(function () { return Promise.resolve(localRaw.del(legacyArchKey(sid))).catch(function () {}); })
        .then(function () { return stripIndex(function () { return ustore.get(archIndexKey()); }, function (idx) { return ustore.set(archIndexKey(), idx); }); })
        .then(function () { return stripIndex(function () { return ustore.get(legacyArchIndexKey()); }, function (idx) { return ustore.set(legacyArchIndexKey(), idx); }); })
        .then(function () { return stripIndex(function () { return localRaw.get(legacyArchIndexKey()); }, function (idx) { return localRaw.set(legacyArchIndexKey(), idx); }); });
    }
    // Before calling anyone "new", check the surfaces a known person can hide in even when they're
    // absent from the hot roster: the cold archive ("historical friends"), the mod log (someone we
    // warned/timed-out/noted), and the blocklist/tombstones (a banned user whose partition was purged).
    // Presence on ANY of these means we've met them — so they must not be greeted/prioritized as a
    // first-timer. (The archive is also restored separately on the hot path; this catches the cases
    // where archiving is off or the partition was deleted.)
    function knownFromOtherSurfaces(id, name) {
      var sid = String(id || '');
      // In a DM, a person known on the PUBLIC side is not a first-timer here — recognize them so the
      // bot doesn't greet a regular as a stranger when they first slide into DMs (read-only check).
      var dmPublic = (cfg.isDM && cfg.globalStore && cfg.globalStore !== store)
        ? Promise.resolve(cfg.globalStore.get(partKey(sid))).then(function (pub) { return pub ? { known: true, where: 'public' } : null; }, function () { return null; })
        : Promise.resolve(null);
      return dmPublic.then(function (dm) {
        if (dm) return dm;
        return getArchiveIndex().then(function (idx) {
          if (sid && idx.indexOf(sid) >= 0) return { known: true, where: 'archive' };
          return getModLog().then(function (log) {
            if (sid && (log || []).some(function (e) { return String(e && e.targetId) === sid; })) return { known: true, where: 'modlog' };
            return Promise.resolve(blockStore().get(BLOCK_KEY)).then(function (bl) {
              bl = bl || { ids: {}, names: {} };
              if (isBlockedSync(bl, sid, name)) return { known: true, where: 'blocklist' };
              return { known: false, where: null };
            });
          });
        });
      });
    }
    function archiveUser(id, reason) {
      var ustore = userStore();
      return Promise.resolve(ustore.get(partKey(id))).then(function (p) {
        if (!p) return { ok: false, reason: 'unknown' };
        p.archivedAt = clock.now(); p.archivedReason = reason || 'stale';
        return Promise.resolve(ustore.set(archKey(id), p))
          .then(function () { return ustore.del(partKey(id)); })
          .then(function () { return removeFromIndex(id); })
          .then(function () { return ustore.get(archIndexKey()); })
          .then(function (idx) {
            idx = Array.isArray(idx) ? idx : [];
            if (idx.indexOf(id) < 0) idx.push(id);
            if (idx.length > cfg.archiveMaxKept) {   // prune the oldest archived ids (cold-cold)
              var drop = idx.splice(0, idx.length - cfg.archiveMaxKept);
              return Promise.all(drop.map(function (d) { return Promise.resolve(ustore.del(archKey(d))); })).then(function () { return ustore.set(archIndexKey(), idx); });
            }
            return ustore.set(archIndexKey(), idx);
          })
          .then(function () { log('[chloe.archive] moved ' + (p.name || id) + ' to historical friends (' + (reason || 'stale') + ')'); return { ok: true, name: p.name || id }; });
      });
    }
    // Restore a returning friend from cold storage so their history (interaction count, summary,
    // first-seen) is preserved rather than starting from zero. Returns the restored partition or null.
    function restoreFromArchive(id) {
      var ustore = userStore();
      function commit(p) {
        delete p.archivedAt; delete p.archivedReason;
        // Durability: commit the hot copy and re-index FIRST, then delete the cold copy. The reverse
        // order (the previous behavior) destroyed the only copy before the hot write landed, so a
        // throw or a closed tab mid-restore lost the user's entire history. Worst case now is a
        // harmless duplicate (cold + hot) that the next sweep reconciles — never data loss.
        return Promise.resolve(ustore.set(partKey(id), p))
          .then(function () { return ensureIndexed(id); })
          .then(function () { return dropFromArchive(id); })   // clears live + legacy cold copies
          .then(function () { return clearCheckinRecord(id); })   // fresh start: they came back
          .then(function () { log('[chloe.archive] restored ' + (p.name || id) + ' from historical friends'); return p; });
      }
      return Promise.resolve(ustore.get(archKey(id))).then(function (p) {
        if (p) return commit(p);
        // legacy per-channel cold copies (pre-upgrade): own channel's key, in either bucket
        return Promise.resolve(ustore.get(legacyArchKey(id))).then(function (p2) {
          if (p2) return commit(p2);
          return Promise.resolve(localRaw.get(legacyArchKey(id))).then(function (p3) {
            return p3 ? commit(p3) : null;
          }, function () { return null; });
        }, function () { return null; });
      });
    }
    function clearCheckinRecord(id) {
      return Promise.resolve(store.get(CHECKIN_KEY)).then(function (ci) {
        if (!ci || !ci.byUser || ci.byUser[id] == null) return null;
        delete ci.byUser[id]; return store.set(CHECKIN_KEY, ci);
      });
    }
    // How long a user is kept in the fast store before archival — extended for favorites (warmth buys
    // patience). archiveAbsenceMs base + one bonus window per favorite tier of interactions.
    function archiveThresholdFor(p) {
      var tiers = Math.floor((p.interactionCount || 0) / (cfg.archiveFavoriteTier || 8));
      return cfg.archiveAbsenceMs + tiers * (cfg.archiveFavoriteBonusMs || 0);
    }

    // G5: a light, human sense of time. Derived purely from the clock + the community's UTC offset
    // (Discord stamps are UTC), plus how long the room has been quiet. Returned as plain descriptors
    // the brain can lean on softly — never as a timestamp to recite.
    function partOfDay(h) {
      if (h < 5) return 'the middle of the night';
      if (h < 9) return 'early morning';
      if (h < 12) return 'morning';
      if (h < 14) return 'midday';
      if (h < 18) return 'afternoon';
      if (h < 22) return 'evening';
      return 'late evening';
    }
    function timeContext(lastActivity) {
      var tabNow = clock.now();
      var now = tabNow;
      // Anchor to Discord's authoritative server time if the local tab clock looks implausible — a
      // sandboxed / misconfigured / long-suspended tab can report a wildly wrong wall clock, and a
      // message snowflake is server-truth. Only a gross (>1 day) disagreement flips the source, so a
      // normal tab always keeps its own wall clock (which is correct even when the channel is quiet).
      if (lastSeenAt > 0 && Math.abs(tabNow - lastSeenAt) > 86400000) now = lastSeenAt;
      var local = new Date(now + (cfg.timezoneOffsetMins || 0) * 60000);
      var h = local.getUTCHours();   // getUTC* on the already-shifted instant = local wall clock
      var dow = local.getUTCDay();   // 0 = Sunday
      var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      var tc = { partOfDay: partOfDay(h), hour: h, dayOfWeek: days[dow], weekend: (dow === 0 || dow === 6), lateNight: (h < 5 || h >= 23) };
      if (lastActivity != null) {
        var q = tabNow - lastActivity;   // duration uses the tab clock for BOTH ends — the delta is right even if the absolute clock is off
        tc.quietForMs = q;
        tc.quietFor = (q < 600000) ? null                         // <10m: not worth mentioning
          : (q < 3600000) ? 'a little while'
          : (q < 21600000) ? 'a few hours'
          : (q < 86400000) ? 'most of the day'
          : 'a day or more';
      }
      return tc;
    }

    // G6 mood: read the room's tenor from cheap, front-end signals — no AI call. Two safe dimensions:
    // energy (how lively/fast) and playfulness (how joking/warm). We never try to detect anger; a
    // wrong "the room is angry" read is worse than none. Per batch we extract signals from human
    // messages, then blend into a decayed state so mood drifts rather than snapping.
    function moodSignals(humanMsgs, avgGapMs) {
      if (!humanMsgs.length) return null;
      var laugh = 0, excl = 0, emoji = 0, caps = 0, qs = 0, totalLen = 0;
      var laughRe = /\b(lol|lmao|lmfao|rofl|haha+|hehe+|heh)\b|😂|🤣|😹/i;
      var emojiRe = /[\u231A-\uD83F\uDC00-\uDFFF\u2600-\u27BF\uFE0F\u2190-\u21FF\u2B00-\u2BFF]/;
      humanMsgs.forEach(function (t) {
        t = String(t || '');
        totalLen += t.length;
        if (laughRe.test(t)) laugh++;
        if (t.indexOf('!') >= 0) excl++;
        if (emojiRe.test(t)) emoji++;
        if (/\?/.test(t)) qs++;
        var words = t.split(/\s+/).filter(function (w) { return w.length >= 3; });
        if (words.some(function (w) { return w === w.toUpperCase() && /[A-Z]/.test(w); })) caps++;
      });
      var n = humanMsgs.length;
      var avgLen = totalLen / n;
      // pace: faster average gap -> higher energy (cap the influence)
      var pace = (avgGapMs && avgGapMs > 0) ? Math.max(0, Math.min(1, 1 - (avgGapMs / 120000))) : 0.5;  // <2min gaps feel live
      var energy = Math.max(0, Math.min(1, 0.35 * pace + 0.30 * Math.min(1, n / 6) + 0.20 * (excl / n) + 0.15 * (avgLen < 40 ? 0.8 : 0.3)));
      var playful = Math.max(0, Math.min(1, 0.5 * Math.min(1, laugh / Math.max(1, n * 0.5)) + 0.3 * Math.min(1, emoji / n) + 0.2 * Math.min(1, excl / n)));
      return { energy: energy, playful: playful };
    }
    function updateMood(humanMsgs, avgGapMs) {
      if (!cfg.moodAware) return Promise.resolve(null);
      var sig = moodSignals(humanMsgs, avgGapMs);
      if (!sig) return Promise.resolve(null);
      return Promise.resolve(store.get(MOOD_KEY)).then(function (m) {
        var d = cfg.moodDecay;
        m = (m && typeof m === 'object') ? m : { energy: 0.5, playful: 0.4, samples: 0 };
        m.energy = m.energy * d + sig.energy * (1 - d);
        m.playful = m.playful * d + sig.playful * (1 - d);
        m.samples = (m.samples || 0) + humanMsgs.length;
        m.at = clock.now();
        return store.set(MOOD_KEY, m).then(function () { return m; });
      });
    }
    function moodDescriptor(m) {
      if (!m) return '';
      var e = m.energy, p = m.playful;
      var energyWord = e < 0.3 ? 'quiet and slow' : e < 0.55 ? 'relaxed' : e < 0.8 ? 'lively' : 'buzzing with energy';
      var playWord = p > 0.6 ? ' and playful' : p > 0.35 ? ' and easygoing' : '';
      return energyWord + playWord;
    }

    // ---- F1 fact memory ---------------------------------------------------------------------
    // Durable facts about a person live on their partition (so they archive/restore for free). Each
    // fact is { text, at, source }. Storage is conservative: capped, deduped, and the extraction
    // prompt (page side) refuses sensitive categories. Users can see and forget what's stored.
    function normFact(t) { return String(t || '').toLowerCase().replace(/[^a-z0-9 ]+/g, '').replace(/\s+/g, ' ').trim(); }
    // Conservative contradiction detector (DESIGN-contradiction). HIGH PRECISION, low recall by design:
    // a false positive (nagging about a non-conflict) is worse than a miss. Fires only on a clear
    // POLARITY FLIP (one side negative/antonym, the other not) over SHARED content words — e.g. "likes
    // minecraft" vs "dislikes minecraft", "is a teacher" vs "is not a teacher". Returns the conflicting
    // held fact text, or null. Antonyms beyond like/dislike/love/hate are intentionally NOT chased.
    var CONTRA_NEG = { not: 1, never: 1, no: 1, longer: 1, dislike: 1, dislikes: 1, disliked: 1, hate: 1, hates: 1, hated: 1, stopped: 1, quit: 1, former: 1, formerly: 1, ex: 1, isnt: 1, arent: 1, aren: 1, doesnt: 1, dont: 1, didnt: 1, cant: 1, wont: 1, wasnt: 1, anymore: 1 };
    var CONTRA_STOP = { a: 1, an: 1, the: 1, is: 1, are: 1, was: 1, were: 1, be: 1, been: 1, to: 1, of: 1, in: 1, on: 1, at: 1, and: 1, or: 1, but: 1, with: 1, for: 1, that: 1, this: 1, it: 1, they: 1, he: 1, she: 1, has: 1, have: 1, had: 1, do: 1, does: 1, did: 1, will: 1, would: 1, their: 1, them: 1, his: 1, her: 1, you: 1, your: 1, i: 1, my: 1, me: 1, we: 1, us: 1, as: 1, so: 1, up: 1, out: 1, now: 1, very: 1, really: 1 };
    function contraParse(norm) {
      var neg = false, content = [];
      norm.split(' ').forEach(function (w) {
        if (!w) return;
        if (CONTRA_NEG[w]) { neg = true; return; }     // a polarity word: flips sign, not content
        if (CONTRA_STOP[w] || w.length < 3) return;     // stopword / too short to anchor a topic
        content.push(w);
      });
      return { neg: neg, content: content };
    }
    function detectContradiction(newText, heldFacts) {
      var n = contraParse(normFact(newText));
      if (!n.content.length) return null;
      for (var i = 0; i < heldFacts.length; i++) {
        var h = heldFacts[i]; if (!h || !h.text) continue;
        var hp = contraParse(normFact(h.text));
        if (!hp.content.length) continue;
        if (n.neg === hp.neg) continue;   // same polarity -> not a flip
        var setN = {}; n.content.forEach(function (w) { setN[w] = 1; });
        var shared = hp.content.filter(function (w) { return setN[w]; }).length;
        // require the smaller fact's topic to be (mostly) shared, so the two are about the same thing
        var minLen = Math.min(n.content.length, hp.content.length);
        if (shared >= 1 && shared >= Math.ceil(minLen / 2)) return h.text;
      }
      return null;
    }
    function getFacts(id) {
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) { return (p && Array.isArray(p.facts)) ? p.facts : []; });
    }
    // Merge newly-proposed fact strings into a user's store. Dedupes against existing (normalized),
    // caps to factsPerUser (newest kept). Returns the count actually added.
    function addFacts(id, proposed, source) {
      if (!proposed || !proposed.length) return Promise.resolve(0);
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (!p) return 0;
        var facts = Array.isArray(p.facts) ? p.facts : [];
        var seen = {}; facts.forEach(function (f) { seen[normFact(f.text)] = true; });
        var added = 0, impAdded = 0;
        proposed.forEach(function (raw) {
          // accept {text/t, importance/i} objects or bare strings (back-compat)
          var text, imp;
          if (raw && typeof raw === 'object') { text = String(raw.text != null ? raw.text : raw.t || '').trim().slice(0, cfg.factTextMax); imp = Math.max(1, Math.min(10, Math.round(Number(raw.importance != null ? raw.importance : raw.i)) || (cfg.factImportanceDefault || 5))); }
          else { text = String(raw || '').trim().slice(0, cfg.factTextMax); imp = cfg.factImportanceDefault || 5; }
          var key = normFact(text);
          if (!key || seen[key]) return;          // empty or duplicate
          // contradiction flag (DESIGN-contradiction): if this new fact clearly flips polarity on a
          // held one, KEEP BOTH (don't let consolidation silently drop the older side) and record the
          // conflict so it can gently clarify. Only for facts that matter (importance floor).
          if (cfg.contradictionAware && imp >= (cfg.contradictionImportanceFloor || 5)) {
            var clash = detectContradiction(text, facts);
            if (clash) { p.conflict = { a: clash, b: text, at: clock.now() }; log('[chloe.fact] noted a conflict for ' + (p.name || p.id) + ': "' + String(clash).slice(0, 40) + '" vs "' + String(text).slice(0, 40) + '"'); }
          }
          seen[key] = true; facts.push({ id: mintFactId(), text: text, at: clock.now(), source: source || 'observed', importance: imp }); added++; impAdded += imp;
        });
        if (!added) return 0;
        facts = boundedEvict(facts, cfg.factsPerUser, function (f) { return f.source === 'operator'; });   // keep newest, never evict operator-pinned facts
        p.facts = facts; p.factsAt = clock.now();
        // reflection fuel: accumulate the importance of what we learned (Step 3 reads this threshold)
        p.reflectImportanceAccum = (p.reflectImportanceAccum || 0) + impAdded;
        return userStore().set(partKey(id), p).then(function () { return added; });
      });
    }
    function forgetFact(id, match) {
      var m = normFact(match);
      if (!m) return Promise.resolve(0);
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (!p || !Array.isArray(p.facts)) return 0;
        var before = p.facts.length;
        p.facts = p.facts.filter(function (f) { return normFact(f.text).indexOf(m) < 0; });
        var removed = before - p.facts.length;
        if (!removed) return 0;
        return userStore().set(partKey(id), p).then(function () { return removed; });
      });
    }

    // ---- context moderation: excise a message from its working memory (DESIGN-excise.md) ----------
    // Remove the line with this message id from whichever user's `recent` window holds it. This is the
    // ONLY place a message is stored by message-id; the speaker ring holds author ids (untouched), and
    // any fact/episode already distilled from it is a separate artifact (excise composes with the
    // People-drawer CRUD, it doesn't cascade). Cross-partition because the operator knows the message,
    // not whose window it's in. Returns { removed, fromUser }.
    function exciseMessage(msgId) {
      var target = String(msgId || '');
      if (!target) return Promise.resolve({ removed: 0, fromUser: null });
      return getRoster().then(function (roster) {
        var chain = Promise.resolve(), removed = 0, fromUser = null;
        roster.forEach(function (p) {
          chain = chain.then(function () {
            if (!p || !Array.isArray(p.recent) || !p.recent.length) return;
            var before = p.recent.length;
            p.recent = p.recent.filter(function (ln) { return String(ln.id) !== target; });
            var n = before - p.recent.length;
            if (n) { removed += n; fromUser = fromUser || p.name || p.id; return userStore().set(partKey(p.id), p); }
          });
        });
        return chain.then(function () {
          if (removed) log('[chloe.excise] removed ' + removed + ' line(s) from working memory');
          return { removed: removed, fromUser: fromUser };
        });
      });
    }
    // Drop the last n lines from one user's recent window ("delete that last thing they said").
    function exciseLastFromUser(userId, n) {
      var k = Math.max(1, Math.round(Number(n) || 1));
      return Promise.resolve(userStore().get(partKey(userId))).then(function (p) {
        if (!p || !Array.isArray(p.recent) || !p.recent.length) return { removed: 0, fromUser: null };
        var cut = Math.min(k, p.recent.length);
        p.recent = p.recent.slice(0, p.recent.length - cut);
        return userStore().set(partKey(userId), p).then(function () {
          log('[chloe.excise] removed ' + cut + ' recent line(s) from ' + (p.name || userId));
          return { removed: cut, fromUser: p.name || userId };
        });
      });
    }

    // ---- per-person memory CRUD (DESIGN-people-crud.md): edit facts + insights by STABLE id -------
    var factSeq = 0;
    function mintFactId() { factSeq++; return 'f' + clock.now().toString(36) + factSeq.toString(36); }
    // Lazy id migration: give any id-less fact/insight a stable id and persist once. Idempotent.
    function migrateMemoryIds(p) {
      var changed = false;
      if (Array.isArray(p.facts)) p.facts.forEach(function (f) { if (f && !f.id) { f.id = mintFactId(); changed = true; } });
      if (Array.isArray(p.insights)) p.insights.forEach(function (x) { if (x && !x.id) { x.id = mintFactId(); changed = true; } });
      return changed;
    }
    // Read one person's editable memory (facts + insights), migrating ids on first read.
    function getMemory(id) {
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (!p) return null;
        var changed = migrateMemoryIds(p);
        var out = {
          id: id, name: p.name || null,
          facts: (p.facts || []).map(function (f) { return { id: f.id, text: f.text, importance: (typeof f.importance === 'number' ? f.importance : (cfg.factImportanceDefault || 5)), source: f.source || 'observed', at: f.at || 0 }; }),
          insights: (p.insights || []).map(function (x) { return { id: x.id, text: x.text, at: x.at || 0 }; })
        };
        return (changed ? userStore().set(partKey(id), p) : Promise.resolve()).then(function () { return out; });
      });
    }
    // Update one fact by id (text and/or importance). Re-dedupes against the others; re-clamps imp.
    function editFact(id, factId, patch) {
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (!p || !Array.isArray(p.facts)) return null;
        migrateMemoryIds(p);
        var target = null; p.facts.forEach(function (f) { if (f.id === factId) target = f; });
        if (!target) return null;
        if (patch && patch.text != null) {
          var newText = String(patch.text).trim().slice(0, cfg.factTextMax || 240);
          if (!newText) return { error: 'empty' };
          var nk = normFact(newText);
          // collision: if another fact already normalizes to this, drop the edited one (merge) by deleting it
          var clash = p.facts.some(function (f) { return f.id !== factId && normFact(f.text) === nk; });
          if (clash) { p.facts = p.facts.filter(function (f) { return f.id !== factId; }); }
          else { target.text = newText; }
        }
        if (patch && patch.importance != null) target.importance = Math.max(1, Math.min(10, Math.round(Number(patch.importance)) || (cfg.factImportanceDefault || 5)));
        if (patch && patch.text != null && target.text) target.source = 'operator';   // a hand-edit makes it operator-owned
        p.factsAt = clock.now();
        return userStore().set(partKey(id), p).then(function () { return { facts: p.facts.map(pubFact) }; });
      });
    }
    function deleteFact(id, factId) {
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (!p || !Array.isArray(p.facts)) return null;
        var before = p.facts.length;
        p.facts = p.facts.filter(function (f) { f.id || (f.id = mintFactId()); return f.id !== factId; });
        if (p.facts.length === before) return { facts: p.facts.map(pubFact) };
        p.factsAt = clock.now();
        return userStore().set(partKey(id), p).then(function () { return { facts: p.facts.map(pubFact) }; });
      });
    }
    // Operator-authored fact: creates the partition row if the person isn't known yet.
    function addUserFact(id, text, importance, name) {
      var t = String(text || '').trim().slice(0, cfg.factTextMax || 240);
      if (!t) return Promise.resolve(null);
      return ensureIndexed(id).then(function () {
        return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
          if (!p) { p = { id: id, name: name || null, facts: [], lastSeen: clock.now(), interactionCount: 0 }; }
          if (!Array.isArray(p.facts)) p.facts = [];
          migrateMemoryIds(p);
          var nk = normFact(t);
          if (p.facts.some(function (f) { return normFact(f.text) === nk; })) return { facts: p.facts.map(pubFact), dup: true };
          var imp = Math.max(1, Math.min(10, Math.round(Number(importance)) || (cfg.factImportanceDefault || 5)));
          p.facts.push({ id: mintFactId(), text: t, at: clock.now(), source: 'operator', importance: imp });
          if (p.facts.length > cfg.factsPerUser) {
            // drop the oldest NON-operator fact to make room (operator intent outranks decay)
            var victim = -1; for (var i = 0; i < p.facts.length; i++) { if (p.facts[i].source !== 'operator') { victim = i; break; } }
            if (victim >= 0) p.facts.splice(victim, 1); else p.facts = p.facts.slice(-cfg.factsPerUser);
          }
          p.factsAt = clock.now();
          return userStore().set(partKey(id), p).then(function () { return { facts: p.facts.map(pubFact) }; });
        });
      });
    }
    function editInsight(id, insId, text) {
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (!p || !Array.isArray(p.insights)) return null;
        migrateMemoryIds(p);
        var t = String(text || '').trim().slice(0, cfg.factTextMax || 240);
        var tgt = null; p.insights.forEach(function (x) { if (x.id === insId) tgt = x; });
        if (!tgt) return null;
        if (!t) { p.insights = p.insights.filter(function (x) { return x.id !== insId; }); }
        else { tgt.text = t; }
        return userStore().set(partKey(id), p).then(function () { return { insights: p.insights.map(function (x) { return { id: x.id, text: x.text, at: x.at || 0 }; }) }; });
      });
    }
    function deleteInsight(id, insId) {
      return Promise.resolve(userStore().get(partKey(id))).then(function (p) {
        if (!p || !Array.isArray(p.insights)) return null;
        p.insights.forEach(function (x) { x.id || (x.id = mintFactId()); });
        p.insights = p.insights.filter(function (x) { return x.id !== insId; });
        return userStore().set(partKey(id), p).then(function () { return { insights: p.insights.map(function (x) { return { id: x.id, text: x.text, at: x.at || 0 }; }) }; });
      });
    }
    function pubFact(f) { return { id: f.id, text: f.text, importance: (typeof f.importance === 'number' ? f.importance : (cfg.factImportanceDefault || 5)), source: f.source || 'observed', at: f.at || 0 }; }
    // A compact one-line synthesis of what it knows about someone — this is what populates the
    // (previously empty) `summary` that already rides into response + check-in context.
    function factSummary(p) {
      if (!p) return '';
      // Insights (reflection's earned, higher-level layer) lead; importance-ranked facts follow.
      var parts = [];
      if (Array.isArray(p.insights) && p.insights.length) {
        parts.push(p.insights.map(function (x) { return x.text; }).join('; '));
      }
      if (Array.isArray(p.facts) && p.facts.length) {
        var n = p.facts.length, def = cfg.factImportanceDefault || 5;
        // rank by importance blended with a mild recency bias; old facts without importance score at the
        // neutral default so nothing is unfairly dropped. Keep the top N, then render in original order.
        var scored = p.facts.map(function (f, idx) {
          var imp = (typeof f.importance === 'number') ? f.importance : def;
          var recency = n > 1 ? (idx / (n - 1)) : 1;   // 0 oldest .. 1 newest
          return { f: f, idx: idx, score: imp + recency * (cfg.factRecencyWeight || 2) };
        });
        scored.sort(function (a, b) { return b.score - a.score; });
        var keep = scored.slice(0, cfg.factContextCount).sort(function (a, b) { return a.idx - b.idx; });
        parts.push(keep.map(function (x) { return x.f.text; }).join('; '));
      }
      return parts.join('; ');
    }
    // Decide whether a user is due for an extraction pass: fact memory on, they're a real regular,
    // enough new messages since the last pass, and the per-user cooldown has elapsed.
    function factProposeDue(p, now) {
      if (!cfg.factMemory) return false;
      if ((p.interactionCount || 0) < cfg.factMinInteractions) return false;
      var newMsgs = (p.interactionCount || 0) - (p.factsBaseline || 0);
      // v0.90.6 repair: the poisoned input line above meant scans advanced factsBaseline/factsAt
      // while learning nothing, so everyone sits inside the 24h gap with empty facts. A user with
      // no facts AND no insights who otherwise qualifies gets ONE repair scan past the gap; the
      // flag is set when the scan runs, so this never repeats and normal cadence resumes after.
      if ((!Array.isArray(p.facts) || !p.facts.length) && (!Array.isArray(p.insights) || !p.insights.length) && !p.factsRepairedV906) return newMsgs >= cfg.factProposeMinNew;
      if (p.factsAt && (now - p.factsAt) < cfg.factProposeGapMs) return false;
      return newMsgs >= cfg.factProposeMinNew;
    }

    function getSpeakerRing() { return Promise.resolve(store.get(RING_KEY)).then(function (r) { return r || []; }); }

    // ---- pace core: one rhythm estimator, several consumers (DESIGN-pace.md) ----------------
    // A short-lived cache of the rhythm record so the per-poll consumers (debounce, polling, quiet)
    // don't each hit the store. Refreshed once per poll in pollOnce's tail.
    var paceCache = null;
    var paceLastAI = {};   // pass-name -> last wall-clock run (AI-cadence floor, anti cost-multiplier)
    function refreshPace() { return Promise.resolve(store.get(RHYTHM_KEY)).then(function (rh) { paceCache = rh || null; return rh; }); }
    function paceReady() { return !!(cfg.adaptivePace && paceCache && (paceCache.samples || 0) >= (cfg.paceMinSamples || 5) && paceCache.avgGapMs != null); }
    // Rhythm-relative debounce: ~one typical gap + slack, hard-clamped. Falls back to the fixed
    // constant when pace isn't ready. (Used by the reply/paint/greet burst gates.)
    function currentDebounce() {
      if (!paceReady()) return cfg.debounceMs;
      var d = (paceCache.avgGapMs || 0) * (cfg.paceDebounceWgap || 0.5) + (paceCache.gapVarMs || 0) * (cfg.paceDebounceWdev || 1.0);
      // Clamp to [floor, ceil]. The configured debounceMs is the CEILING (pace may make it settle
      // faster than the fixed value, never slower) — so an explicitly tiny debounce stays tiny.
      var ceil = cfg.debounceMs;
      var floor = Math.min(cfg.debounceFloorMs || 800, ceil);
      return Math.round(Math.max(floor, Math.min(ceil, d)));
    }
    // How many deviations past typical the current silence is (z-score). >= paceQuietZ reads as quiet.
    function silenceZ(now) {
      if (!paceReady() || paceCache.lastActivity == null) return 0;
      var silentFor = now - paceCache.lastActivity;
      var denom = Math.max(paceCache.gapVarMs || 0, 1000);   // floor the denominator (avoid div blowups in a metronomic room)
      return (silentFor - (paceCache.avgGapMs || 0)) / denom;
    }
    function paceIsQuiet(now) { return paceReady() ? (silenceZ(now) >= (cfg.paceQuietZ || 3)) : null; }   // null = "no opinion, use your flat threshold"

    // ---- loop control --------------------------------------------------------------------
    // adaptive cadence: snap to the floor while there's activity or pending work; otherwise grow
    // the interval (x1.5) toward the ceiling so a quiet channel isn't polled every few seconds.
    function computeNextDelay(prev, summary) {
      if (!cfg.adaptivePolling) return cfg.pollIntervalMs;
      prev = prev || cfg.pollIntervalMs;
      // ADDRESSED-PRIORITY OVERRIDE: a pending reply/greet/gate/paint means it's been @-mentioned or
      // replied to (or owes a delivery) — being addressed always beats passive ingest, snap to floor.
      var addressed = hasPendingReply() || paint.queue.length || paint.painting || gate.pending || greet.pending;
      if (addressed) return cfg.pollFloorMs;

      if (cfg.adaptivePace) {
        // INVERTED model (this bot ACTS on new content; it doesn't chatter into a busy stream):
        //   quiet room  -> poll FAST (catch new content the moment it stirs); fresh content speeds up.
        //   busy  room  -> poll RELAXED but only PARTWAY (pollBusyCeilMs): passive ingest, reply on lull.
        var fresh = summary && summary.ingested > 0;
        var z = paceIsQuiet(clock.now());   // true=quiet, false=busy, null=pace-not-ready
        var busyCeil = cfg.pollBusyCeilMs || cfg.pollCeilMs;
        if (z === false) {
          // active room: ingest passively — ease the interval UP toward the partial (busy) ceiling.
          var relaxed = prev + (cfg.pollAdditiveStepMs || cfg.pollFloorMs);
          return Math.max(cfg.pollFloorMs, Math.min(relaxed, busyCeil));
        }
        // quiet (or pace not ready): be eager. Fresh content cuts the interval multiplicatively toward
        // the floor; an idle quiet poll still drifts UP toward the FULL ceiling (nothing to catch).
        if (fresh) return Math.max(cfg.pollFloorMs, Math.min(Math.round(prev * 0.5), cfg.pollCeilMs));
        var grownQ = prev + (cfg.pollAdditiveStepMs || cfg.pollFloorMs);
        return Math.max(cfg.pollFloorMs, Math.min(grownQ, cfg.pollCeilMs));
      }
      // legacy (pace off): binary snap-fast on any activity, else x1.5 grow.
      var busy = (summary && summary.ingested > 0) || hasPendingReply() || paint.queue.length || paint.painting || gate.pending || greet.pending;
      if (busy) return cfg.pollFloorMs;
      var grown = Math.round(prev * 1.5);
      return Math.max(cfg.pollFloorMs, Math.min(grown, cfg.pollCeilMs));
    }
    // Poll-failure explainer (user-visible): the raw Discord/transport error (kept,
    // PII-free) says WHAT broke in codes; this adds WHERE it broke and WHAT TO DO,
    // because a bare 'HTTP 503 {code=0 ...}' in the panel timeline reads like the
    // operator broke something. One line, no PII (status + Discord code + message
    // head only — the same fields errBrief keeps).
    function explainPollError(e) {
      var status = e && e.status;
      var body = (e && e.body) || {};
      var dcode = body.code;
      var msg = String((e && e.message) || e || '');
      var ch = cfg.channelId || '?';
      if (status === 429 || /rate[ .]?limit|retry_after/i.test(msg)) return 'Discord rate-limited this read (HTTP 429). Where: the Discord API, this channel (' + ch + '). Fix: nothing \u2014 the poll already backs off and retries; act only if EVERY poll 429s for 10+ min (too many channels polling too fast).';
      if (status === 401) return 'Discord rejected the bot token (HTTP 401). Where: transport login. Fix: Setup tab \u2192 paste a fresh bot token \u2192 Validate \u2192 Stop + Start.';
      if (status === 403 || dcode === 50001 || dcode === 50013 || /missing access|missing permissions|forbidden/i.test(msg)) return 'Discord refused access (HTTP 403' + (dcode != null ? '/code ' + dcode : '') + '). Where: this channel or server for this bot. Fix: confirm the bot is IN the server with View Channel + Read History here; a dead 403 channel also hangs polls \u2014 remove or re-grant it.';
      if (status === 404 || dcode === 10003) return 'Discord reports Unknown Channel (404/code 10003). Where: channel ' + ch + ' \u2014 deleted or the bot can no longer see it. Fix: polling for it pauses itself; verify the channel id and access, then Start again.';
      if (status === 500 || status === 502 || status === 503 || (status >= 520 && status <= 527) || dcode === 0 || /service unavailable|bad gateway|gateway/i.test(msg)) return 'Discord\u2019s servers hiccuped (' + (status ? ('HTTP ' + status) : 'unreachable') + (dcode != null ? '/code ' + dcode : '') + '). Where: Discord\u2019s side \u2014 NOT your token or setup. Fix: nothing \u2014 this poll retries automatically and keeps its place; act only if it repeats for 10+ min (check discordstatus.com).';
      if (/transport timeout|timed? ?out/i.test(msg)) return 'Discord gave no answer within the request window. Where: the link between this browser\u2019s userscript and Discord. Fix: usually transient \u2014 retries on its own; repeats mean your connection or Discord is degraded (check discordstatus.com).';
      if (/transport error|network|failed to fetch|load failed/i.test(msg)) return 'The userscript\u2019s Discord request never completed. Where: this browser between the userscript and Discord (net/DNS/script-blocker). Fix: check your connection, allow discord.com through script-blockers, then Stop + Start.';
      return 'Unusual read-path failure on channel ' + ch + '. Where: the poll read (transport or Discord). Fix: nothing urgent \u2014 retries automatically; if it repeats, paste this line plus Diagnostics \u2192 Dump trace ring.';
    }
    function start() {
      if (running) return;
      if (!cfg.channelId) throw new Error('[chloe.T0] no channelId configured');
      running = true;
      startedAt = clock.now();
      startupPending = true;   // next poll may carry a history backlog; clamp image gen on it
      greetSettleLogged = false;
      refreshPersonaName();
      resumePendingReply().catch(function () {});   // Gap A: pick up a predecessor's lost reply (verified, resume-once)
      log('[chloe.T0] started; ' + (cfg.adaptivePolling ? ('adaptive polling ' + cfg.pollFloorMs + '\u2013' + cfg.pollCeilMs + 'ms') : ('polling every ' + cfg.pollIntervalMs + 'ms')));
      if (!cfg.botUserId && !cfg.botName) {
        log('[chloe] WARNING: no bot identity yet — click Validate. Until then it can\u2019t tell when it\u2019s being @-mentioned or named, so EVERY message routes to the volunteer gate (and is likely ignored).');
      } else {
        var summonTxt = (cfg.botRoleIds && cfg.botRoleIds.length) ? (' or summon-role <@&' + cfg.botRoleIds.join('>/<@&') + '>') : '';
        log('[chloe] identity (bridge v' + (cfg.bridgeVersion || '?') + '): ' + (cfg.botName || '?') + ' (' + (cfg.botUserId || 'no id') + '); answers to: ' + nameAliases().join(', ') + ' or @-mention' + summonTxt + '; replies-when=' + cfg.addressMode);
      }
      var curDelay = cfg.pollIntervalMs;
      var tick = function () {
        if (!running) return;
        Promise.resolve(pollOnce()).then(function (summary) {
          curDelay = computeNextDelay(curDelay, summary);
          if (running) timer = setTimeout(tick, curDelay);
        }, function (e) {
          var code = e && (e.status || (e.body && e.body.code));
          var unknownChannel = (e && e.status === 404) || (e && e.body && e.body.code === 10003);
          log('[chloe.T0] poll error:', (e && e.message) || e, '-', explainPollError(e));
          if (unknownChannel && typeof cfg.onChannelGone === 'function') {
            try { cfg.onChannelGone(cfg.channelId); } catch (e2) { log('[chloe.poll] onChannelGone handler failed (' + ((e2 && e2.message) || e2) + ')'); }
            running = false;   // stop this engine's loop; the bootstrap decides whether to drop the channel
            return;
          }
          if (running) timer = setTimeout(tick, cfg.pollIntervalMs);
        });
      };
      tick();
    }
    function stop() { try { clearAllAcks('engine stopped'); } catch (eS) {} running = false; deferGen++; if (timer) clearTimeout(timer); timer = null; releaseRunLock(); log('[chloe.T0] stopped'); }   // releasing lets a clean successor claim instantly (no TTL wait); the sweep covers acks orphaned by the deferGen bump + discarded queues
    function isRunning() { return running; }

    // Live config patch: update specific cfg keys in-place on a running engine WITHOUT a full
    // rebuild. Only safe for values the engine reads at call-time (not ones captured at startup in
    // closure state). Currently: deviceClock, semanticInjections. Callers must list keys explicitly.
    // Keys the engine reads at call-time (not captured at startup) — safe to patch in-place on a
    // running engine without a full rebuild. Structural keys (channelId, addressMode, botUserId,
    // character/persona, channels list) still require applyConfigChange + rebuild.
    var LIVE_PATCHABLE = ['deviceClock', 'semanticInjections', 'deviceClockStaleMs', 'cleanOutput',
      'translate', 'selfKnowledge', 'attentionManager', 'exactTokens', 'workingMemory',
      'idleDeliberation', 'ownAffect', 'moodAware', 'channelSummary', 'factMemory', 'volunteer',
      'contradictionAware',
      'conversationMemory',
      'feedbackLearning',
      'semanticRecall',
      'userModeling',
      'deferredIntents',
      'greet', 'checkins', 'lullFiller', 'lullPatienceMs', 'lullMinGapMs',
      'checkinMinInteractions', 'checkinAbsenceMs', 'checkinPerUserGapMs', 'checkinGapMs',
      'checkinFavorites', 'checkinBlacklist',
      'adaptivePace', 'idleConsolidation', 'reflection',
      'episodicMemory', 'episodeGraph', 'goalObjects', 'relationshipTrust', 'reactionSummon',
      'proceduralModes', 'ackReactions', 'singleParagraph', 'toolsEnabled', 'converseEngine', 'trustHardening', 'bondLadder', 'replyReference', 'backfill', 'hamRadio',
      'chanSpeak', 'chanRead', 'chanRemember',
      'image', 'imageQueueMax', 'imageMemory', 'imageEnhanceOffer', 'autoMod', 'autoModRules', 'dmReplies', 'modList',
      'commandPrefixes', 'commandPrefix', 'beats', 'procRules', 'serverMemberCount', 'newsFeeds', 'newsPrompt', 'newsPodcastPrompt', 'newsPostTemplate', 'newsInContext', 'newsReview', 'thoughtsFeedTarget',
      'actPolicy', 'actGrants',
      'timezoneOffsetMins', 'timeAware', 'engageMode', 'channelLang', 'botAliases', 'botRoleIds', 'botLoopGrace',
      'botLoopHardStop', 'summonEmoji', 'ackThrottleEmoji'];
    function updateConfig(patch) {
      if (!patch || typeof patch !== 'object') return;
      Object.keys(patch).forEach(function (k) { if (LIVE_PATCHABLE.indexOf(k) >= 0) cfg[k] = patch[k]; });
    }

    // Self-rescue surface: stuckInfo describes the locks, rescueStuck clears them (manual panel
    // command + the automatic watchdogs above). The queue is always kept — rescue never drops a
    // message, it just lets the next poll retry it.
    function stuckInfo() {
      var nowS = clock.now();
      return { replying: !!reply.replying, replyAgeMs: reply.replying ? Math.max(0, nowS - (reply.startedAt || 0)) : 0, painting: !!paint.painting, paintAgeMs: paint.painting ? Math.max(0, nowS - (paint.startedAt || 0)) : 0, queuedAuthors: Object.keys(reply.queue).length, paintQueued: paint.queue.length, epoch: reply.epoch, acksOutstanding: Object.keys(outstandingAcks).length };
    }
    // Rescue card sweep: delete the recorded live thought cards (cmd reply card +
    // feed post), best-effort and fail-open like unreact. The pointer clears only
    // on a successful delete, so a failed delete retries via the next publish's
    // delete-old-then-post path instead of orphaning the card.
    function sweepThoughtCards(reason) {
      var keys = [THOUGHTCARD_CMD, THOUGHTCARD_FEED];
      if (typeof cfg.deleteMessage !== 'function') return Promise.resolve(0);
      var jobs = keys.map(function (k) {
        return Promise.resolve(store.get(k)).then(function (ptr) {
          if (!ptr || !ptr.id) return 0;
          var ch = ptr.target || cfg.channelId;
          return Promise.resolve(cfg.deleteMessage(ch, ptr.id)).then(function () {
            try { Promise.resolve(store.del(k)).catch(function () {}); } catch (eD) {}
            return 1;
          }, function () { return 0; });   // gone/perm/network: keep the pointer, next publish retries
        }, function () { return 0; });
      });
      return Promise.all(jobs).then(function (ns) {
        var n = 0; ns.forEach(function (x) { n += x; });
        if (n) log('[chloe.rescue] ' + reason + ': cleared ' + n + ' thought card(s)');
        return n;
      }, function () { return 0; });
    }
    function rescueStuck(reason) {
      var before = stuckInfo();
      if (reply.replying) { reply.replying = false; reply.epoch++; try { if (typeof cfg.releaseSend === 'function') cfg.releaseSend('text'); } catch (eR) {} }
      if (paint.painting) { paint.painting = false; try { if (typeof cfg.releaseSend === 'function') cfg.releaseSend('image'); } catch (eR2) {} }
      var swept = clearAllAcks(reason || 'manual rescue');   // full transient sweep (lane claims + throttle/search/lockdown/queue acks), not just the two in-flight lanes
      try { Promise.resolve(store.del(PENDING_KEY)).catch(function () {}); } catch (eR3) {}   // watchdog parity: a rescued generation must not resurrect later
      var why = reason || 'manual rescue';
      log('[chloe.rescue] ' + why + ': cleared reply/paint locks (had reply=' + before.replying + ' paint=' + before.painting + ') + swept ' + swept + ' stuck ack(s); ' + before.queuedAuthors + ' author(s) still queued, retrying');
      scheduleTextChain(); scheduleImageChain();
      // Card deletes are async (store read + DELETE); the locks/acks above are
      // already swept synchronously, so existing sync callers observe those
      // immediately and the promise only adds the card count.
      return Promise.resolve(sweepThoughtCards(why)).then(function (cards) {
        return { ok: true, value: { clearedReply: before.replying, clearedPaint: before.painting, sweptAcks: swept, sweptCards: cards } };
      }, function () {
        return { ok: true, value: { clearedReply: before.replying, clearedPaint: before.painting, sweptAcks: swept, sweptCards: 0 } };
      });
    }
    return {
      pollOnce: pollOnce,
      getRoster: getRoster,
      getSpeakerRing: getSpeakerRing,
      applyModAction: applyModAction,
      applyStrike: applyStrike,
      blockUser: blockUser, unblockUser: unblockUser, listBlocked: listBlocked,
      anchorSweep: anchorSweep,
      parseJob: parseJob,
      sanitizePromptForCaption: sanitizePromptForCaption,
      botLoopReplyChance: botLoopReplyChance,
      noteAuthorForLoop: noteAuthorForLoop,
      setIntent: setIntent, getIntent: getIntent, clearIntent: clearIntent,
      estimateTokens: estimateTokens, packByTokens: packByTokens, cleanReply: cleanReply, attentionScore: attentionScore, chooseAttention: chooseAttention, selfKnowledgeText: selfKnowledgeText,
      parseImageJson: parseImageJson,
      safeParseJson: safeParseJson, volunteerPrefilter: volunteerPrefilter,
      scheduleReminder: scheduleReminder, listReminders: listReminders, clearReminders: clearReminders, processReminders: processReminders,
      setAfk: setAfk, getAfk: getAfk, clearAfk: clearAfk, getAfkMap: getAfkMap,
      addHighlight: addHighlight, listHighlights: listHighlights, clearHighlights: clearHighlights,
      reactionSignificance: reactionSignificance, reactionThreshold: reactionThreshold, processMessageReactions: processMessageReactions, topReactions: topReactions, reactionSweep: reactionSweep,
      processLull: processLull, processCheckin: processCheckin, processFacts: processFacts,
      getFacts: getFacts, addFacts: addFacts, forgetFact: forgetFact, factSummary: factSummary,
      detectContradiction: detectContradiction,
      styleOf: styleOf, recordFeedback: recordFeedback,
      creditContinuation: creditContinuation,
      recordReplyStyle: function (style, who) { lastReplyStyle = style; fbPending.push({ style: style, who: who, at: clock.now(), done: false }); },
      cosine: cosine, fsrsRetrievability: fsrsRetrievability, fsrsStrengthen: fsrsStrengthen,
      boundedEvict: boundedEvict,
      userRegister: userRegister,
      getMemory: getMemory, editFact: editFact, deleteFact: deleteFact, addUserFact: addUserFact, editInsight: editInsight, deleteInsight: deleteInsight,
      getUserLang: getUserLang, setUserLang: setUserLang, updateConfig: updateConfig,
      exciseMessage: exciseMessage, exciseLastFromUser: exciseLastFromUser, assembleContext: assembleContext,
      timeContext: timeContext,
      updateMood: updateMood, moodDescriptor: moodDescriptor, moodSignals: moodSignals,
      processChannelSummary: processChannelSummary, recentTranscript: recentTranscript,
     processReflection: processReflection, processEpisodes: processEpisodes, dropEpisodesFor: dropEpisodesFor,
      scoreEpisodesForQuery: scoreEpisodesForQuery, searchEpisodes: searchEpisodes, episodeQueryTokens: episodeQueryTokens,
      processNews: processNews, testNewsFeed: testNewsFeed, postThoughtsFeed: postThoughtsFeed, thoughtCardPublish: thoughtCardPublish,
      runNewsFeedNow: runNewsFeedNow,
      listNewsQueue: listNewsQueue, newsDiag: newsDiag, updateNewsQueue: updateNewsQueue, regenNewsQueue: regenNewsQueue, postNewsQueue: postNewsQueue, dropNewsQueue: dropNewsQueue,
      newsParseRobots: newsParseRobots, newsPickSitemap: newsPickSitemap, newsParseItems: newsParseItems, newsParseFeedItems: newsParseFeedItems,
      newsFilterItems: newsFilterItems, newsFormatRollup: newsFormatRollup, recentTranscriptTexts: recentTranscriptTexts,
      newsClassicBody: newsClassicBody, newsApplyTemplate: newsApplyTemplate, newsComposeText: newsComposeText,
      newsResolveItemPrompt: newsResolveItemPrompt, newsResolveTemplate: newsResolveTemplate, newsPackPost: newsPackPost, newsItemLine: newsItemLine,
      newsSubtitle: newsSubtitle, newsCleanBlurb: newsCleanBlurb,
      newsKindOf: newsKindOf, newsKindEmoji: newsKindEmoji, newsKindLabel: newsKindLabel, newsCadence: newsCadence,
      newsOwnSig: newsOwnSig, newsMarkerLine: newsMarkerLine,
      addTrust: addTrust, creditPositiveReactions: creditPositiveReactions, replyPriority: replyPriority,
      addGoal: addGoal, closeGoal: closeGoal, goalsForOwner: goalsForOwner, loadGoals: loadGoals, dropGoalsFor: dropGoalsFor,
      seedCharacterMemories: seedCharacterMemories, clearCharacterMemories: clearCharacterMemories,
      workLoad: workLoad, workSync: workSync, noteDecision: noteDecision,
      deliberate: deliberate, deliberateDue: deliberateDue, deliberateSeed: deliberateSeed,
      getSelfIntents: getSelfIntents, scheduleSelfIntent: scheduleSelfIntent, dueSelfIntent: dueSelfIntent,
      consolidateStructural: consolidateStructural, consolidateSemantic: consolidateSemantic, channelIsIdle: channelIsIdle,
      currentDebounce: currentDebounce, silenceZ: silenceZ, paceIsQuiet: paceIsQuiet, paceReady: paceReady, refreshPace: refreshPace, computeNextDelay: computeNextDelay,
      affectLoad: affectLoad, affectNudge: affectNudge, affectTick: affectTick, affectOnUserMessage: affectOnUserMessage, affectOnContent: affectOnContent,
      procCheckReactions: procCheckReactions, getProcMode: getProcMode, clearProcMode: clearProcMode, activateProcMode: activateProcMode,
      rescueStuck: rescueStuck, stuckInfo: stuckInfo, clearAllAcks: clearAllAcks,
      resumePendingReply: resumePendingReply, summonCheckReactions: summonCheckReactions, pollCreate: pollCreate, pollClose: pollClose, checkPollExpiry: checkPollExpiry,
      BANDS: BANDS, registerProvider: registerProvider, gatherInjections: gatherInjections,
      archiveUser: archiveUser, restoreFromArchive: restoreFromArchive, getArchiveIndex: getArchiveIndex, quietSweep: quietSweep,
      describeJobs: describeJobs,
      getPersonaNote: getPersonaNote,
      clearPersonaNote: clearPersonaNote,
      purge: purge,
      getModLog: getModLog,
      verifyModLog: verifyModLog,
      approveAct: approveAct, dismissAct: dismissAct, getPendingAct: getPendingAct, getActLog: getActLog,
      actWhy: actWhy, actWhatIf: actWhatIf,
      pushUndoEntry: pushUndoEntry, peekUndo: peekUndo, undoLastApplied: undoLastApplied, restoreModState: restoreModState,
      clearanceOf: clearanceOf, elevateUser: elevateUser, demoteUser: demoteUser, transcriptFor: transcriptFor,
      appendModLog: appendModLog,
      knownFromOtherSurfaces: knownFromOtherSurfaces,
      ingestOne: ingestOne,
      quietSweep: quietSweep,
      dueForMemberCheck: dueForMemberCheck,
      noteMemberPresent: noteMemberPresent,
      markDeparted: markDeparted,
      backfillStep: backfillStep, resetBackfill: resetBackfill,
      computeNextDelay: computeNextDelay,
      start: start,
      stop: stop,
      isRunning: isRunning,
      config: cfg
    };
  }

  // Pure per-kind brain telemetry: Jacobson latency estimation (srtt + 4*rttvar -> adaptive
  // timeout) and a circuit breaker (CLOSED -> N consecutive failures -> OPEN, instant-fail ->
  // HALF-OPEN probe after probeMs -> success closes). Host (bootstrap) wires it around brainCall.
  function createBrainMeter(opts) {
    opts = opts || {};
    var alpha = opts.alpha != null ? opts.alpha : 0.125;   // RFC 6298 gains
    var beta = opts.beta != null ? opts.beta : 0.25;
    var minT = opts.minTimeoutMs || 10000, maxT = opts.maxTimeoutMs || 90000;
    var failsToOpen = opts.failsToOpen || 3, probeMs = opts.probeMs || 30000;
    var nowFn = opts.now || function () { return Date.now(); };
    var kinds = {};
    function k(kind) {
      return kinds[kind] || (kinds[kind] = { srtt: null, rttvar: null, fails: 0, state: 'closed', openedAt: 0, probing: false });
    }
    return {
      // before a call: { allow, probe, timeoutMs, reason }
      gate: function (kind) {
        var s = k(kind), now = nowFn();
        var t = (s.srtt == null) ? maxT : Math.max(minT, Math.min(maxT, Math.round(s.srtt + 4 * s.rttvar)));
        if (s.state === 'open') {
          if (now - s.openedAt >= probeMs && !s.probing) { s.probing = true; return { allow: true, probe: true, timeoutMs: t }; }   // half-open: ONE probe
          return { allow: false, timeoutMs: t, reason: 'brain circuit open for "' + kind + '" (' + s.fails + ' consecutive failures; probing every ' + Math.round(probeMs / 1000) + 's)' };
        }
        return { allow: true, probe: false, timeoutMs: t };
      },
      // after a call: ok=false means transport-level failure/timeout (a brain that ANSWERED
      // "no" is a success for the breaker — the wire works).
      record: function (kind, rttMs, ok) {
        var s = k(kind);
        if (ok && rttMs != null) {
          if (s.srtt == null) { s.srtt = rttMs; s.rttvar = rttMs / 2; }
          else { s.rttvar = (1 - beta) * s.rttvar + beta * Math.abs(rttMs - s.srtt); s.srtt = (1 - alpha) * s.srtt + alpha * rttMs; }
        }
        if (ok) { s.fails = 0; s.state = 'closed'; s.probing = false; }
        else {
          s.fails++; s.probing = false;
          if (s.fails >= failsToOpen) { s.state = 'open'; s.openedAt = nowFn(); }
        }
      },
      snapshot: function () {
        var out = {};
        Object.keys(kinds).forEach(function (kk) {
          var s = kinds[kk];
          out[kk] = { srtt: s.srtt == null ? null : Math.round(s.srtt), rttvar: s.rttvar == null ? null : Math.round(s.rttvar),
                      timeoutMs: (s.srtt == null) ? maxT : Math.max(minT, Math.min(maxT, Math.round(s.srtt + 4 * s.rttvar))),
                      state: s.state, fails: s.fails };
        });
        return out;
      },
      reset: function (kind) { if (kind) delete kinds[kind]; else Object.keys(kinds).forEach(function (kk) { delete kinds[kk]; }); }
    };
  }

  return { createEngine: createEngine, createBrainMeter: createBrainMeter, _snowflakeCmp: snowflakeCmp, LANG_NAMES: LANG_NAMES };
});
